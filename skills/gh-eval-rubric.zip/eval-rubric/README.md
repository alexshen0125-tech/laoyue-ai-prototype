# AI 功能评测细则：写进 PRD 的通过 / 不通过标准（gh-eval-rubric）

免费下载，装上即用。用途：AI 功能评测细则：写进 PRD 的通过 / 不通过标准。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** AI 产品设计与评测 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Calibre Partners LLC（Sandhya Hegde、Justin Bauer） · 来源：GitHub Calibre-Labs/reforge-ai-evals（skills/eval-rubric）· 许可证：CC-BY-4.0 · 老岳AI编辑部 中文整理与实测。上游文件除下述链接修正外原样保留，本 README 由编辑部撰写；这不是本站自制的 Skill。 编辑部修正了 1 处指向原仓库其他文件的链接，其余内容保持原样

## 用处

### 解决什么问题
AI 客服 PRD 里写「回答准确、语气友好」，研发和测试都不知道怎么判它过没过。

### 适合谁
负责 AI 功能或智能体的产品经理，要在 PRD 里写清「什么算好」。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| AI 功能还没上线，要从 PRD 写第一版评测细则<br>已经看过一批真实对话记录，要更新细则<br>要审别人写的评测细则 | 要写让模型当评委的提示词 → 用 gh-eval-llm-judge<br>要先把对话记录里的问题归类 → 用 gh-trace-codes<br>要设计答错时的兜底 → 用 ai-fallback-design |

### 用前 / 用后
**用前：** 细则写「回答要有帮助、要安全」，测试拿到 50 条对话，3 个人判出 3 种结果。

**用后：** 细则分四组：结果对不对（O）、过程对不对（T）、绝对不能 / 必须做（G，以「绝不」「始终」开头）、用户体验（X）；每行只写一个行为、看一条对话就能判过或不过、证据在记录里；跨多条对话才算的数（成本、延迟、失败率）单独放进「上线门槛」；输出一份网页和一份 Markdown 存在 PRD 旁边。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `eval-rubric/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-eval-rubric.zip -o /tmp/gh-eval-rubric.zip && unzip -oq /tmp/gh-eval-rubric.zip -d ~/.claude/skills/ && rm /tmp/gh-eval-rubric.zip
```

```powershell
$z="$env:TEMP\gh-eval-rubric.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eval-rubric.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/eval-rubric` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-eval-rubric.zip -o /tmp/gh-eval-rubric.zip && unzip -oq /tmp/gh-eval-rubric.zip -d ~/.agents/skills/ && rm /tmp/gh-eval-rubric.zip
```

```powershell
$z="$env:TEMP\gh-eval-rubric.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eval-rubric.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$eval-rubric` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-eval-rubric.zip -o /tmp/gh-eval-rubric.zip && unzip -oq /tmp/gh-eval-rubric.zip -d ~/.cursor/skills/ && rm /tmp/gh-eval-rubric.zip
```

```powershell
$z="$env:TEMP\gh-eval-rubric.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eval-rubric.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `eval-rubric`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-eval-rubric.zip -o /tmp/gh-eval-rubric.zip && unzip -oq /tmp/gh-eval-rubric.zip -d ~/.gemini/skills/ && rm /tmp/gh-eval-rubric.zip
```

```powershell
$z="$env:TEMP\gh-eval-rubric.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eval-rubric.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`agents/openai.yaml`、`references/prd-sections.md`、`references/rubric-template.html`、`references/worked-examples.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我给这个 AI 功能写评测细则」
- 「这份 PRD 里加上评测标准」
- 「AI 客服什么算答得好，帮我定清楚」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「AI 售后客服 PRD（贴上），能查订单、能发起退款但不能直接退款。帮我写第一版评测细则。」 |
| 它问了你什么 | 只问一句：「你看过这个智能体的真实对话记录了吗？」没看过就写第一版，看过就按记录更新。 |
| 它交付了什么 | 细则 16 行，例如 O2「退款金额与订单实付一致」、G1「绝不在用户未确认时提交退款申请」、X1「需要转人工时一句话说明原因」；上线门槛 3 条（如「单次对话成本低于 0.3 元」）。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**一定要生成网页吗？** 原文默认网页和 Markdown 各一份。网页版里它会直接给 Markdown，复制进 PRD 即可。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `eval-rubric`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 eval-rubric 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `eval-rubric`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE-CONTENT` | 上游许可证原文（CC-BY-4.0），原样保留 |
| `agents/openai.yaml` | 上游原文：上游给某个平台的显示名配置，纯文字，不执行 |
| `references/prd-sections.md` | 上游原文（修正 1 处缺失模板引用）：细则在 PRD 里放在哪一节 |
| `references/rubric-template.html` | 上游原文：展示细则的网页模板（引用外部网络字体） |
| `references/worked-examples.md` | 上游原文：两个产品从第一版到第二版细则的完整示例 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `92afb10` 版本，新增中文 README。
