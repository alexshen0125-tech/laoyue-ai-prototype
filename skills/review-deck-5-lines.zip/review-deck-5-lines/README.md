# 述职 PPT 先定 5 句结论（review-deck-5-lines）

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10）：在本机命令行 AI 里项目级安装真跑，「帮我做年终述职 PPT」自动调用，先出带来源的事实表，再停下问汇报对象和他关心什么；只改配色字号时不调用。同一份材料说「中间不用停」：装后 82 分、不装 71 分。装后有事实表、7 页结论句标题的逐页大纲和 12 条 VP 追问（问到平均数还是中位数、样本量），并指出最弱的一页；不装的没有事实表和追问，页标题多是栏目名。装后讲稿里仍有 1 处说错倍数（NPS 21→34 写成「翻了近一倍」），用前要查。样本 1 次，仅供参考。详见 AI 测评与指南《自制 Skill 全量实测》

## 用处

### 解决什么问题
一句话让工具生成 20 页，很好看，但领导问「今年最重要的一件事是什么」，翻三页还没翻到。

### 适合谁
要做年终述职、季度汇报的人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 手里有一年的周报、上线记录、复盘，不知道先讲什么<br>离述职还有几天，想先把要讲的话定下来 | 已有 PPT 只想改配色排版<br>发布会、培训课件、路演<br>只要一份文字周报 |

### 用前 / 用后
**用前：** 一句话让工具生成 20 页，配色统一、图标齐全。述职会上领导问「今年最重要的一件事是什么」，翻了三页还没翻到；第 7 页那个「提升 47%」，材料里根本没有。

**用后：** 第 1 页就是 5 句结论；每页标题是一句话；所有数字都能指到事实表的哪一行；会前已经被「扮领导」问过 12 个问题，答不上的 3 个补进了讲稿。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `review-deck-5-lines/` 文件夹，里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/review-deck-5-lines.zip -o /tmp/review-deck-5-lines.zip && unzip -oq /tmp/review-deck-5-lines.zip -d ~/.claude/skills/ && rm /tmp/review-deck-5-lines.zip
```

```powershell
$z="$env:TEMP\review-deck-5-lines.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/review-deck-5-lines.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/review-deck-5-lines` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/review-deck-5-lines.zip -o /tmp/review-deck-5-lines.zip && unzip -oq /tmp/review-deck-5-lines.zip -d ~/.agents/skills/ && rm /tmp/review-deck-5-lines.zip
```

```powershell
$z="$env:TEMP\review-deck-5-lines.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/review-deck-5-lines.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$review-deck-5-lines` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/review-deck-5-lines.zip -o /tmp/review-deck-5-lines.zip && unzip -oq /tmp/review-deck-5-lines.zip -d ~/.cursor/skills/ && rm /tmp/review-deck-5-lines.zip
```

```powershell
$z="$env:TEMP\review-deck-5-lines.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/review-deck-5-lines.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `review-deck-5-lines`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/review-deck-5-lines.zip -o /tmp/review-deck-5-lines.zip && unzip -oq /tmp/review-deck-5-lines.zip -d ~/.gemini/skills/ && rm /tmp/review-deck-5-lines.zip
```

```powershell
$z="$env:TEMP\review-deck-5-lines.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/review-deck-5-lines.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；步骤里提到的模板文件（`templates/` 下）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我做年终述职 PPT，材料如下……」
- 「季度汇报怎么讲，先帮我理一下这几个月做的事」
- 「把这些材料做成给老板的汇报」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「帮我做年终述职 PPT，材料如下。」然后按月贴上周报。 |
| 它问了你什么 | 先把材料整理成一张带来源的事实表，并列出「提到了但没有结果的事」请你补；再问你的岗位、汇报对象、他今年最关心什么。 |
| 它交付了什么 | 10 句结论候选（你选 5 句）→ 10 页以内的逐页大纲，每页标题是一句话、证据指到事实表哪一行、讲稿 3 句 → 扮领导提的 12 个追问，标出哪些大纲里还没答案（见 `examples/示例_商家后台述职.md`）。 |

### 常见问题
**说了触发说法，它没反应怎么办？** 先确认文件夹名和 `SKILL.md` 第二行 `name:` 一致、放对了目录（见上面「安装」里你用的那个 AI）、新开了对话。还不行，直接说「用 review-deck-5-lines 这个 Skill」点名调用；或者把你平时的说法加进 `SKILL.md` 开头 `description:` 那一行里——它只靠这一行判断要不要出场。

**怎么改成自己团队的版本？** 不要一上来就大改。先照原样用 3 次，每次把它的产出和你手改后的版本都存下来，然后让 AI 对比两版、说出你改动背后的规则，把规则写进 `SKILL.md` 的步骤或「不要做」里；模板换成你们团队的格式，放进 `templates/` 覆盖同名文件即可。改完在 README「更新记录」里写一行。

**它为什么不直接出 PPT 文件？** 有意的。它交的是大纲，你粘进任何一个出页工具就能排版；先定话、再出页，内容才不会被模板带跑。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 四步流程、反例、交付要求 |
| `templates/事实表.md` | 第 1 步表格 |
| `templates/逐页大纲.md` | 第 3 步表格 + 出页后自查 |
| `examples/示例_商家后台述职.md` | 示例产出（示例数据） |

## 更新记录
- v1.0（2026-11-09）：首发。
- v1.0（2026-11-09）：README 改为「用处 / 用法」结构，补完整使用示例与常见问题。
- v1.0（2026-11-09）：安装改为按平台分节、给可复制命令（下载地址为上线前占位）。
- v1.0（2026-11-09）：安装补齐 4 个平台的命令（目录按产品技术部核实）。
