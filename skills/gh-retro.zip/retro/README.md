# 迭代复盘（gh-retro）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-execution/skills/retro）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
复盘会每次的结论都是「沟通要加强」，下个迭代照旧。

### 适合谁
主持迭代复盘的产品经理、敏捷教练、小组长。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 迭代结束要组织复盘<br>手上有一堆便利贴、问卷或群里的吐槽要归纳 | 复盘的是一次线上事故（要时间线和根因）<br>写个人述职 → 用 review-deck-5-lines |

### 用前 / 用后
**用前：** 复盘列了 15 条改进项，一条都没人认领，下次复盘原样再列一遍。

**用后：** 选一种格式（开始/停止/继续、4L、帆船）；把零散反馈归成几个主题；看目标达成没有、承诺多少完成多少；改进项只留 2–3 条，每条有负责人、截止日、怎么算做到；回看上次的改进项完成没有。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `retro/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-retro.zip -o /tmp/gh-retro.zip && unzip -oq /tmp/gh-retro.zip -d ~/.claude/skills/ && rm /tmp/gh-retro.zip
```

```powershell
$z="$env:TEMP\gh-retro.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-retro.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/retro` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-retro.zip -o /tmp/gh-retro.zip && unzip -oq /tmp/gh-retro.zip -d ~/.agents/skills/ && rm /tmp/gh-retro.zip
```

```powershell
$z="$env:TEMP\gh-retro.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-retro.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$retro` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-retro.zip -o /tmp/gh-retro.zip && unzip -oq /tmp/gh-retro.zip -d ~/.cursor/skills/ && rm /tmp/gh-retro.zip
```

```powershell
$z="$env:TEMP\gh-retro.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-retro.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `retro`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-retro.zip -o /tmp/gh-retro.zip && unzip -oq /tmp/gh-retro.zip -d ~/.gemini/skills/ && rm /tmp/gh-retro.zip
```

```powershell
$z="$env:TEMP\gh-retro.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-retro.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我组织这次迭代复盘」
- 「这些复盘便利贴帮我归归类，出改进项」
- 「用帆船格式帮我做个复盘」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「第 14 个迭代，目标是再来一单上线，没按时上；承诺 34 点完成 26 点；这是大家写的 23 条反馈（贴上）。」 |
| 它问了你什么 | 先问用哪种格式（你不选它按情况推荐），再问上次复盘的改进项完成了没有。 |
| 它交付了什么 | 一份复盘纪要：目标部分达成、承诺 34 点完成 26 点；3 个主题（需求中途改、联调环境不稳、评审拖延）；改进项 2 条，如「需求冻结后改动走变更单——产品负责人——下个迭代开始前——变更不超过 1 次」。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**原文为什么建议先匿名收集？** 避免最资深的人先开口定调。用匿名问卷收一轮，再把结果贴给它。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/retro 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `retro`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 retro 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `retro`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
