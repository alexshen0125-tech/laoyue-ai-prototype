# 对话式写 PRD：先对齐概念版，再出落地版（gh-prd-writer）

免费下载，装上即用。用途：对话式写 PRD：先对齐概念版，再出落地版。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 定义需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Panix22 · 来源：GitHub Panix22/prd-writer-skill（prd-writer）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
想法还没聊清楚就让 AI 写完整 PRD，出来十几页，方向却是错的，只能整份重来。

### 适合谁
要从一个想法起步写 PRD 的产品经理，尤其是做小程序、App、网页小产品的。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 只有一个想法或一段描述，需要被追问着把用户、商业、技术、页面结构想清楚<br>要一份写到状态、字段、文案、异常的落地版 PRD | 需求已经很清楚，只要快速出规格 → 用 gh-write-spec<br>要把 PRD 精简成给编码工具看的版本 → 用 gh-vibe-coding-prd<br>已有 PRD 要挑问题 → 用 prd-four-role-review |

### 用前 / 用后
**用前：** 一句「做个习惯打卡小程序」，AI 直接给了 12 个功能，评审时才发现连付费不付费都没想过。

**用后：** 分四段走：每轮最多问 3 个问题，从用户、商业、技术、页面结构四个角度诊断；出不到 200 字的概念版 PRD 请你确认；冻结范围；最后按模板写落地版——每个 P0/P1 功能都有流程（含异常路径）、状态、字段规则和文案，不允许写「待定」，缺的信息标「建议默认值」。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `prd-writer/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-prd-writer.zip -o /tmp/gh-prd-writer.zip && unzip -oq /tmp/gh-prd-writer.zip -d ~/.claude/skills/ && rm /tmp/gh-prd-writer.zip
```

```powershell
$z="$env:TEMP\gh-prd-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prd-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/prd-writer` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-prd-writer.zip -o /tmp/gh-prd-writer.zip && unzip -oq /tmp/gh-prd-writer.zip -d ~/.agents/skills/ && rm /tmp/gh-prd-writer.zip
```

```powershell
$z="$env:TEMP\gh-prd-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prd-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$prd-writer` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-prd-writer.zip -o /tmp/gh-prd-writer.zip && unzip -oq /tmp/gh-prd-writer.zip -d ~/.cursor/skills/ && rm /tmp/gh-prd-writer.zip
```

```powershell
$z="$env:TEMP\gh-prd-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prd-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `prd-writer`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-prd-writer.zip -o /tmp/gh-prd-writer.zip && unzip -oq /tmp/gh-prd-writer.zip -d ~/.gemini/skills/ && rm /tmp/gh-prd-writer.zip
```

```powershell
$z="$env:TEMP\gh-prd-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prd-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`references/prd-template.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「我有个产品想法，帮我写 PRD」
- 「帮我把这个功能整理成需求文档」
- 「先别急着写，问我几个问题把需求对齐」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「想做一个给上班族用的习惯打卡小程序，帮我写 PRD。」 |
| 它问了你什么 | 先一句话复述需求，再分轮问：目标用户现在怎么记录？免费还是收费？要不要登录？数据存本地还是云端？主页面有哪几个？你不清楚页面结构，它会先给一版草案让你确认。 |
| 它交付了什么 | 概念版 PRD 8 行（核心用户、要解决的一件事、3 条最小可用功能、本版不做……）；你回「确认」后，出落地版：页面结构、每个功能的正常与异常流程、打卡状态、字段校验、提示文案和自查清单。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**我就想直接要一份完整 PRD？** 原文规定先问几轮再写，它会简短解释原因然后开始提问。实在赶时间，一次把用户、平台、收不收费、页面结构都说清，问答会很快结束。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `prd-writer`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 prd-writer 这个 Skill」点名调用。这个 Skill 的原文本身就有中文说明，一般中文提问即可触发。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `prd-writer`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（中英混合，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `references/prd-template.md` | 上游原文：落地版 PRD 模板与自查清单 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `d18d04a` 版本，新增中文 README。
