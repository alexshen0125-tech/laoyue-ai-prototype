# 从用户故事写测试场景（gh-test-scenarios）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-execution/skills/test-scenarios）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
测试用例靠测试自己猜，前置条件写「正常登录」，预期结果写「显示正确」。

### 适合谁
要自测或写验收的产品经理、测试工程师、没有专职测试的小团队。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 已经有用户故事和验收标准，要变成一步一步能执行的测试场景<br>上线前自己要过一遍，想有一份清单 | 还没有故事 → 先用 gh-user-stories<br>要做压力测试或写自动化测试代码<br>只要业务规则 → 用 acceptance-criteria-br-ac |

### 用前 / 用后
**用前：** 验收时产品自己点了两下觉得没问题；上线后「购物车里已有同款时数量叠加」出错。

**用后：** 每条验收标准对应一个场景：测什么、前置条件（账号、数据、配置）、谁来测、逐步操作和每一步的预期、边界和异常情况。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `test-scenarios/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-test-scenarios.zip -o /tmp/gh-test-scenarios.zip && unzip -oq /tmp/gh-test-scenarios.zip -d ~/.claude/skills/ && rm /tmp/gh-test-scenarios.zip
```

```powershell
$z="$env:TEMP\gh-test-scenarios.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-test-scenarios.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/test-scenarios` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-test-scenarios.zip -o /tmp/gh-test-scenarios.zip && unzip -oq /tmp/gh-test-scenarios.zip -d ~/.agents/skills/ && rm /tmp/gh-test-scenarios.zip
```

```powershell
$z="$env:TEMP\gh-test-scenarios.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-test-scenarios.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$test-scenarios` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-test-scenarios.zip -o /tmp/gh-test-scenarios.zip && unzip -oq /tmp/gh-test-scenarios.zip -d ~/.cursor/skills/ && rm /tmp/gh-test-scenarios.zip
```

```powershell
$z="$env:TEMP\gh-test-scenarios.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-test-scenarios.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `test-scenarios`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-test-scenarios.zip -o /tmp/gh-test-scenarios.zip && unzip -oq /tmp/gh-test-scenarios.zip -d ~/.gemini/skills/ && rm /tmp/gh-test-scenarios.zip
```

```powershell
$z="$env:TEMP\gh-test-scenarios.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-test-scenarios.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「根据这条用户故事写测试场景」
- 「帮我把验收标准变成测试用例」
- 「这个功能上线前我要自测，帮我列步骤」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 贴上「一键加购」那条故事和 5 条验收标准，说「写测试场景」。 |
| 它问了你什么 | 先确认产品名和有没有额外限制（比如只测 iOS）；你没给的前置数据会写成能造出来的样子，例如「账号 A 最近一次订单有 3 个商品，其中 1 个已下架」。 |
| 它交付了什么 | 6 个场景：正常加购、部分下架、全部下架、购物车已有同款、连点两次、断网；每个 4–5 步，每步写预期结果。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**它会帮我跑测试吗？** 不会，也不生成自动化代码。产出的是人读的测试场景，可以直接贴进你们的用例管理工具。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `test-scenarios`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 test-scenarios 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `test-scenarios`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
