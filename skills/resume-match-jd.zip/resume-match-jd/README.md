# 简历按岗位匹配（resume-match-jd）

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10）：在本机命令行 AI 里项目级安装真跑，「按这个 JD 改简历」自动调用，问「简历放一页还是两页」时不调用。同一份 JD 和简历：装后 88 分、不装 47 分。装后先出 6 行匹配表（强 / 弱 / 缺），A/B 实验标「缺」，SQL 和对账自动化的成果写【待补】请你提供；不装的版本把「和财务、技术一起做」改成了「独立推动财务、技术、运营三方协作」，还编了「覆盖平台全量商家」和 SQL 取数成果。装后仍有 1 处把「负责」拔高成「主导」，用前看一眼。代价是慢约 2 倍（50 秒对 24 秒）。样本 1 次，仅供参考。详见 AI 测评与指南《自制 Skill 全量实测》

## 用处

### 解决什么问题
让 AI 改简历，拿回一份很漂亮的版本，里面有你没说过的数字和你没有的技能，面试一问就露馅。

### 适合谁
跳槽季的产品经理；同一份简历要投几个方向的人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 手上有一份明确的目标岗位 JD<br>投了很多份没回音，想针对一个岗位改 | 没有目标 JD 的通用润色<br>写求职信<br>模拟面试 |

### 用前 / 用后
**用前：** 让 AI 改简历，拿回一份很漂亮的版本：「提升转化率 35%」「精通机器学习」——第一个数你没说过，第二个技能你没有，面试一问就露馅。

**用后：** 一张 5 行匹配表：2 条「强」、1 条「弱」、2 条「缺」；改写后的句子里，数字的位置写着【待补】，并告诉你去哪张报表找；「AI 功能落地」那条写着「缺」，附了一段面试时诚实的答法思路。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `resume-match-jd/` 文件夹，里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/resume-match-jd.zip -o /tmp/resume-match-jd.zip && unzip -oq /tmp/resume-match-jd.zip -d ~/.claude/skills/ && rm /tmp/resume-match-jd.zip
```

```powershell
$z="$env:TEMP\resume-match-jd.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/resume-match-jd.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/resume-match-jd` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/resume-match-jd.zip -o /tmp/resume-match-jd.zip && unzip -oq /tmp/resume-match-jd.zip -d ~/.agents/skills/ && rm /tmp/resume-match-jd.zip
```

```powershell
$z="$env:TEMP\resume-match-jd.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/resume-match-jd.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$resume-match-jd` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/resume-match-jd.zip -o /tmp/resume-match-jd.zip && unzip -oq /tmp/resume-match-jd.zip -d ~/.cursor/skills/ && rm /tmp/resume-match-jd.zip
```

```powershell
$z="$env:TEMP\resume-match-jd.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/resume-match-jd.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `resume-match-jd`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/resume-match-jd.zip -o /tmp/resume-match-jd.zip && unzip -oq /tmp/resume-match-jd.zip -d ~/.gemini/skills/ && rm /tmp/resume-match-jd.zip
```

```powershell
$z="$env:TEMP\resume-match-jd.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/resume-match-jd.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；步骤里提到的模板文件（`templates/` 下）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「按这个 JD 帮我改一下简历」
- 「看看我的简历和这个岗位匹不匹配」
- 「这份简历投这个岗位要怎么改」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「按这个 JD 帮我改一下简历。」贴上 JD 和删掉了手机号、证件号的简历。 |
| 它问了你什么 | 先把 JD 拆成 5 条硬要求请你过目；改写时遇到没有数字的经历，不会估，而是写【待补】并问你去哪张报表能找到。 |
| 它交付了什么 | 一张 5 行匹配表（2 强、1 弱、2 缺）、改写后的经历段落（每条对应 JD 哪一条）、待补清单、缺口与面试追问的诚实答法思路（见 `examples/示例_B端产品经理.md`）。 |

### 常见问题
**说了触发说法，它没反应怎么办？** 先确认文件夹名和 `SKILL.md` 第二行 `name:` 一致、放对了目录（见上面「安装」里你用的那个 AI）、新开了对话。还不行，直接说「用 resume-match-jd 这个 Skill」点名调用；或者把你平时的说法加进 `SKILL.md` 开头 `description:` 那一行里——它只靠这一行判断要不要出场。

**怎么改成自己团队的版本？** 不要一上来就大改。先照原样用 3 次，每次把它的产出和你手改后的版本都存下来，然后让 AI 对比两版、说出你改动背后的规则，把规则写进 `SKILL.md` 的步骤或「不要做」里；模板换成你们团队的格式，放进 `templates/` 覆盖同名文件即可。改完在 README「更新记录」里写一行。

**「缺」的那几条能不能帮我写上？** 不能，这是这个 Skill 的底线。它会告诉你面试官可能怎么问、怎么诚实回答，比编上去被问穿好。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 四步流程、改写反例 |
| `templates/匹配表.md` | 匹配表、待补清单、缺口与追问 |
| `examples/示例_B端产品经理.md` | 示例产出（虚构） |

## 更新记录
- v1.0（2026-11-09）：首发。
- v1.0（2026-11-09）：README 改为「用处 / 用法」结构，补完整使用示例与常见问题。
- v1.0（2026-11-09）：安装改为按平台分节、给可复制命令（下载地址为上线前占位）。
- v1.0（2026-11-09）：安装补齐 4 个平台的命令（目录按产品技术部核实）。
