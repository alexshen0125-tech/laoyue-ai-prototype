# AI 信任校准：别让用户太信，也别太不信（gh-trust-calibration）

免费下载，装上即用。用途：AI 信任校准：别让用户太信，也别太不信。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** AI 产品设计与评测 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：MC Dean（Owl-Listener） · 来源：GitHub Owl-Listener/ai-design-skills（ai-alignment-reasoning 插件下的 trust-calibration 目录）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
AI 报表助手说话太笃定，用户照着错数字做了决策；改成处处「可能」「或许」之后，用户又完全不看了。

### 适合谁
设计 AI 功能交互、写 AI 回复规范的产品经理和设计师。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 要设计 AI 怎么表达把握程度、怎么展示来源<br>AI 答错一次后用户就不用了，想挽回信任 | 要设计什么时候转人工 → 用 gh-escalation-design<br>要设计答错后的兜底流程 → 用 ai-fallback-design |

### 用前 / 用后
**用前：** 所有回答都用加粗标题和肯定句式，低把握的答案看起来和高把握的一样权威。

**用后：** 先看清影响信任的 5 个因素（语气多笃定、过往表现、用户是否知道风险、有没有来源、人设）；识别 5 种失败（迎合用户、过度自信、处处含糊、一次出错全盘否定、低把握答案用了高把握的排版）；再从 AI 一侧（把握程度如实表达、标来源、给备选、主动认错、说清能做什么不能做什么）和用户一侧（说明出错的代价）设计信号。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `trust-calibration/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-trust-calibration.zip -o /tmp/gh-trust-calibration.zip && unzip -oq /tmp/gh-trust-calibration.zip -d ~/.claude/skills/ && rm /tmp/gh-trust-calibration.zip
```

```powershell
$z="$env:TEMP\gh-trust-calibration.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-trust-calibration.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/trust-calibration` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-trust-calibration.zip -o /tmp/gh-trust-calibration.zip && unzip -oq /tmp/gh-trust-calibration.zip -d ~/.agents/skills/ && rm /tmp/gh-trust-calibration.zip
```

```powershell
$z="$env:TEMP\gh-trust-calibration.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-trust-calibration.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$trust-calibration` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-trust-calibration.zip -o /tmp/gh-trust-calibration.zip && unzip -oq /tmp/gh-trust-calibration.zip -d ~/.cursor/skills/ && rm /tmp/gh-trust-calibration.zip
```

```powershell
$z="$env:TEMP\gh-trust-calibration.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-trust-calibration.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `trust-calibration`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-trust-calibration.zip -o /tmp/gh-trust-calibration.zip && unzip -oq /tmp/gh-trust-calibration.zip -d ~/.gemini/skills/ && rm /tmp/gh-trust-calibration.zip
```

```powershell
$z="$env:TEMP\gh-trust-calibration.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-trust-calibration.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「AI 回答该怎么表达不确定」
- 「用户太相信 AI 的答案了，怎么设计」
- 「AI 答错一次用户就不用了，怎么办」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「B 端 AI 报表助手，用户会直接拿它给的数字发周报。帮我设计信任校准。」 |
| 它问了你什么 | 先问错一次的代价有多大、用户是谁、现在的回答长什么样。 |
| 它交付了什么 | 一套规范：三档把握程度的固定说法；所有数字旁标数据源和统计时间；低把握答案不用加粗结论；首次使用时提示「发出前核对关键数字」；答错后的认错话术。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**原文比较短？** 是一份设计原则清单，适合配合具体页面使用：把你的界面或回复样例贴给它，让它逐条对照改。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `trust-calibration`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 trust-calibration 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `trust-calibration`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `f41b650` 版本，新增中文 README。
