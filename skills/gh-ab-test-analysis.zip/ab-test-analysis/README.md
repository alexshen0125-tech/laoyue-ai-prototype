# A/B 实验结果分析（gh-ab-test-analysis）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-data-analytics/skills/ab-test-analysis）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
实验跑了 3 天，实验组转化高了 0.4 个百分点，就宣布「赢了」全量上线。

### 适合谁
要看实验结果、做上线决定的产品经理、增长和数据分析同学。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 实验结束，要判断能不能全量<br>想检查样本够不够、分流有没有出问题 | 还在设计实验阶段（它重在分析结果）<br>要先想清楚该看什么数据 → 用 data-question-decision-first |

### 用前 / 用后
**用前：** 只看了主指标相对提升 8%，没算显著性，也没发现客单价这个「护栏指标」掉了。

**用后：** 先核对假设、改了什么、主指标和护栏指标、跑了多久、分流比例；再查样本量、分流是否失衡、新鲜感效应；算出两组转化率、相对提升、p 值、95% 置信区间；最后按结果表给出「全量 / 延长 / 停止 / 先查清楚」。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `ab-test-analysis/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-ab-test-analysis.zip -o /tmp/gh-ab-test-analysis.zip && unzip -oq /tmp/gh-ab-test-analysis.zip -d ~/.claude/skills/ && rm /tmp/gh-ab-test-analysis.zip
```

```powershell
$z="$env:TEMP\gh-ab-test-analysis.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-ab-test-analysis.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/ab-test-analysis` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-ab-test-analysis.zip -o /tmp/gh-ab-test-analysis.zip && unzip -oq /tmp/gh-ab-test-analysis.zip -d ~/.agents/skills/ && rm /tmp/gh-ab-test-analysis.zip
```

```powershell
$z="$env:TEMP\gh-ab-test-analysis.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-ab-test-analysis.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$ab-test-analysis` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-ab-test-analysis.zip -o /tmp/gh-ab-test-analysis.zip && unzip -oq /tmp/gh-ab-test-analysis.zip -d ~/.cursor/skills/ && rm /tmp/gh-ab-test-analysis.zip
```

```powershell
$z="$env:TEMP\gh-ab-test-analysis.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-ab-test-analysis.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `ab-test-analysis`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-ab-test-analysis.zip -o /tmp/gh-ab-test-analysis.zip && unzip -oq /tmp/gh-ab-test-analysis.zip -d ~/.gemini/skills/ && rm /tmp/gh-ab-test-analysis.zip
```

```powershell
$z="$env:TEMP\gh-ab-test-analysis.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-ab-test-analysis.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我看看这个 A/B 实验结果显著吗」
- 「实验数据在这，能不能全量」
- 「帮我检查这个实验样本量够不够」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「实验：再来一单按钮放首页 vs 放订单页；跑了 7 天；对照组 4,980 人转化 612，实验组 5,020 人转化 701；护栏指标是客单价。」 |
| 它问了你什么 | 先问假设、主指标、护栏指标、跑了几个完整周期；你没给护栏数据，它会提醒你补。 |
| 它交付了什么 | 结果表：对照 12.3%、实验 14.0%，相对提升约 14%，p 约 0.013，显著；护栏数据缺 → 结论「先查清楚」，补上客单价再定。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**它说要写 Python 脚本？** 那是它当场生成的，包里没有任何脚本。你的工具能运行代码才会运行，运行前会问你，可以先看一眼；网页版就让它手算并写出公式。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/ab-test-analysis 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `ab-test-analysis`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 ab-test-analysis 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `ab-test-analysis`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
