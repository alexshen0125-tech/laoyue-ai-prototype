# 产品经理数据面：定指标、找原因、做取舍（gh-analytical-pm）

免费下载，装上即用。用途：产品经理数据面：定指标、找原因、做取舍。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 个人成长 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：aroyburman-codes · 来源：GitHub aroyburman-codes/pm-skills（skills/analytical-pm）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
面试题「日活掉了 15% 怎么查」，一上来就猜原因，没有先排除数据问题、也没拆维度。

### 适合谁
准备产品经理面试数据分析轮的人；想练习排查指标异常的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 练「怎么定指标 / 某指标掉了怎么查 / 两个方案怎么选」三类题<br>要一套 AI 产品特有的指标和排查思路 | 工作中要真的排查问题 → 用 gh-root-cause-analysis<br>要设计 A/B 实验 → 用 gh-experiment-design |

### 用前 / 用后
**用前：** 回答「为 AI 写作功能定成功指标」只说了「日活和留存」。

**用后：** 分三类题给框架：定指标题（目标→用户行为→北极星、辅助、护栏）；排查题（先确认数据、再按时间、平台、人群、功能拆、内外部因素、提出假设和验证）；取舍题（列选项、按影响和代价比较、给建议和兜底）。另有 AI 产品特有的考虑：答案质量、幻觉率、成本。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `analytical-pm/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-analytical-pm.zip -o /tmp/gh-analytical-pm.zip && unzip -oq /tmp/gh-analytical-pm.zip -d ~/.claude/skills/ && rm /tmp/gh-analytical-pm.zip
```

```powershell
$z="$env:TEMP\gh-analytical-pm.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-analytical-pm.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/analytical-pm` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-analytical-pm.zip -o /tmp/gh-analytical-pm.zip && unzip -oq /tmp/gh-analytical-pm.zip -d ~/.agents/skills/ && rm /tmp/gh-analytical-pm.zip
```

```powershell
$z="$env:TEMP\gh-analytical-pm.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-analytical-pm.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$analytical-pm` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-analytical-pm.zip -o /tmp/gh-analytical-pm.zip && unzip -oq /tmp/gh-analytical-pm.zip -d ~/.cursor/skills/ && rm /tmp/gh-analytical-pm.zip
```

```powershell
$z="$env:TEMP\gh-analytical-pm.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-analytical-pm.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `analytical-pm`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-analytical-pm.zip -o /tmp/gh-analytical-pm.zip && unzip -oq /tmp/gh-analytical-pm.zip -d ~/.gemini/skills/ && rm /tmp/gh-analytical-pm.zip
```

```powershell
$z="$env:TEMP\gh-analytical-pm.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-analytical-pm.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「日活掉了 15% 怎么查，帮我按面试答一遍」
- 「帮我给这个 AI 功能定成功指标」
- 「两个方案怎么取舍，面试怎么答」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「面试题：某 AI 写作助手周活跃下降 15%，你会怎么分析？」 |
| 它问了你什么 | 会先列出要澄清的问题（下降是突然还是渐进、全量还是某个平台），你不回答就按假设往下走并注明。 |
| 它交付了什么 | 结构化答案：先查埋点和统计口径；按新老用户、平台、功能入口拆；发现集中在安卓新版本；提出 3 个假设并各给验证方法；最后给出指标护栏（生成质量评分）和下一步。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**和 gh-mock-interviewer 有什么区别？** 这个是教你答题框架、给你一份示范答案；模拟面试是出题、追问、打分。先学框架再去模拟。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `analytical-pm`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 analytical-pm 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `analytical-pm`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `f879de8` 版本，新增中文 README。
