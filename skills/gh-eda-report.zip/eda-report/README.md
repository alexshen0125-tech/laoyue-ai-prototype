# 拿到一份数据先摸底：探索性分析报告（gh-eda-report）

免费下载，装上即用。用途：拿到一份数据先摸底：探索性分析报告。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 上线验证 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：qa-aman 及该仓库贡献者 · 来源：GitHub qa-aman/claude-skills（skills/by-role/data-scientist/eda-report）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
拿到一份用户行为导出表就开始做结论，后来才发现有 30% 的记录重复、金额字段有负数。

### 适合谁
要自己动手看数据的产品经理、数据分析新人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 拿到一份新数据，想先知道有多少行、哪里缺、哪里怪<br>做看板或结论前先做数据质量检查 | 要写取数 SQL → 用 gh-sql-queries<br>分析做完要自检结论 → 用 gh-validate-data |

### 用前 / 用后
**用前：** 直接按「平均客单价」出结论，没发现有几单测试订单金额是 99999。

**用后：** 先审数据：行列数、类型、缺失比例（超 5% 标出）、重复行；逐列画像：数值列看均值与中位数差、1% 和 99% 分位，类别列看取值个数和前几名；再看变量之间的关系和异常值；最后写一份结构化报告：数据质量问题、关键发现、下一步建议。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `eda-report/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-eda-report.zip -o /tmp/gh-eda-report.zip && unzip -oq /tmp/gh-eda-report.zip -d ~/.claude/skills/ && rm /tmp/gh-eda-report.zip
```

```powershell
$z="$env:TEMP\gh-eda-report.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eda-report.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/eda-report` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-eda-report.zip -o /tmp/gh-eda-report.zip && unzip -oq /tmp/gh-eda-report.zip -d ~/.agents/skills/ && rm /tmp/gh-eda-report.zip
```

```powershell
$z="$env:TEMP\gh-eda-report.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eda-report.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$eda-report` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-eda-report.zip -o /tmp/gh-eda-report.zip && unzip -oq /tmp/gh-eda-report.zip -d ~/.cursor/skills/ && rm /tmp/gh-eda-report.zip
```

```powershell
$z="$env:TEMP\gh-eda-report.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eda-report.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `eda-report`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-eda-report.zip -o /tmp/gh-eda-report.zip && unzip -oq /tmp/gh-eda-report.zip -d ~/.gemini/skills/ && rm /tmp/gh-eda-report.zip
```

```powershell
$z="$env:TEMP\gh-eda-report.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eda-report.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我看看这份数据里有什么」
- 「这个表先做个数据质量检查」
- 「拿到一份导出数据，帮我摸个底」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 上传一份 CSV（订单 5 万行），说「电商后台导出的 10 月订单，想先摸底再做客单价分析」。 |
| 它问了你什么 | 先问数据的来源和你接下来想回答的问题，以便决定重点看哪些列。 |
| 它交付了什么 | 报告：5 万行 14 列；重复行 1,200 行；「优惠金额」缺失 12%；金额最大值 99,999 的 6 单疑似测试单；客单价中位数 86 元、均值 132 元，分布右偏，建议用中位数；下一步 3 条。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**我的工具不能运行代码怎么办？** 它会让你描述或贴出部分数据，按同样的检查项人工判断；行数多时建议用能运行代码的工具。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `eda-report`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 eda-report 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `eda-report`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `be4abcc` 版本，新增中文 README。
