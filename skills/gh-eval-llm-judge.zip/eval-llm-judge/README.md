# 让模型当评委：写评审提示词并对齐人工标注（gh-eval-llm-judge）

免费下载，装上即用。用途：让模型当评委：写评审提示词并对齐人工标注。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** AI 产品设计与评测 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Calibre Partners LLC（Sandhya Hegde、Justin Bauer） · 来源：GitHub Calibre-Labs/reforge-ai-evals（skills/eval-llm-judge）· 许可证：CC-BY-4.0 · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
AI 回答的质量全靠人工抽看，每次上线前 3 个人看 200 条，看到眼花，标准还不一致。

### 适合谁
负责 AI 功能质量的产品经理，与研发一起搭自动评测的人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 有些质量没法用规则判断（是否忠于资料、语气是否恰当），想让模型当评委<br>要检查现有的评审提示词是否有偏见、含糊或一次判多件事 | 还没定评测细则 → 先用 gh-eval-rubric<br>能用规则判断的（字数、格式、是否包含某字段） → 直接写规则，不用模型评委 |

### 用前 / 用后
**用前：** 一个评审提示词同时判「准确、完整、礼貌」，打分忽高忽低，没人敢信。

**用后：** 一个评委只判一个标准；先找项目里已有的评测格式照着写；提示词里写清判定标准、过与不过的例子、只输出理由和 0/1；最后拿一批人工标注过的样本对齐，看评委和人的一致率，不达标就改提示词。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `eval-llm-judge/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-eval-llm-judge.zip -o /tmp/gh-eval-llm-judge.zip && unzip -oq /tmp/gh-eval-llm-judge.zip -d ~/.claude/skills/ && rm /tmp/gh-eval-llm-judge.zip
```

```powershell
$z="$env:TEMP\gh-eval-llm-judge.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eval-llm-judge.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/eval-llm-judge` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-eval-llm-judge.zip -o /tmp/gh-eval-llm-judge.zip && unzip -oq /tmp/gh-eval-llm-judge.zip -d ~/.agents/skills/ && rm /tmp/gh-eval-llm-judge.zip
```

```powershell
$z="$env:TEMP\gh-eval-llm-judge.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eval-llm-judge.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$eval-llm-judge` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-eval-llm-judge.zip -o /tmp/gh-eval-llm-judge.zip && unzip -oq /tmp/gh-eval-llm-judge.zip -d ~/.cursor/skills/ && rm /tmp/gh-eval-llm-judge.zip
```

```powershell
$z="$env:TEMP\gh-eval-llm-judge.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eval-llm-judge.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `eval-llm-judge`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-eval-llm-judge.zip -o /tmp/gh-eval-llm-judge.zip && unzip -oq /tmp/gh-eval-llm-judge.zip -d ~/.gemini/skills/ && rm /tmp/gh-eval-llm-judge.zip
```

```powershell
$z="$env:TEMP\gh-eval-llm-judge.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-eval-llm-judge.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`agents/openai.yaml`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我写一个让模型判断答案是否忠于资料的评审提示词」
- 「这个评审提示词有什么问题」
- 「怎么让模型评委和人工标注对齐」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「知识库问答助手，想自动判断『回答是否只用了检索到的资料，没有编造』。我们有 60 条人工标注过的样本。」 |
| 它问了你什么 | 先问项目里有没有现成的评测目录和格式；没有就按通用格式写，并问你用哪个模型当评委。 |
| 它交付了什么 | 一个评审提示词（判定标准、2 个通过例、2 个不通过例、输出格式）；一个运行脚本的骨架；对齐步骤：先跑 60 条，看与人工一致率，低于 90% 时按分歧样本改标准。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**我不会写代码也能用吗？** 评审提示词本身你就能写、能审；运行脚本那部分交给研发，或在能运行代码的工具里让它带你跑。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `eval-llm-judge`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 eval-llm-judge 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `eval-llm-judge`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE-CONTENT` | 上游许可证原文（CC-BY-4.0），原样保留 |
| `agents/openai.yaml` | 上游原文：上游给某个平台的显示名配置，纯文字，不执行 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `92afb10` 版本，新增中文 README。
