# 提示词诊断与改写：先找病因，再对症改（gh-prompt-engineer）

免费下载，装上即用。用途：提示词诊断与改写：先找病因，再对症改。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** AI 产品设计与评测 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Aakash Gupta · 来源：GitHub aakashg/pm-claude-skills（skills/prompt-engineer）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
AI 功能的提示词越改越长，问题还是那几个：格式不稳、动不动编数据、语气不对。

### 适合谁
在写或维护 AI 功能提示词的产品经理；日常用提示词干活的人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 手上有一段提示词和一个不满意的输出，要找原因并改好<br>要把提示词缩短但效果不变 | 要从零写一个完整的 Skill（先看 Skill 库的新手说明页）<br>要系统评测 AI 输出 → 用 gh-eval-rubric |

### 用前 / 用后
**用前：** 提示词 800 字，规则写了 20 条，输出格式还是每次不一样。

**用后：** 先要齐三样东西：原提示词全文、目标、坏输出样例；诊断问题属于哪一类；把问题对到具体技巧（角色、结构化输出、分步思考、少量示例、明确的要做 / 不要做、自查标准、把指令和输入数据分开）；输出诊断、改好的提示词、改了什么为什么、怎么测。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `prompt-engineer/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-prompt-engineer.zip -o /tmp/gh-prompt-engineer.zip && unzip -oq /tmp/gh-prompt-engineer.zip -d ~/.claude/skills/ && rm /tmp/gh-prompt-engineer.zip
```

```powershell
$z="$env:TEMP\gh-prompt-engineer.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prompt-engineer.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/prompt-engineer` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-prompt-engineer.zip -o /tmp/gh-prompt-engineer.zip && unzip -oq /tmp/gh-prompt-engineer.zip -d ~/.agents/skills/ && rm /tmp/gh-prompt-engineer.zip
```

```powershell
$z="$env:TEMP\gh-prompt-engineer.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prompt-engineer.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$prompt-engineer` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-prompt-engineer.zip -o /tmp/gh-prompt-engineer.zip && unzip -oq /tmp/gh-prompt-engineer.zip -d ~/.cursor/skills/ && rm /tmp/gh-prompt-engineer.zip
```

```powershell
$z="$env:TEMP\gh-prompt-engineer.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prompt-engineer.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `prompt-engineer`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-prompt-engineer.zip -o /tmp/gh-prompt-engineer.zip && unzip -oq /tmp/gh-prompt-engineer.zip -d ~/.gemini/skills/ && rm /tmp/gh-prompt-engineer.zip
```

```powershell
$z="$env:TEMP\gh-prompt-engineer.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prompt-engineer.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`references/techniques.md`、`templates/SKILL-TEMPLATE.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我改一下这个提示词」
- 「这个提示词为什么老是输出不对」
- 「把这个提示词缩短一点」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 贴上一段「生成商品卖点」的提示词和 2 个输出不好的例子，说「格式不稳，还会编参数」。 |
| 它问了你什么 | 缺坏输出样例时会先要样例——原文要求拿到真实失败再改，不凭空优化。 |
| 它交付了什么 | 诊断：没给输出格式、没把商品资料和指令分开、没写「资料里没有的参数不要写」；改写版加了固定格式、资料分隔、1 个示例和自查句；附 3 条测试输入。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**原文例子是英文提示词？** 方法对中文提示词同样适用，直接贴中文提示词即可。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `prompt-engineer`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 prompt-engineer 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `prompt-engineer`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `references/techniques.md` | 上游原文：提示词技巧说明 |
| `templates/SKILL-TEMPLATE.md` | 上游原文：作者的 Skill 写法模板（建议把多步提示词做成 Skill 时用） |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `64deebf` 版本，新增中文 README。
