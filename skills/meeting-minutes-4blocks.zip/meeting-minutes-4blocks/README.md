# 会议纪要 4 块（meeting-minutes-4blocks）

**版本：** v1.2 · **日期：** 2026-11-10 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10，v1.2）：v1.0 在本机命令行 AI 里项目级安装真跑，两次都按模板编了记录人、漏了 1 条待办，装后 52 分、不装 79 分，判不通过。改版到 v1.2（没给的信息一律【待补】、说「我想想」的人不进负责人栏、会议日期没给就不推算日子、格式写进 SKILL.md 少读文件）后，原题装后 92 分、不装 79 分；另一份没见过的周会速记装后 92.5 分、不装 67.5 分（不装的两次都编了会议日期）。代价是慢约 3 倍（35 秒对 10 秒）。详见 AI 测评与指南《自制 Skill 全量实测》

## 用处

### 解决什么问题
会开完，纪要按时间顺序记了三屏，待办写着「大家跟进一下」，下次会又从头讨论。

### 适合谁
经常组织评审会、周会、用户访谈的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 会后要在 5 分钟内发出纪要<br>手上有录音转写、速记或群聊记录 | 会还没开，要写议程或邀请<br>只是校对转写稿的错别字<br>只要一句话摘要 |

### 用前 / 用后
**用前：** 拿到一份按时间顺序的「会议记录」，三屏长，待办写着「产品和设计跟进一下」「尽快」。下周开会，又从头讨论一遍。

**用后：** 一屏：结论 3 条、范围变更 2 条、待办 5 条，每条有一个人和一个日子；没人认领的那条写【待补】，并注明会后找运营确认；转写里只有「说话人 2」的，没有被猜成某个名字。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `meeting-minutes-4blocks/` 文件夹，里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/meeting-minutes-4blocks.zip -o /tmp/meeting-minutes-4blocks.zip && unzip -oq /tmp/meeting-minutes-4blocks.zip -d ~/.claude/skills/ && rm /tmp/meeting-minutes-4blocks.zip
```

```powershell
$z="$env:TEMP\meeting-minutes-4blocks.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/meeting-minutes-4blocks.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/meeting-minutes-4blocks` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/meeting-minutes-4blocks.zip -o /tmp/meeting-minutes-4blocks.zip && unzip -oq /tmp/meeting-minutes-4blocks.zip -d ~/.agents/skills/ && rm /tmp/meeting-minutes-4blocks.zip
```

```powershell
$z="$env:TEMP\meeting-minutes-4blocks.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/meeting-minutes-4blocks.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$meeting-minutes-4blocks` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/meeting-minutes-4blocks.zip -o /tmp/meeting-minutes-4blocks.zip && unzip -oq /tmp/meeting-minutes-4blocks.zip -d ~/.cursor/skills/ && rm /tmp/meeting-minutes-4blocks.zip
```

```powershell
$z="$env:TEMP\meeting-minutes-4blocks.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/meeting-minutes-4blocks.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `meeting-minutes-4blocks`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/meeting-minutes-4blocks.zip -o /tmp/meeting-minutes-4blocks.zip && unzip -oq /tmp/meeting-minutes-4blocks.zip -d ~/.gemini/skills/ && rm /tmp/meeting-minutes-4blocks.zip
```

```powershell
$z="$env:TEMP\meeting-minutes-4blocks.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/meeting-minutes-4blocks.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；步骤里提到的模板文件（`templates/` 下）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我整理这段会议录音的纪要：……」
- 「这是今天评审会的转写，出一份纪要」
- 「把这次周会的待办列一下」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「这是今天评审会的转写，出一份纪要。」附上参会人名单和转写稿。 |
| 它问了你什么 | 速记和参会人都给了就不问，直接整理，开头写一句「按需求评审会整理」；只有什么都没贴时才问会议类型、参会人和专有名词。 |
| 它交付了什么 | 一屏纪要：结论 3 条、范围变更 2 条、待办 5 条（每条一个人、一个日子），没人认领的一条写【待补】并建议会后找谁确认（见 `examples/需求评审纪要.md`）。 |

### 常见问题
**说了触发说法，它没反应怎么办？** 先确认文件夹名和 `SKILL.md` 第二行 `name:` 一致、放对了目录（见上面「安装」里你用的那个 AI）、新开了对话。还不行，直接说「用 meeting-minutes-4blocks 这个 Skill」点名调用；或者把你平时的说法加进 `SKILL.md` 开头 `description:` 那一行里——它只靠这一行判断要不要出场。

**怎么改成自己团队的版本？** 不要一上来就大改。先照原样用 3 次，每次把它的产出和你手改后的版本都存下来，然后让 AI 对比两版、说出你改动背后的规则，把规则写进 `SKILL.md` 的步骤或「不要做」里；模板换成你们团队的格式，放进 `templates/` 覆盖同名文件即可。改完在 README「更新记录」里写一行。

**转写里只有「说话人 1、说话人 2」怎么办？** 它会原样保留并标【待确认是谁】，不会猜名字。你在开头给出参会人名单，它会按名单对上。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 整理规则、输出格式、发出前自查、反例（跑任务只读这一个文件） |
| `reference/会议类型.md` | 四种会议的结构变体 |
| `templates/纪要.md` | 一屏纪要模板 + 发出前自查 |
| `examples/需求评审纪要.md` | 示例产出（虚构） |

## 更新记录
- v1.0（2026-11-09）：首发。
- v1.0（2026-11-09）：README 改为「用处 / 用法」结构，补完整使用示例与常见问题。
- v1.0（2026-11-09）：安装改为按平台分节、给可复制命令（下载地址为上线前占位）。
- v1.0（2026-11-09）：安装补齐 4 个平台的命令（目录按产品技术部核实）。
- v1.1（2026-11-10）：实测发现模板「记录：【姓名】」会诱导 AI 编记录人、分歧里的会后动作会漏进待办。改为：没给的信息一律【待补】不许编（模板记录人默认【待补】）；「回头看看」不算认领；分歧里约好的会后动作进待办；标记统一为【待补】。
- v1.2（2026-11-10）：留出集复测发现 v1.1 仍会把说「我想想」的人写进负责人栏、用今天日期推算「周四」。改为：负责人栏不出现未认领的人；会议日期没给不推算；周例会没贴上周待办按通用整理、不写会上没人说的风险；格式与自查写进 SKILL.md，跑任务不必读模板。复测通过（原题 92 vs 79，留出集 92.5 vs 67.5）。
