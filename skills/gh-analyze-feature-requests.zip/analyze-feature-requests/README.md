# 用户需求池分析（gh-analyze-feature-requests）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-product-discovery/skills/analyze-feature-requests）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。 编辑部按 MIT 许可删除了原文末的课程推广链接，其余内容保持原样。

## 用处

### 解决什么问题
销售、客服、用户群里攒了 80 条需求，谁嗓门大先做谁的。

### 适合谁
管需求池、要决定下一步做什么的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 有一批用户提的功能请求（表格或文字）<br>要归类，并挑出最值得做的 3 个 | 只想了解有哪些排序方法 → 用 gh-prioritization-frameworks<br>整理单份访谈 → 用 gh-summarize-interview |

### 用前 / 用后
**用前：** 按「提的人数」排序，第一名是「导出 Excel」，做完才发现真正的问题是对账难。

**用后：** 先确认产品目标；把请求归成主题；看每个主题和目标有多契合；按影响、成本、风险、战略契合挑出前 3；每个都写理由、替代方案、风险最高的假设和最省事的验证办法。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `analyze-feature-requests/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-analyze-feature-requests.zip -o /tmp/gh-analyze-feature-requests.zip && unzip -oq /tmp/gh-analyze-feature-requests.zip -d ~/.claude/skills/ && rm /tmp/gh-analyze-feature-requests.zip
```

```powershell
$z="$env:TEMP\gh-analyze-feature-requests.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-analyze-feature-requests.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/analyze-feature-requests` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-analyze-feature-requests.zip -o /tmp/gh-analyze-feature-requests.zip && unzip -oq /tmp/gh-analyze-feature-requests.zip -d ~/.agents/skills/ && rm /tmp/gh-analyze-feature-requests.zip
```

```powershell
$z="$env:TEMP\gh-analyze-feature-requests.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-analyze-feature-requests.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$analyze-feature-requests` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-analyze-feature-requests.zip -o /tmp/gh-analyze-feature-requests.zip && unzip -oq /tmp/gh-analyze-feature-requests.zip -d ~/.cursor/skills/ && rm /tmp/gh-analyze-feature-requests.zip
```

```powershell
$z="$env:TEMP\gh-analyze-feature-requests.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-analyze-feature-requests.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `analyze-feature-requests`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-analyze-feature-requests.zip -o /tmp/gh-analyze-feature-requests.zip && unzip -oq /tmp/gh-analyze-feature-requests.zip -d ~/.gemini/skills/ && rm /tmp/gh-analyze-feature-requests.zip
```

```powershell
$z="$env:TEMP\gh-analyze-feature-requests.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-analyze-feature-requests.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我分析这批用户需求」
- 「需求池太乱了，帮我归类挑出最该做的」
- 「这些客户反馈的功能请求怎么排」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「目标是下季度减少门店缺货投诉；这是 80 条需求（贴表格），帮我分析。」 |
| 它问了你什么 | 先确认目标和期望结果；表格里没有影响人数的，会请你补，或者标成估计值。 |
| 它交付了什么 | 7 个主题（对账、补货提醒、订单修改……）；前 3 是补货提醒、截单后可改单、缺货自动替换；每个配替代方案（比如「缺货替换」可以先做「缺货提前通知」）和一周内能做完的验证。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**它把我的功能需求改成了「问题」？** 有意的。原文的原则是「排问题不排功能」，所以「导出 Excel」会被归到背后的「对账难」里。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/analyze-feature-requests 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `analyze-feature-requests`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 analyze-feature-requests 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `analyze-feature-requests`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
