# 把对话记录的观察归类成问题清单（gh-trace-codes）

免费下载，装上即用。用途：把对话记录的观察归类成问题清单。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** AI 产品设计与评测 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Calibre Partners LLC（Sandhya Hegde、Justin Bauer） · 来源：GitHub Calibre-Labs/reforge-ai-evals（skills/trace-codes）· 许可证：CC-BY-4.0 · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
看了 50 条 AI 对话记录，笔记记了一堆，最后还是说不清「最该先修什么」。

### 适合谁
在做 AI 功能错误分析的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 已经读过并批注了一批对话记录，要把零散笔记归类<br>要知道各类问题各出现了多少次、先修哪个 | 还没读过对话记录 → 原文要求先自己读并批注至少 10 条<br>要写评测细则 → 用 gh-eval-rubric<br>要排查单次执行失败的原因 → 用 gh-agent-trace-diagnoser |

### 用前 / 用后
**用前：** 笔记里写着「数字不对」「没给来源」「答非所问」，同一个问题有 5 种叫法，没法统计。

**用后：** 先把每条笔记拆成单个观察并保留编号；把描述同一现象的归成一类，每类有 3–6 字标题、能用是 / 否判断的一句定义、2–3 个例子和出现次数（几条里出现几条）；好的表现也可以成一类；输出问题清单、一张给人工复核用的标注表和对评测细则的修改建议。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `trace-codes/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-trace-codes.zip -o /tmp/gh-trace-codes.zip && unzip -oq /tmp/gh-trace-codes.zip -d ~/.claude/skills/ && rm /tmp/gh-trace-codes.zip
```

```powershell
$z="$env:TEMP\gh-trace-codes.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-trace-codes.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/trace-codes` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-trace-codes.zip -o /tmp/gh-trace-codes.zip && unzip -oq /tmp/gh-trace-codes.zip -d ~/.agents/skills/ && rm /tmp/gh-trace-codes.zip
```

```powershell
$z="$env:TEMP\gh-trace-codes.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-trace-codes.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$trace-codes` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-trace-codes.zip -o /tmp/gh-trace-codes.zip && unzip -oq /tmp/gh-trace-codes.zip -d ~/.cursor/skills/ && rm /tmp/gh-trace-codes.zip
```

```powershell
$z="$env:TEMP\gh-trace-codes.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-trace-codes.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `trace-codes`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-trace-codes.zip -o /tmp/gh-trace-codes.zip && unzip -oq /tmp/gh-trace-codes.zip -d ~/.gemini/skills/ && rm /tmp/gh-trace-codes.zip
```

```powershell
$z="$env:TEMP\gh-trace-codes.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-trace-codes.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`agents/openai.yaml`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我把这些对话记录的笔记归归类」
- 「这批对话记录里主要有哪些问题」
- 「我们先修哪个问题」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「AI 报表助手，我读了 40 条对话记录并写了笔记（贴 CSV：编号、笔记）。」 |
| 它问了你什么 | 笔记没有编号时会先编号并告诉你；如果你只有记录没有笔记，它会请你先自己读。 |
| 它交付了什么 | 问题清单 7 类，例如「引用了过期数据」40 条中 9 条、「没说明数据来源」6 条；好的表现 1 类；标注表 40 行 × 7 列；建议在评测细则里新增 2 行。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**为什么不让它直接读记录写笔记？** 原文认为读记录是产品判断发生的地方，必须由人来做；它可以帮你概括长记录、指出工具调用，但观察要是你的。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `trace-codes`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 trace-codes 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `trace-codes`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE-CONTENT` | 上游许可证原文（CC-BY-4.0），原样保留 |
| `agents/openai.yaml` | 上游原文：上游给某个平台的显示名配置，纯文字，不执行 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `92afb10` 版本，新增中文 README。
