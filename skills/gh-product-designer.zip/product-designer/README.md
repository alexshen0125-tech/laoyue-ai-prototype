# 原型 / 设计稿评审：先说好在哪，再列必改（gh-product-designer）

免费下载，装上即用。用途：原型 / 设计稿评审：先说好在哪，再列必改。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 定义需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Aakash Gupta · 来源：GitHub aakashg/pm-claude-skills（skills/product-designer）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
设计稿评审时大家只说「感觉不太对」，改了三轮还是没说清哪里不对。

### 适合谁
要评审原型或设计稿、给设计师反馈的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 手上有截图、原型或设计稿，要一份分级的修改意见<br>上线前检查可用性和无障碍问题 | 只改界面文案 → 用 gh-ux-writing<br>还没有原型 → 用 one-line-html-prototype 先出一版 |

### 用前 / 用后
**用前：** 结算页评审意见 15 条平铺，设计师不知道先改哪个，最要命的「主按钮在小屏幕上被挡住」排在第 12 条。

**用后：** 先确认三样东西：能看到的图、用户在这个流程里要干什么、平台和阶段；先说做得好的；再按 6 个维度（清晰、流程、信息结构、一致性、出错处理、无障碍）审；输出必改最多 3 条、建议改 2–4 条、可考虑 1–3 条，并写明没审到的部分。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `product-designer/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-product-designer.zip -o /tmp/gh-product-designer.zip && unzip -oq /tmp/gh-product-designer.zip -d ~/.claude/skills/ && rm /tmp/gh-product-designer.zip
```

```powershell
$z="$env:TEMP\gh-product-designer.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-product-designer.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/product-designer` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-product-designer.zip -o /tmp/gh-product-designer.zip && unzip -oq /tmp/gh-product-designer.zip -d ~/.agents/skills/ && rm /tmp/gh-product-designer.zip
```

```powershell
$z="$env:TEMP\gh-product-designer.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-product-designer.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$product-designer` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-product-designer.zip -o /tmp/gh-product-designer.zip && unzip -oq /tmp/gh-product-designer.zip -d ~/.cursor/skills/ && rm /tmp/gh-product-designer.zip
```

```powershell
$z="$env:TEMP\gh-product-designer.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-product-designer.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `product-designer`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-product-designer.zip -o /tmp/gh-product-designer.zip && unzip -oq /tmp/gh-product-designer.zip -d ~/.gemini/skills/ && rm /tmp/gh-product-designer.zip
```

```powershell
$z="$env:TEMP\gh-product-designer.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-product-designer.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`references/ai-ux-review.md`、`references/screen-checklists.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我评审这张设计稿」
- 「看看这个原型有什么可用性问题」
- 「给设计师写一份修改意见」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 上传电商结算页截图，说「新用户第一次下单，手机端，准备交开发，帮我评审」。 |
| 它问了你什么 | 看不到图时不会硬评，会请你上传；用户目标和阶段没说，会先问这两件事。 |
| 它交付了什么 | 做得好 2 条；必改 3 条（如「优惠券入口和支付按钮颜色一样，抢了主操作」）；建议改 3 条；可考虑 2 条；注明「没看到加载和报错状态，未评」。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**我只有一段文字描述，没有图？** 原文要求先看到真实的图再评，否则容易空谈。没有图就先用 one-line-html-prototype 出一个可点原型截个图。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `product-designer`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 product-designer 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `product-designer`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `references/ai-ux-review.md` | 上游原文：AI 界面评审检查项 |
| `references/screen-checklists.md` | 上游原文：各类页面评审检查项 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `64deebf` 版本，新增中文 README。
