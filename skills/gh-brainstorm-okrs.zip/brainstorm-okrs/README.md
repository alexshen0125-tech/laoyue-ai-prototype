# 团队 OKR 草案（gh-brainstorm-okrs）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-execution/skills/brainstorm-okrs）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。 编辑部按 MIT 许可删除了原文末的课程推广链接，其余内容保持原样。

## 用处

### 解决什么问题
OKR 写成了任务清单：「KR1：上线 5 个功能」。

### 适合谁
每季度要写团队 OKR 的产品经理、小组负责人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 要对齐公司目标，出团队 OKR 草案<br>想要几套方案拿去和团队讨论 | 要定长期核心指标 → 用 gh-north-star-metric<br>要准备个人述职 → 用 review-deck-5-lines |

### 用前 / 用后
**用前：** 「O：做好门店体验；KR：上线再来一单、上线补货提醒、完成首页改版」

**用后：** 三套同样站得住的 OKR，每套 1 个有方向感的目标加 3 个可量化的 KR（如「新店首月复购率从 35% 到 45%」），附为什么重要；不出现「上线 N 个功能」这种产出型 KR，并标出要依赖哪些数据。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `brainstorm-okrs/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-brainstorm-okrs.zip -o /tmp/gh-brainstorm-okrs.zip && unzip -oq /tmp/gh-brainstorm-okrs.zip -d ~/.claude/skills/ && rm /tmp/gh-brainstorm-okrs.zip
```

```powershell
$z="$env:TEMP\gh-brainstorm-okrs.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-brainstorm-okrs.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/brainstorm-okrs` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-brainstorm-okrs.zip -o /tmp/gh-brainstorm-okrs.zip && unzip -oq /tmp/gh-brainstorm-okrs.zip -d ~/.agents/skills/ && rm /tmp/gh-brainstorm-okrs.zip
```

```powershell
$z="$env:TEMP\gh-brainstorm-okrs.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-brainstorm-okrs.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$brainstorm-okrs` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-brainstorm-okrs.zip -o /tmp/gh-brainstorm-okrs.zip && unzip -oq /tmp/gh-brainstorm-okrs.zip -d ~/.cursor/skills/ && rm /tmp/gh-brainstorm-okrs.zip
```

```powershell
$z="$env:TEMP\gh-brainstorm-okrs.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-brainstorm-okrs.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `brainstorm-okrs`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-brainstorm-okrs.zip -o /tmp/gh-brainstorm-okrs.zip && unzip -oq /tmp/gh-brainstorm-okrs.zip -d ~/.gemini/skills/ && rm /tmp/gh-brainstorm-okrs.zip
```

```powershell
$z="$env:TEMP\gh-brainstorm-okrs.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-brainstorm-okrs.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我写下季度团队 OKR」
- 「对齐公司目标，给我三套 OKR 方案」
- 「帮我看看这个 KR 写得对不对」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「公司一季度目标是提升门店留存；我们是订货 App 团队，帮我出 OKR 草案。」 |
| 它问了你什么 | 先读你给的公司目标和战略材料，再问团队能影响的 3–5 个方向。 |
| 它交付了什么 | 三套 OKR（留存向、效率向、履约向），每套 3 个 KR 带目标值和「大约六七成把握」的说明，并列出「KR2 需要先补复购埋点」这类数据前提。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**KR 的目标值能直接用吗？** 那是它按经验给的，一定要拿你们自己的历史数据改。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/brainstorm-okrs 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `brainstorm-okrs`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 brainstorm-okrs 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `brainstorm-okrs`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
