# PRD 四角色挑刺（prd-four-role-review）

**版本：** v1.2 · **日期：** 2026-11-10 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10，v1.2）：v1.0 在本机命令行 AI 里项目级安装真跑，埋了 10 个雷的 PRD 平均只挑中 5 个（不装 7 个），判不通过；改版加 8 项通用必查后，原题平均挑中 8.5 个、另一份没见过的 PRD 挑中 9 个（不装分别 7、8 个），两套题总分都超过不装。代价是慢 1.5–2 倍。说评审请求每次都自动调用，改错别字时不调用。详见 AI 测评与指南《3 个站内 Skill 真装真跑》

## 用处

### 解决什么问题
PRD 写完直接约评审，会上被研发、测试轮流问倒，结论是「回去补完再约」。

### 适合谁
要过需求评审的产品经理；接手别人 PRD 的人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 评审会前一天，自己先挑一遍<br>接手一份 PRD，想快速知道哪里没写清 | 还没有文档 → 用 prd-step-by-step<br>只想润色措辞、改错别字<br>文档不到半屏 → 先补齐再评审 |

### 用前 / 用后
**用前：** PRD 写完直接约评审。研发问「上次是哪次」，测试问「下架了怎么测」，会开了一个小时，结论是「回去补完再约」。

**用后：** 评审前拿到 7 条问题，P0 的 3 条（取单规则没定义、没防重、没有异常验收标准）当天补完；其中 1 条判断为假问题，填了「不采纳：线上已有统一防抖」。评审只剩 2 个讨论点。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `prd-four-role-review/` 文件夹，里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/prd-four-role-review.zip -o /tmp/prd-four-role-review.zip && unzip -oq /tmp/prd-four-role-review.zip -d ~/.claude/skills/ && rm /tmp/prd-four-role-review.zip
```

```powershell
$z="$env:TEMP\prd-four-role-review.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/prd-four-role-review.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/prd-four-role-review` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/prd-four-role-review.zip -o /tmp/prd-four-role-review.zip && unzip -oq /tmp/prd-four-role-review.zip -d ~/.agents/skills/ && rm /tmp/prd-four-role-review.zip
```

```powershell
$z="$env:TEMP\prd-four-role-review.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/prd-four-role-review.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$prd-four-role-review` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/prd-four-role-review.zip -o /tmp/prd-four-role-review.zip && unzip -oq /tmp/prd-four-role-review.zip -d ~/.cursor/skills/ && rm /tmp/prd-four-role-review.zip
```

```powershell
$z="$env:TEMP\prd-four-role-review.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/prd-four-role-review.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `prd-four-role-review`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/prd-four-role-review.zip -o /tmp/prd-four-role-review.zip && unzip -oq /tmp/prd-four-role-review.zip -d ~/.gemini/skills/ && rm /tmp/prd-four-role-review.zip
```

```powershell
$z="$env:TEMP\prd-four-role-review.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/prd-four-role-review.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；步骤里提到的模板文件（`templates/` 下）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我评审一下这份 PRD：……」
- 「站在研发和测试的角度挑挑刺」
- 「明天评审，帮我先自查一遍这份需求」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「明天评审，帮我先自查一遍这份需求。」然后贴上 PRD 全文。 |
| 它问了你什么 | 先确认「这是全文吗，后面还有没有」；先过 8 项通用必查（范围边界、特殊对象、前后数字、防刷、钱去哪、通知、目标、异常验收），再让研发、测试、设计、规范四个角色各挑一遍，互不参考。 |
| 它交付了什么 | 一句结论（P0 3 条、P1 3 条、P2 1 条，P0 未清零前不建议约评审）+ 一张合并去重后的问题表，每条指到原文哪一句，最后一列「采纳 / 不采纳」留给你填（见 `examples/评审输出示例.md`）。 |

### 常见问题
**说了触发说法，它没反应怎么办？** 先确认文件夹名和 `SKILL.md` 第二行 `name:` 一致、放对了目录（见上面「安装」里你用的那个 AI）、新开了对话。还不行，直接说「用 prd-four-role-review 这个 Skill」点名调用；或者把你平时的说法加进 `SKILL.md` 开头 `description:` 那一行里——它只靠这一行判断要不要出场。

**怎么改成自己团队的版本？** 不要一上来就大改。先照原样用 3 次，每次把它的产出和你手改后的版本都存下来，然后让 AI 对比两版、说出你改动背后的规则，把规则写进 `SKILL.md` 的步骤或「不要做」里；模板换成你们团队的格式，放进 `templates/` 覆盖同名文件即可。改完在 README「更新记录」里写一行。

**挑出来的问题要全改吗？** 不要。AI 不了解你们的业务背景，会有假问题。逐条判断，不采纳的写一句原因，P0 改完再约评审。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 通用必查 + 三步流程、级别口径、反例 |
| `reference/四角色清单.md` | 8 项通用必查 + 每个角色看的 5 件事 |
| `templates/问题表.md` | 单角色表和合并表的格式 |
| `examples/评审输出示例.md` | 示例产出（虚构） |

## 更新记录
- v1.0（2026-11-09）：首发。
- v1.0（2026-11-09）：README 改为「用处 / 用法」结构，补完整使用示例与常见问题。
- v1.0（2026-11-09）：安装改为按平台分节、给可复制命令（下载地址为上线前占位）。
- v1.0（2026-11-09）：安装补齐 4 个平台的命令（目录按产品技术部核实）。
- v1.1（2026-11-10）：实测发现「每个角色只看 5 项、看完就停」会漏大问题（埋雷 PRD 装后挑中 5/10、不装 7/10）。改为先过 8 项通用必查；清单是起点不是边界；不同缺口不硬合并；尊重用户指定的角色数和列数。
- v1.2（2026-11-10）：v1.1 在原题上胜出、在新题上命中持平但慢一倍。改为同一对话里单角色表不写出来、直接出合并表；示例文件格式拿不准时再读。
