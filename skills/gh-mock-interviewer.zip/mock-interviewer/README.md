# AI 产品经理模拟面试：出题、追问、打分（gh-mock-interviewer）

免费下载，装上即用。用途：AI 产品经理模拟面试：出题、追问、打分。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 个人成长 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：aroyburman-codes · 来源：GitHub aroyburman-codes/pm-skills（skills/mock-interviewer）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
自己准备面试只会看题背答案，真被追问两层就乱了，也不知道自己答得几分。

### 适合谁
准备产品经理、AI 产品经理面试的人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 想要一场接近真实的模拟面试，被追问、被打分<br>想练产品设计、策略、数据分析、技术、行为面等不同轮次 | 要先系统学某一轮的答题框架 → 用 gh-analytical-pm 或 gh-technical-pm<br>要从简历准备故事 → 用 gh-interview-prep-generator |

### 用前 / 用后
**用前：** 对着题库自言自语练了 20 题，真面试时一个「你怎么知道用户需要这个」就卡住了。

**用后：** 先选轮次和难度；它扮演面试官出一道题，按你的回答追问 2–4 轮（不会提前给答案）；结束后给总评、各维度 1–4 分、具体到原话的反馈，并和这一轮的标准答题框架对照，指出漏了哪一步。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `mock-interviewer/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-mock-interviewer.zip -o /tmp/gh-mock-interviewer.zip && unzip -oq /tmp/gh-mock-interviewer.zip -d ~/.claude/skills/ && rm /tmp/gh-mock-interviewer.zip
```

```powershell
$z="$env:TEMP\gh-mock-interviewer.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-mock-interviewer.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/mock-interviewer` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-mock-interviewer.zip -o /tmp/gh-mock-interviewer.zip && unzip -oq /tmp/gh-mock-interviewer.zip -d ~/.agents/skills/ && rm /tmp/gh-mock-interviewer.zip
```

```powershell
$z="$env:TEMP\gh-mock-interviewer.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-mock-interviewer.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$mock-interviewer` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-mock-interviewer.zip -o /tmp/gh-mock-interviewer.zip && unzip -oq /tmp/gh-mock-interviewer.zip -d ~/.cursor/skills/ && rm /tmp/gh-mock-interviewer.zip
```

```powershell
$z="$env:TEMP\gh-mock-interviewer.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-mock-interviewer.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `mock-interviewer`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-mock-interviewer.zip -o /tmp/gh-mock-interviewer.zip && unzip -oq /tmp/gh-mock-interviewer.zip -d ~/.gemini/skills/ && rm /tmp/gh-mock-interviewer.zip
```

```powershell
$z="$env:TEMP\gh-mock-interviewer.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-mock-interviewer.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「模拟一场 AI 产品经理面试」
- 「考我一道产品设计题，像真面试那样追问」
- 「帮我练一下数据分析轮」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「模拟一场 AI 产品经理的产品设计轮，中等难度，用中文。」 |
| 它问了你什么 | 先确认轮次、难度、要不要模仿某类公司风格；然后直接出题，例如「为家长设计一个 AI 作业辅导功能」。 |
| 它交付了什么 | 追问 3 轮（「你怎么判断模型答错了」「错一次的代价是什么」）；总评「有条件通过」；用户洞察 3 分、方案 3 分、指标 2 分、AI 风险意识 2 分；指出「没提答错时的兜底」并给改进示范。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**能用中文面吗？** 能，开始时说「用中文」。原文按海外大厂面试写，题目可以直接让它换成国内常见场景。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `mock-interviewer`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 mock-interviewer 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `mock-interviewer`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `f879de8` 版本，新增中文 README。
