# 周 / 月度指标复盘：记分卡、亮点、隐患、行动（gh-metrics-review）

免费下载，装上即用。用途：周 / 月度指标复盘：记分卡、亮点、隐患、行动。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 上线验证 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10）：在本机命令行 AI 里项目级安装真跑，周会指标复盘 1/1 自动调用、问概念时不调用；装后 100 分、不装 69 分：两版都识别出一次性大单和埋点升级导致的转化率假下跌，不装的版本有 1 处自相矛盾的结论。详见 AI 测评与指南《又装了 5 个站内 Skill》

> 原作者：Anthropic · 来源：GitHub anthropics/knowledge-work-plugins（product-management/skills/metrics-review）· 许可证：Apache-2.0 · 老岳AI编辑部 中文整理与实测。上游文件除下述链接修正外原样保留，本 README 由编辑部撰写；这不是本站自制的 Skill。 编辑部修正了 1 处指向原仓库其他文件的链接，其余内容保持原样

## 用处

### 解决什么问题
月度复盘就是把看板截图贴进 PPT，每页写「环比 +3%」，老板问「所以要做什么」没人答。

### 适合谁
要做周会、月会、季度指标复盘的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 定期复盘指标，要一份带结论和行动的报告<br>某个指标突然掉了，要先摸清范围 | 要从零设计指标体系 → 用 gh-metrics-framework 或 gh-north-star-metric<br>要设计看板 → 用 gh-metrics-dashboard |

### 用前 / 用后
**用前：** 复盘写了 12 页，每个指标都「略有波动」，没有一条行动。

**用后：** 先按北极星、健康指标、诊断指标三层整理；每个指标看当前值、趋势、与目标差距、变化是在加速还是放缓、有没有异常；输出一页总结、指标记分卡、趋势解读、亮点、隐患、建议行动（带负责人）和数据说明。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `metrics-review/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-review.zip -o /tmp/gh-metrics-review.zip && unzip -oq /tmp/gh-metrics-review.zip -d ~/.claude/skills/ && rm /tmp/gh-metrics-review.zip
```

```powershell
$z="$env:TEMP\gh-metrics-review.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-review.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/metrics-review` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-review.zip -o /tmp/gh-metrics-review.zip && unzip -oq /tmp/gh-metrics-review.zip -d ~/.agents/skills/ && rm /tmp/gh-metrics-review.zip
```

```powershell
$z="$env:TEMP\gh-metrics-review.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-review.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$metrics-review` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-review.zip -o /tmp/gh-metrics-review.zip && unzip -oq /tmp/gh-metrics-review.zip -d ~/.cursor/skills/ && rm /tmp/gh-metrics-review.zip
```

```powershell
$z="$env:TEMP\gh-metrics-review.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-review.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `metrics-review`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-review.zip -o /tmp/gh-metrics-review.zip && unzip -oq /tmp/gh-metrics-review.zip -d ~/.gemini/skills/ && rm /tmp/gh-metrics-review.zip
```

```powershell
$z="$env:TEMP\gh-metrics-review.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-review.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`CONNECTORS.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我做一下这个月的指标复盘」
- 「这些指标数据帮我出一份周报解读」
- 「这个月转化掉了，帮我先整理一下情况」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「内容 App 10 月数据（贴表）：日活 52 万、7 日留存 31%、人均时长 23 分钟，目标分别是 55 万、33%、25 分钟。」 |
| 它问了你什么 | 先问复盘给谁看、有没有目标值和上期数据；数据里看不出原因的，会写成「需要进一步拆解」而不是硬猜。 |
| 它交付了什么 | 一句话总结「三项均未达标，留存差距最大」；记分卡 3 行标红黄绿；隐患 2 条（新用户 7 日留存降了 4 个百分点）；行动 3 条，例如「拆新老用户留存，内容运营负责，下周三前」。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**它给的「行业基准」能信吗？** 当参考即可。目标值一定用你们自己的历史数据和计划来定。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/metrics-review 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 除上述链接修正外保持上游原文，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `metrics-review`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 metrics-review 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `metrics-review`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，修正 1 处包外链接）：步骤、规矩、输出格式 |
| `CONNECTORS.md` | 上游原文：上游插件说明：`~~知识库` 这类占位符分别指哪类工具（只是说明，不含任何连接配置） |
| `LICENSE` | 上游许可证原文（Apache-2.0），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `e050c2e` 版本，新增中文 README。
