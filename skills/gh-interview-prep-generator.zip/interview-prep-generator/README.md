# 面试准备：从简历生成 STAR 故事库和练习题（gh-interview-prep-generator）

免费下载，装上即用。用途：面试准备：从简历生成 STAR 故事库和练习题。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 个人成长 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Resume Skills（Paramchoudhary） · 来源：GitHub Paramchoudhary/ResumeSkills（skills/interview-prep-generator）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
面试被问「讲一个你推动跨部门的例子」，临场想到哪说到哪，3 分钟没说到结果。

### 适合谁
准备产品经理面试、跳槽或转岗的人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 有简历和目标岗位，要提前准备行为面试故事<br>要一份按类别分好的练习题和反问面试官的问题 | 要按岗位改简历 → 用 resume-match-jd<br>要模拟面试、被追问并打分 → 用 gh-mock-interviewer<br>简历里的句子要改写 → 用 gh-resume-bullet-writer |

### 用前 / 用后
**用前：** 准备面试只是把简历背熟，被问「失败经历」时讲成了「我太追求完美」。

**用后：** 先分析岗位要的能力；把简历每段经历对到能力上，写成 STAR 故事（情境、任务、行动、结果，结果带数字）；每个故事准备长短两个版本；给出行为题、岗位题、常规题三类练习题，以及问用人经理和问同事的反问清单。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `interview-prep-generator/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-interview-prep-generator.zip -o /tmp/gh-interview-prep-generator.zip && unzip -oq /tmp/gh-interview-prep-generator.zip -d ~/.claude/skills/ && rm /tmp/gh-interview-prep-generator.zip
```

```powershell
$z="$env:TEMP\gh-interview-prep-generator.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-interview-prep-generator.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/interview-prep-generator` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-interview-prep-generator.zip -o /tmp/gh-interview-prep-generator.zip && unzip -oq /tmp/gh-interview-prep-generator.zip -d ~/.agents/skills/ && rm /tmp/gh-interview-prep-generator.zip
```

```powershell
$z="$env:TEMP\gh-interview-prep-generator.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-interview-prep-generator.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$interview-prep-generator` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-interview-prep-generator.zip -o /tmp/gh-interview-prep-generator.zip && unzip -oq /tmp/gh-interview-prep-generator.zip -d ~/.cursor/skills/ && rm /tmp/gh-interview-prep-generator.zip
```

```powershell
$z="$env:TEMP\gh-interview-prep-generator.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-interview-prep-generator.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `interview-prep-generator`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-interview-prep-generator.zip -o /tmp/gh-interview-prep-generator.zip && unzip -oq /tmp/gh-interview-prep-generator.zip -d ~/.gemini/skills/ && rm /tmp/gh-interview-prep-generator.zip
```

```powershell
$z="$env:TEMP\gh-interview-prep-generator.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-interview-prep-generator.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我根据简历准备面试故事」
- 「下周面产品经理，帮我出一份练习题」
- 「把我这段经历整理成 STAR 格式」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 贴上简历和目标岗位描述，说「B 端 SaaS 产品经理，3 年经验，下周二面」。 |
| 它问了你什么 | 先问目标岗位的级别和面试轮次；简历里结果不清楚的经历，会追问「最后的数字是多少」。 |
| 它交付了什么 | 能力—经历对照表 6 行；STAR 故事 6 个（如「推动权限系统重构」：结果写成「配置工单下降 40%」）；练习题 20 道分三类；反问 8 个。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**原文的例子偏海外公司？** 方法通用。说「按国内互联网公司面试来准备」即可。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `interview-prep-generator`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 interview-prep-generator 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `interview-prep-generator`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `74ae19e` 版本，新增中文 README。
