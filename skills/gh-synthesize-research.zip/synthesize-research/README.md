# 用户研究汇总：访谈、问卷、反馈归成洞察（gh-synthesize-research）

免费下载，装上即用。用途：用户研究汇总：访谈、问卷、反馈归成洞察。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 发现需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10）：在本机命令行 AI 里项目级安装真跑，访谈综合请求 1/1 自动调用、问概念时不调用；装后 89 分、不装 62 分：频次计数全对、7 处原话一字不差，不装的版本把一个主题的频次多算了 1 人。详见 AI 测评与指南《又装了 5 个站内 Skill》

> 原作者：Anthropic · 来源：GitHub anthropics/knowledge-work-plugins（product-management/skills/synthesize-research）· 许可证：Apache-2.0 · 老岳AI编辑部 中文整理与实测。上游文件除下述链接修正外原样保留，本 README 由编辑部撰写；这不是本站自制的 Skill。 编辑部修正了 1 处指向原仓库其他文件的链接，其余内容保持原样

## 用处

### 解决什么问题
12 份访谈、一份问卷、300 条客服反馈，整理了一周，最后只剩几句「用户希望更方便」。

### 适合谁
要汇总多份用户研究材料、给出结论和建议的产品经理、用户研究员。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 手上有多份访谈记录、问卷结果、反馈，要归成主题和洞察<br>每条洞察要带证据、出现频次和可信度 | 只整理单份访谈 → 用 gh-summarize-interview<br>还没做研究 → 用 gh-interview-script<br>要排需求优先级 → 用 gh-analyze-feature-requests |

### 用前 / 用后
**用前：** 汇总报告把「3 个人提到」和「1 个人提到」写成同样分量的结论。

**用后：** 先逐条提取观察、原话、行为、痛点、亮点；再按「频次 × 影响」四格分主题；每条发现写一句结论、证据（原话或数据，标来源）、几个人支持、影响多大、可信度高中低；最后给用户分群、机会点、建议和待解答问题。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `synthesize-research/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-synthesize-research.zip -o /tmp/gh-synthesize-research.zip && unzip -oq /tmp/gh-synthesize-research.zip -d ~/.claude/skills/ && rm /tmp/gh-synthesize-research.zip
```

```powershell
$z="$env:TEMP\gh-synthesize-research.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-synthesize-research.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/synthesize-research` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-synthesize-research.zip -o /tmp/gh-synthesize-research.zip && unzip -oq /tmp/gh-synthesize-research.zip -d ~/.agents/skills/ && rm /tmp/gh-synthesize-research.zip
```

```powershell
$z="$env:TEMP\gh-synthesize-research.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-synthesize-research.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$synthesize-research` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-synthesize-research.zip -o /tmp/gh-synthesize-research.zip && unzip -oq /tmp/gh-synthesize-research.zip -d ~/.cursor/skills/ && rm /tmp/gh-synthesize-research.zip
```

```powershell
$z="$env:TEMP\gh-synthesize-research.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-synthesize-research.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `synthesize-research`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-synthesize-research.zip -o /tmp/gh-synthesize-research.zip && unzip -oq /tmp/gh-synthesize-research.zip -d ~/.gemini/skills/ && rm /tmp/gh-synthesize-research.zip
```

```powershell
$z="$env:TEMP\gh-synthesize-research.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-synthesize-research.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`CONNECTORS.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我汇总这些用户访谈」
- 「把访谈和问卷结果整理成研究结论」
- 「这些用户反馈里有哪些主要问题」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「SaaS 报销工具，贴上 12 份访谈速记和 1 份 200 人问卷结果，研究问题是『为什么月底报销拖延』。」 |
| 它问了你什么 | 先确认研究问题和材料清单；没标用户类型的访谈，会问是员工还是财务。 |
| 它交付了什么 | 5 条主要发现，例如「贴票据最耗时（12 人中 9 人提到，问卷 61% 选择），可信度高」；用户分 3 群；机会点 4 个；待解答问题 3 个。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**能直接上传录音吗？** 先转成文字再贴；材料里有客户真名、手机号的，先替换掉。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/synthesize-research 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 除上述链接修正外保持上游原文，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `synthesize-research`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 synthesize-research 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `synthesize-research`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，修正 1 处包外链接）：步骤、规矩、输出格式 |
| `CONNECTORS.md` | 上游原文：上游插件说明：`~~知识库` 这类占位符分别指哪类工具（只是说明，不含任何连接配置） |
| `LICENSE` | 上游许可证原文（Apache-2.0），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `e050c2e` 版本，新增中文 README。
