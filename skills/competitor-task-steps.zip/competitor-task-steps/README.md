# 竞品按任务比步数（competitor-task-steps）

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10）：在本机命令行 AI 里项目级安装真跑，「做个竞品分析、数数各走几步」1/1 自动调用、只要产品介绍时不调用；装后 94 分、不装 72 分：每条结论都标了已确认 / 待实测，识别出一份材料过时，给了「不学」建议，还列了 5 条待实测清单。代价是慢一倍多。详见 AI 测评与指南《又装了 5 个站内 Skill》

## 用处

### 解决什么问题
竞品报告变成功能清单对功能清单，十页纸，数字没出处，老板一句「这个准吗」答不上来。

### 适合谁
被要竞品对比的产品经理；要优化某个流程、想看别人怎么做的人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 比 2–3 个产品完成同一个任务的路径<br>手上有截图、官网文字、更新日志这些材料 | 只要介绍某一个产品<br>要市场规模、融资、行业格局<br>没有任何材料又不能联网 |

### 用前 / 用后
**用前：** 搜一圈拼成十页文档，功能清单对功能清单，数字没有出处。老板一句「这个准吗」答不上来。

**用后：** 一页纸：第一行「学 A 的常买清单，不学它默认后天送」；路径表 A 16 下、B 28 下（示例），每步标「待实测」，提醒自己拿手机点一遍；截图没拍到的那步写「截图未覆盖」，没有被补成一句看起来很像的话。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `competitor-task-steps/` 文件夹，里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/competitor-task-steps.zip -o /tmp/competitor-task-steps.zip && unzip -oq /tmp/competitor-task-steps.zip -d ~/.claude/skills/ && rm /tmp/competitor-task-steps.zip
```

```powershell
$z="$env:TEMP\competitor-task-steps.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/competitor-task-steps.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/competitor-task-steps` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/competitor-task-steps.zip -o /tmp/competitor-task-steps.zip && unzip -oq /tmp/competitor-task-steps.zip -d ~/.agents/skills/ && rm /tmp/competitor-task-steps.zip
```

```powershell
$z="$env:TEMP\competitor-task-steps.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/competitor-task-steps.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$competitor-task-steps` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/competitor-task-steps.zip -o /tmp/competitor-task-steps.zip && unzip -oq /tmp/competitor-task-steps.zip -d ~/.cursor/skills/ && rm /tmp/competitor-task-steps.zip
```

```powershell
$z="$env:TEMP\competitor-task-steps.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/competitor-task-steps.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `competitor-task-steps`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/competitor-task-steps.zip -o /tmp/competitor-task-steps.zip && unzip -oq /tmp/competitor-task-steps.zip -d ~/.gemini/skills/ && rm /tmp/competitor-task-steps.zip
```

```powershell
$z="$env:TEMP\competitor-task-steps.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/competitor-task-steps.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；步骤里提到的模板文件（`templates/` 下）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我做个竞品分析，对比 A 和 B 的下单流程」
- 「按『店长晚上补货』这个任务比一下这两个 App」
- 「这是两个产品的截图，帮我数数各走几步」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「按『店长晚上补第二天的货』这个任务，比一下 A 和 B。」并按「A_01_首页」的名字顺序上传截图。 |
| 它问了你什么 | 先让你一句话说清任务：谁、什么时候、做什么、看到什么算完成；然后核对两个产品的版本和定位，找不到的写「未找到」。 |
| 它交付了什么 | 一页报告：第一行结论「学 A 的常买清单，不学它默认后天送」；路径表 A 16 下、B 28 下（示例），全部标「待实测」提醒你自己点一遍；截图没拍到的那步写「截图未覆盖」（见 `examples/示例_补货任务.md`）。 |

### 常见问题
**说了触发说法，它没反应怎么办？** 先确认文件夹名和 `SKILL.md` 第二行 `name:` 一致、放对了目录（见上面「安装」里你用的那个 AI）、新开了对话。还不行，直接说「用 competitor-task-steps 这个 Skill」点名调用；或者把你平时的说法加进 `SKILL.md` 开头 `description:` 那一行里——它只靠这一行判断要不要出场。

**怎么改成自己团队的版本？** 不要一上来就大改。先照原样用 3 次，每次把它的产出和你手改后的版本都存下来，然后让 AI 对比两版、说出你改动背后的规则，把规则写进 `SKILL.md` 的步骤或「不要做」里；模板换成你们团队的格式，放进 `templates/` 覆盖同名文件即可。改完在 README「更新记录」里写一行。

**为什么点击数都标「待实测」？** 截图是 AI 数的，可能漏了弹窗。你自己拿手机点一遍，对上了再改成「已确认」。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 定任务 + 四步流程、自查 |
| `templates/材料清单.md` | 动手前备料清单、截图命名规则 |
| `templates/任务路径表.md` | 空白路径表 |
| `templates/报告.html` | 一页网页报告样式（离线可开） |
| `examples/示例_补货任务.md` | 示例产出（虚构） |

## 更新记录
- v1.0（2026-11-09）：首发。
- v1.0（2026-11-09）：README 改为「用处 / 用法」结构，补完整使用示例与常见问题。
- v1.0（2026-11-09）：安装改为按平台分节、给可复制命令（下载地址为上线前占位）。
- v1.0（2026-11-09）：安装补齐 4 个平台的命令（目录按产品技术部核实）。
