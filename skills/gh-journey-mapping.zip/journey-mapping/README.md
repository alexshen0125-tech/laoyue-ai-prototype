# 用户旅程图、服务蓝图与共情图（gh-journey-mapping）

免费下载，装上即用。用途：用户旅程图、服务蓝图与共情图。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 发现需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Carlos C.（cuellarfr） · 来源：GitHub cuellarfr/design-skills（skills/journey-mapping）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
新商家入驻要走 7 个环节、跨 4 个部门，每个部门只看到自己那段，没人知道商家在哪一步最想放弃。

### 适合谁
要梳理用户全流程体验、找体验断点的产品经理和设计师。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 要画用户旅程图（阶段、行为、想法、情绪、触点、机会）<br>要画服务蓝图，看清前台、后台和支撑系统怎么配合<br>要拉团队开对齐会 | 只画系统流程和审批 → 用 gh-process-mapper<br>还没有调研材料 → 先用 gh-interview-script |

### 用前 / 用后
**用前：** 旅程图做成了一张漂亮的海报，没有标关键时刻，也没对应到任何改进项。

**用后：** 先帮你选图（旅程图、服务蓝图、体验图、共情图各适合什么）；按发起、调研、绘制、对齐四步走；旅程图必备阶段、行为、想法、情绪曲线、触点和机会；蓝图写五条泳道和三条线（用户能看到的、内部互动、支撑）；标出关键时刻并给出设计建议，附对齐会开法。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `journey-mapping/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-journey-mapping.zip -o /tmp/gh-journey-mapping.zip && unzip -oq /tmp/gh-journey-mapping.zip -d ~/.claude/skills/ && rm /tmp/gh-journey-mapping.zip
```

```powershell
$z="$env:TEMP\gh-journey-mapping.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-journey-mapping.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/journey-mapping` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-journey-mapping.zip -o /tmp/gh-journey-mapping.zip && unzip -oq /tmp/gh-journey-mapping.zip -d ~/.agents/skills/ && rm /tmp/gh-journey-mapping.zip
```

```powershell
$z="$env:TEMP\gh-journey-mapping.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-journey-mapping.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$journey-mapping` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-journey-mapping.zip -o /tmp/gh-journey-mapping.zip && unzip -oq /tmp/gh-journey-mapping.zip -d ~/.cursor/skills/ && rm /tmp/gh-journey-mapping.zip
```

```powershell
$z="$env:TEMP\gh-journey-mapping.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-journey-mapping.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `journey-mapping`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-journey-mapping.zip -o /tmp/gh-journey-mapping.zip && unzip -oq /tmp/gh-journey-mapping.zip -d ~/.gemini/skills/ && rm /tmp/gh-journey-mapping.zip
```

```powershell
$z="$env:TEMP\gh-journey-mapping.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-journey-mapping.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里另有 10 个参考文件，`SKILL.md` 里提到哪个就把哪个一起贴上。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我画一个用户旅程图」
- 「这个服务流程帮我做成服务蓝图」
- 「新用户从注册到首单的体验帮我梳理一下」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「B2B 平台新商家入驻：注册、资质审核、签约、上架、首单。附 6 份商家访谈摘要。」 |
| 它问了你什么 | 先问目的（找断点、对齐团队还是设计新流程）再推荐图的类型；访谈里没有情绪信息的阶段会标「待补」。 |
| 它交付了什么 | 一张旅程图（5 阶段 × 6 行），情绪最低点在资质审核（平均等待 4 天、无进度提示）；关键时刻 2 个；机会点 6 个；附一份服务蓝图，标出审核环节的后台交接。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**能出图片吗？** 它给的是结构化表格和画图写法，可以直接贴进白板、文档或交给设计师出图。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `journey-mapping`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 journey-mapping 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `journey-mapping`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `examples/cjm-walkthrough.md` | 上游原文：示例 |
| `examples/diagram-selection-scenarios.md` | 上游原文：示例 |
| `references/alignment-workshops.md` | 上游原文：参考资料 |
| `references/customer-journey-maps.md` | 上游原文：参考资料 |
| `references/experience-maps-and-models.md` | 上游原文：参考资料 |
| `references/flow-diagramming-visual-vocabulary.md` | 上游原文：参考资料 |
| `references/service-blueprints.md` | 上游原文：参考资料 |
| `templates/customer-journey-map-template.md` | 上游原文：可填写的模板 |
| `templates/empathy-map-template.md` | 上游原文：可填写的模板 |
| `templates/service-blueprint-template.md` | 上游原文：可填写的模板 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `7e25e66` 版本，新增中文 README。
