# 用 18 条质量标准体检需求（gh-make-requirements-great）

免费下载，装上即用。用途：用 18 条质量标准体检需求。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 定义需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：George Nurijanian · 来源：GitHub gnurio/nurijanian-skills（skills/make-requirements-great）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
需求写着「系统响应要快」「相关人员可查看」，研发、测试、业务三方各读出一个意思。

### 适合谁
写需求、审需求的产品经理和业务分析师。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 已有一批需求条目，想逐条查出含糊、合在一起、没人负责、没法测的地方<br>手上是会议记录、聊天记录，要整理成合格的需求条目 | 要从零写整份 PRD → 用 gh-write-spec<br>只要 Given/When/Then 验收 → 用 acceptance-criteria-br-ac<br>还在判断问题值不值得做 → 用 gh-problem-validation |

### 用前 / 用后
**用前：** 会员需求 12 条，有 3 条写着「体验友好」，2 条一句话里塞了三件事，没有一条写了谁来拍板。

**用后：** 先判断每条需求属于业务层、用户层还是方案层，按对应层级的标准审（不会逼业务层需求写出毫秒数）；输出缺陷清单（违反哪条标准、为什么）、逐条改写稿、「拆解时再定」的待决事项和一页术语表。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `make-requirements-great/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-make-requirements-great.zip -o /tmp/gh-make-requirements-great.zip && unzip -oq /tmp/gh-make-requirements-great.zip -d ~/.claude/skills/ && rm /tmp/gh-make-requirements-great.zip
```

```powershell
$z="$env:TEMP\gh-make-requirements-great.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-make-requirements-great.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/make-requirements-great` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-make-requirements-great.zip -o /tmp/gh-make-requirements-great.zip && unzip -oq /tmp/gh-make-requirements-great.zip -d ~/.agents/skills/ && rm /tmp/gh-make-requirements-great.zip
```

```powershell
$z="$env:TEMP\gh-make-requirements-great.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-make-requirements-great.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$make-requirements-great` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-make-requirements-great.zip -o /tmp/gh-make-requirements-great.zip && unzip -oq /tmp/gh-make-requirements-great.zip -d ~/.cursor/skills/ && rm /tmp/gh-make-requirements-great.zip
```

```powershell
$z="$env:TEMP\gh-make-requirements-great.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-make-requirements-great.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `make-requirements-great`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-make-requirements-great.zip -o /tmp/gh-make-requirements-great.zip && unzip -oq /tmp/gh-make-requirements-great.zip -d ~/.gemini/skills/ && rm /tmp/gh-make-requirements-great.zip
```

```powershell
$z="$env:TEMP\gh-make-requirements-great.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-make-requirements-great.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我检查这批需求写得合不合格」
- 「把这段会议记录整理成规范的需求条目」
- 「这些需求哪些写得含糊、没法测」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「会员积分改版的 12 条需求（贴上），帮我按标准体检一遍。」 |
| 它问了你什么 | 层级看不出来时只问一句：「这些是业务目标、用户诉求，还是给研发的方案描述？」 |
| 它交付了什么 | 缺陷清单 9 条，例如「积分到账要及时」违反「无歧义」「可测试」，改写为「订单完成后 10 分钟内积分到账，95% 订单满足」；1 条拆成 3 条；4 条缺负责人，标为最重要的发现。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**它把我的需求拆得太细了？** 原文专门写了「默认不拆」：只有一句里塞了两个意图、或你确认要写到方案层时才拆。觉得拆过头，直接说「保持业务层」。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `make-requirements-great`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 make-requirements-great 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `make-requirements-great`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `43a0566` 版本，新增中文 README。
