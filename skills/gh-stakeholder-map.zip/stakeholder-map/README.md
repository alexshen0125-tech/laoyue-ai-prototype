# 干系人地图与沟通计划（gh-stakeholder-map）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-execution/skills/stakeholder-map）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
项目做到一半，财务说「这事从来没人跟我说过」，直接卡住。

### 适合谁
跨部门推项目的产品经理、项目经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 项目启动或上线前，要理清谁说了算、谁会受影响<br>要定好多久跟谁同步一次、怎么同步 | 只是要写一次周报 → 用 gh-internal-comms<br>要管的是团队内部任务分工 |

### 用前 / 用后
**用前：** 只拉了研发和设计的群，上线前一周才发现客服、财务、区域运营都要跟着改流程。

**用后：** 一张「权力 × 关注度」四象限表；每个象限的沟通频率、方式、要说的话、被忽略的后果；一张沟通计划表；标出利益冲突的几方和对齐办法。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `stakeholder-map/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-stakeholder-map.zip -o /tmp/gh-stakeholder-map.zip && unzip -oq /tmp/gh-stakeholder-map.zip -d ~/.claude/skills/ && rm /tmp/gh-stakeholder-map.zip
```

```powershell
$z="$env:TEMP\gh-stakeholder-map.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-stakeholder-map.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/stakeholder-map` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-stakeholder-map.zip -o /tmp/gh-stakeholder-map.zip && unzip -oq /tmp/gh-stakeholder-map.zip -d ~/.agents/skills/ && rm /tmp/gh-stakeholder-map.zip
```

```powershell
$z="$env:TEMP\gh-stakeholder-map.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-stakeholder-map.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$stakeholder-map` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-stakeholder-map.zip -o /tmp/gh-stakeholder-map.zip && unzip -oq /tmp/gh-stakeholder-map.zip -d ~/.cursor/skills/ && rm /tmp/gh-stakeholder-map.zip
```

```powershell
$z="$env:TEMP\gh-stakeholder-map.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-stakeholder-map.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `stakeholder-map`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-stakeholder-map.zip -o /tmp/gh-stakeholder-map.zip && unzip -oq /tmp/gh-stakeholder-map.zip -d ~/.gemini/skills/ && rm /tmp/gh-stakeholder-map.zip
```

```powershell
$z="$env:TEMP\gh-stakeholder-map.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-stakeholder-map.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我做一份干系人地图」
- 「这个项目要跟哪些人沟通、多久一次」
- 「项目要跨部门推，帮我出个沟通计划」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「项目：门店再来一单，涉及研发、设计、区域运营、客服、财务结算，还有两家大客户。帮我做干系人地图。」 |
| 它问了你什么 | 你没提到的常见角色（法务、销售）它会按经验补上，你删掉不相关的即可。 |
| 它交付了什么 | 四象限表（区域运营总监＝重点管理，每周一对一；客服＝保持知情，上线前培训）；沟通计划表 8 行；冲突 1 条：运营想默认勾选全部商品，财务担心误订退货，建议先用数据对齐。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**沟通渠道写的是海外常用工具？** 换成你们公司的群、邮件、周会即可，地图本身不依赖工具。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/stakeholder-map 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `stakeholder-map`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 stakeholder-map 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `stakeholder-map`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
