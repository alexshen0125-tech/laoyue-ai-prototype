# 产品分析：按阶段选指标，算留存、同期群和漏斗（gh-product-analytics）

免费下载，装上即用。用途：产品分析：按阶段选指标，算留存、同期群和漏斗。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 上线验证 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Alireza Rezvani · 来源：GitHub alirezarezvani/claude-skills（product-team/skills/product-analytics）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
不同阶段的产品用同一套指标，早期产品天天看收入，成熟产品还在盯注册数。

### 适合谁
要选指标、搭看板、算留存和漏斗的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 要按产品阶段（找到市场前 / 增长期 / 成熟期）选关键指标<br>手上有 CSV，要快速算留存、同期群、漏斗转化 | 要定唯一的北极星 → 用 gh-north-star-metric<br>要设计看板布局与告警 → 用 gh-metrics-dashboard |

### 用前 / 用后
**用前：** 漏斗转化在表格里手算，四个环节算错了一个分母，周会上被当场指出。

**用后：** 先选框架（增长漏斗 / 北极星 / 体验质量）；按阶段给关键指标；看板分高管层、产品健康层、功能层；留存看曲线不看单点；每个指标配目标、阈值和触发的动作。包里附一个小脚本，从 CSV 算留存、同期群表和漏斗。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `product-analytics/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-product-analytics.zip -o /tmp/gh-product-analytics.zip && unzip -oq /tmp/gh-product-analytics.zip -d ~/.claude/skills/ && rm /tmp/gh-product-analytics.zip
```

```powershell
$z="$env:TEMP\gh-product-analytics.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-product-analytics.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/product-analytics` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-product-analytics.zip -o /tmp/gh-product-analytics.zip && unzip -oq /tmp/gh-product-analytics.zip -d ~/.agents/skills/ && rm /tmp/gh-product-analytics.zip
```

```powershell
$z="$env:TEMP\gh-product-analytics.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-product-analytics.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$product-analytics` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-product-analytics.zip -o /tmp/gh-product-analytics.zip && unzip -oq /tmp/gh-product-analytics.zip -d ~/.cursor/skills/ && rm /tmp/gh-product-analytics.zip
```

```powershell
$z="$env:TEMP\gh-product-analytics.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-product-analytics.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `product-analytics`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-product-analytics.zip -o /tmp/gh-product-analytics.zip && unzip -oq /tmp/gh-product-analytics.zip -d ~/.gemini/skills/ && rm /tmp/gh-product-analytics.zip
```

```powershell
$z="$env:TEMP\gh-product-analytics.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-product-analytics.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`references/dashboard-templates.md`、`references/metrics-frameworks.md`、`scripts/metrics_calculator.py`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「我们这个阶段该看哪些指标」
- 「这份 CSV 帮我算一下漏斗转化」
- 「按注册周帮我算同期群留存」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「工具类 SaaS，刚找到第一批付费客户。这是注册→创建项目→邀请成员→付费的事件表（CSV），帮我算漏斗，并告诉我现阶段看哪些指标。」 |
| 它问了你什么 | 先确认产品阶段和 CSV 里的列名（用户、环节、日期各叫什么）。 |
| 它交付了什么 | 现阶段指标 4 个（激活率、第 1 周留存、首次见效时长、访谈问题契合度）；漏斗：注册 2,000 → 创建项目 1,240（62%）→ 邀请成员 410（33%）→ 付费 96（23%），最大流失在邀请环节；建议一个对应动作。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**包里的脚本安全吗？** 只有一个 Python 小脚本，只用自带库，只读你指定的 CSV，结果打印在屏幕上，不联网、不写文件。能运行代码的工具会先问你；网页版它按同样公式手算。

**脚本要求列名叫什么？** 默认 `user_id`、`cohort_date`、`activity_date`、`stage`，你的列名不同时可以在命令里改，它会帮你写好命令。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `product-analytics`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 product-analytics 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `product-analytics`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `references/dashboard-templates.md` | 上游原文：看板模板 |
| `references/metrics-frameworks.md` | 上游原文：指标框架说明 |
| `scripts/metrics_calculator.py` | 上游原文：从 CSV 算留存、同期群和漏斗（只读本地文件，不联网） |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `8f08254` 版本，新增中文 README。
