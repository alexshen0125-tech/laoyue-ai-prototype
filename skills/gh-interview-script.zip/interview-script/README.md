# 用户访谈提纲（不诱导）（gh-interview-script）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-product-discovery/skills/interview-script）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。 编辑部按 MIT 许可删除了原文末的课程推广链接，其余内容保持原样。

## 用处

### 解决什么问题
访谈时问「你想要什么功能」，用户什么都想要；或者聊着聊着变成推销自己的方案。

### 适合谁
要做用户访谈、需求调研的产品经理、用户研究员。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 约好了访谈，要一份开场—热身—核心—收尾的提纲<br>需要一张统一的访谈记录模板 | 访谈已经做完要整理 → 用 gh-summarize-interview<br>要发大规模问卷<br>要做可用性测试 |

### 用前 / 用后
**用前：** 问店长「如果有一键再来一单你会用吗」，对方说「会啊挺好」，上线后几乎没人用。

**用后：** 一份 30 分钟的提纲：问的都是「上一次你补货是怎么做的」这种过去发生的具体事，没有「你会不会用」；附 5 种追问话术和一张记录模板（要完成的事、现在的办法、最大的痛点、意外发现）。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `interview-script/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-interview-script.zip -o /tmp/gh-interview-script.zip && unzip -oq /tmp/gh-interview-script.zip -d ~/.claude/skills/ && rm /tmp/gh-interview-script.zip
```

```powershell
$z="$env:TEMP\gh-interview-script.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-interview-script.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/interview-script` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-interview-script.zip -o /tmp/gh-interview-script.zip && unzip -oq /tmp/gh-interview-script.zip -d ~/.agents/skills/ && rm /tmp/gh-interview-script.zip
```

```powershell
$z="$env:TEMP\gh-interview-script.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-interview-script.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$interview-script` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-interview-script.zip -o /tmp/gh-interview-script.zip && unzip -oq /tmp/gh-interview-script.zip -d ~/.cursor/skills/ && rm /tmp/gh-interview-script.zip
```

```powershell
$z="$env:TEMP\gh-interview-script.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-interview-script.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `interview-script`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-interview-script.zip -o /tmp/gh-interview-script.zip && unzip -oq /tmp/gh-interview-script.zip -d ~/.gemini/skills/ && rm /tmp/gh-interview-script.zip
```

```powershell
$z="$env:TEMP\gh-interview-script.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-interview-script.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我准备一份用户访谈提纲」
- 「下周访谈 5 个店长，问题怎么问才不诱导」
- 「给我一份访谈记录模板」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「下周访谈 5 个连锁店店长，想弄清他们每晚怎么补货、卡在哪，每人 30 分钟。」 |
| 它问了你什么 | 先问三件事：这次要回答什么问题、结果会影响哪个决定、要验证哪些假设。 |
| 它交付了什么 | 分段提纲（开场 3 分钟、热身 5 分钟、核心 20 分钟、收尾 3 分钟）、5 种追问话术、「只问过去不问将来」等 6 条规矩，以及一张记录模板。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**「付费意愿」那段对 B 端不合适？** 改成「现在每周花多少时间在这件事上」「为此用过什么别的办法」即可，原文本来就是问投入而不是问「你愿意付多少」。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/interview-script 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `interview-script`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 interview-script 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `interview-script`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
