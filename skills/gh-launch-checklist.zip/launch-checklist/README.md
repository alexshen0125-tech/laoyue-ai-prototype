# 上线就绪清单：各部门检查项、放行标准、回滚（gh-launch-checklist）

免费下载，装上即用。用途：上线就绪清单：各部门检查项、放行标准、回滚。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 推进落地 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：aroyburman-codes · 来源：GitHub aroyburman-codes/pm-skills（skills/launch-checklist）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
上线当天客服才知道有新功能，法务说隐私协议没改，最后半夜回滚。

### 适合谁
负责版本上线、要协调多个部门的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 上线前要一份按部门列好的检查清单<br>要定清放行标准和回滚方案<br>上线的是 AI 功能（会额外列评测、安全检查项） | 要业务方验收计划 → 用 gh-uat-plan<br>要做上线前风险推演 → 用 gh-pre-mortem |

### 用前 / 用后
**用前：** 上线清单只有研发和测试两栏，灰度、回滚、客服培训都没人管。

**用后：** 先定上线规模（开关灰度、公测、全量）；按研发、测试、设计、法务、市场、客服等部门生成检查项；写清放行和不放行的标准；写回滚方案（触发条件、谁拍板、多久内回滚）；AI 功能另加评测通过线、内容安全、成本监控。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `launch-checklist/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-launch-checklist.zip -o /tmp/gh-launch-checklist.zip && unzip -oq /tmp/gh-launch-checklist.zip -d ~/.claude/skills/ && rm /tmp/gh-launch-checklist.zip
```

```powershell
$z="$env:TEMP\gh-launch-checklist.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-launch-checklist.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/launch-checklist` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-launch-checklist.zip -o /tmp/gh-launch-checklist.zip && unzip -oq /tmp/gh-launch-checklist.zip -d ~/.agents/skills/ && rm /tmp/gh-launch-checklist.zip
```

```powershell
$z="$env:TEMP\gh-launch-checklist.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-launch-checklist.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$launch-checklist` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-launch-checklist.zip -o /tmp/gh-launch-checklist.zip && unzip -oq /tmp/gh-launch-checklist.zip -d ~/.cursor/skills/ && rm /tmp/gh-launch-checklist.zip
```

```powershell
$z="$env:TEMP\gh-launch-checklist.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-launch-checklist.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `launch-checklist`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-launch-checklist.zip -o /tmp/gh-launch-checklist.zip && unzip -oq /tmp/gh-launch-checklist.zip -d ~/.gemini/skills/ && rm /tmp/gh-launch-checklist.zip
```

```powershell
$z="$env:TEMP\gh-launch-checklist.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-launch-checklist.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我列一份上线检查清单」
- 「这个功能下周灰度，上线前要准备什么」
- 「帮我写回滚方案」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「SaaS 产品下周灰度 AI 智能回复功能，先开 10% 客户。」 |
| 它问了你什么 | 先问上线规模和涉及的部门；是 AI 功能就会追问有没有评测结果。 |
| 它交付了什么 | 清单 6 个部门共 28 项（如「客服：上线前 2 天完成话术培训」「AI：拒答率和单次成本告警已配置」）；放行标准 5 条；回滚方案：错误率超 2% 或投诉 5 起即关开关，产品负责人拍板，15 分钟内完成。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**清单太长了？** 告诉它上线规模是「小功能开关灰度」，它会缩到关键项。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `launch-checklist`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 launch-checklist 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `launch-checklist`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `f879de8` 版本，新增中文 README。
