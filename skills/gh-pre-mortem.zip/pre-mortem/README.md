# 上线前事前验尸（gh-pre-mortem）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-execution/skills/pre-mortem）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
上线前大家都说「没问题」，真上线了才发现，有人早就担心的事从头到尾没人提。

### 适合谁
要对一次上线或大版本负责的产品经理、项目负责人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 上线前两周左右，PRD 或上线计划已经有了<br>想把团队的顾虑摊开，分出哪些必须上线前解决 | 还没有方案 → 先用 prd-step-by-step<br>只想挑 PRD 写得哪里不清楚 → 用 prd-four-role-review<br>要攻击的是战略层面的假设 → 用 gh-strategy-red-team |

### 用前 / 用后
**用前：** 上线评审会上问「还有风险吗」，全场沉默；上线第 3 天客服电话打爆，原来运营早就担心短信额度不够，只是没人问。

**用后：** 拿到三栏清单：真风险（原文叫「老虎」）、被夸大的担心（「纸老虎」）、没人提的隐患（「房间里的大象」）；真风险再分「上线前必须解决 / 上线 30 天内解决 / 先观察」，每个必须解决的都有对策、负责人和日期。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `pre-mortem/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-pre-mortem.zip -o /tmp/gh-pre-mortem.zip && unzip -oq /tmp/gh-pre-mortem.zip -d ~/.claude/skills/ && rm /tmp/gh-pre-mortem.zip
```

```powershell
$z="$env:TEMP\gh-pre-mortem.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-pre-mortem.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/pre-mortem` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-pre-mortem.zip -o /tmp/gh-pre-mortem.zip && unzip -oq /tmp/gh-pre-mortem.zip -d ~/.agents/skills/ && rm /tmp/gh-pre-mortem.zip
```

```powershell
$z="$env:TEMP\gh-pre-mortem.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-pre-mortem.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$pre-mortem` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-pre-mortem.zip -o /tmp/gh-pre-mortem.zip && unzip -oq /tmp/gh-pre-mortem.zip -d ~/.cursor/skills/ && rm /tmp/gh-pre-mortem.zip
```

```powershell
$z="$env:TEMP\gh-pre-mortem.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-pre-mortem.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `pre-mortem`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-pre-mortem.zip -o /tmp/gh-pre-mortem.zip && unzip -oq /tmp/gh-pre-mortem.zip -d ~/.gemini/skills/ && rm /tmp/gh-pre-mortem.zip
```

```powershell
$z="$env:TEMP\gh-pre-mortem.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-pre-mortem.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「这个上线计划帮我做一次事前验尸」
- 「假设两周后上线失败了，帮我倒推是哪些原因」
- 「上线前帮我把风险分成必须解决和可以后补的」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「下周四上线门店『再来一单』，这是上线计划（贴全文），帮我做一次 pre-mortem。」 |
| 它问了你什么 | 先读完计划，按「14 天后上线、结果失败了」往回推；计划里没写到的环节（短信额度、客服话术）会列成「大象」，请你确认是不是真的没人跟进。 |
| 它交付了什么 | 一份清单：老虎 4 条，其中「下架商品跳过逻辑没联调」标上线前必须解决（对策：联调加回归；负责人：研发负责人；日期：上线前 3 天）；纸老虎 2 条，各附一句为什么不用太担心；大象 2 条，各附怎么查。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**它说要「匿名收集风险」，怎么做？** 原文推荐的是同仓库另一个 Skill，不在本包。用匿名问卷收一轮，把结果贴给它即可。

**它要把结果存成文件？** 原文默认存成 `PreMortem-产品名-日期.md`。能写文件的工具会照做；网页版直接在对话里给。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/pre-mortem 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `pre-mortem`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 pre-mortem 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `pre-mortem`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
