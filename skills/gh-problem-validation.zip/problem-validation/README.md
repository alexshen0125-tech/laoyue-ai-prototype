# 问题值不值得解决：四项打分（gh-problem-validation）

免费下载，装上即用。用途：问题值不值得解决：四项打分。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 发现需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Tair Asim · 来源：GitHub assimovt/productskills（skills/problem-validation）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
「用户都说这个很痛」，做出来没人用，事后发现用户只是礼貌地附和。

### 适合谁
在立项前判断「这个问题值不值得做」的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 有一个想解决的用户问题，要用证据判断真不真、痛不痛<br>多个问题要比一比先做哪个 | 问题已经确认，要设计实验 → 用 gh-experiment-design<br>AI 项目立项评估 → 用 gh-assess-enterprise-ai-project |

### 用前 / 用后
**用前：** 凭 3 个用户说「会用」就立项，没问他们现在怎么解决、有没有花过钱。

**用后：** 按证据给四项各打 1–5 分：多常发生、多痛、用户已经在用什么土办法、愿不愿意付钱（「可能会付」要打折）；四项相乘：250 分以上做，100–249 分补证据，100 分以下换方向或放弃；附怎么补证据的建议。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `problem-validation/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-problem-validation.zip -o /tmp/gh-problem-validation.zip && unzip -oq /tmp/gh-problem-validation.zip -d ~/.claude/skills/ && rm /tmp/gh-problem-validation.zip
```

```powershell
$z="$env:TEMP\gh-problem-validation.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-problem-validation.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/problem-validation` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-problem-validation.zip -o /tmp/gh-problem-validation.zip && unzip -oq /tmp/gh-problem-validation.zip -d ~/.agents/skills/ && rm /tmp/gh-problem-validation.zip
```

```powershell
$z="$env:TEMP\gh-problem-validation.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-problem-validation.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$problem-validation` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-problem-validation.zip -o /tmp/gh-problem-validation.zip && unzip -oq /tmp/gh-problem-validation.zip -d ~/.cursor/skills/ && rm /tmp/gh-problem-validation.zip
```

```powershell
$z="$env:TEMP\gh-problem-validation.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-problem-validation.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `problem-validation`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-problem-validation.zip -o /tmp/gh-problem-validation.zip && unzip -oq /tmp/gh-problem-validation.zip -d ~/.gemini/skills/ && rm /tmp/gh-problem-validation.zip
```

```powershell
$z="$env:TEMP\gh-problem-validation.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-problem-validation.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「这个问题值不值得做」
- 「帮我验证一下这个用户痛点是不是真的」
- 「这几个问题先解决哪个」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「餐饮门店老板每晚手工对账要 1 小时，想做自动对账。访谈了 8 家店。」 |
| 它问了你什么 | 每一项都会追问证据：「8 家里几家每天都对账？有人花钱请人做吗？」 |
| 它交付了什么 | 频率 5、痛感 4、土办法 4（表格加手工核对）、付费意愿 3（只是口头说会付）= 240 分，结论「有希望，补付费证据」；建议做一个预售或人工代对账服务测付费。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**分数是不是太机械？** 是个快速判断工具。分数靠证据打，没证据的那项默认往低打，比拍脑袋好。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `problem-validation`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 problem-validation 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `problem-validation`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `66f9cee` 版本，新增中文 README。
