# A/B 实验设计：假设、主指标、护栏、样本量（gh-experiment-design）

免费下载，装上即用。用途：A/B 实验设计：假设、主指标、护栏、样本量。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 上线验证 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Tair Asim · 来源：GitHub assimovt/productskills（skills/experiment-design）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
实验开了才想「看什么指标」，跑了 4 天看到显著就停，下个月效果全没了。

### 适合谁
要设计 A/B 实验、验证改动效果的产品经理和增长同学。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 实验开始前，写假设、定主指标和护栏指标<br>算要多少样本、跑多久，判断值不值得做 | 实验已经跑完要看结果 → 用 gh-ab-test-analysis<br>还在找该验证什么 → 用 gh-strategy-red-team |

### 用前 / 用后
**用前：** 「改版新手引导，看看效果」——没写假设，主指标列了 5 个，跑 4 天就停。

**用后：** 按模板写假设：「如果对 [人群] 做 [具体改动]，[指标] 会 [方向] [幅度]，因为 [证据]」；只定 1 个主指标，另列护栏指标；开跑前算样本量（基线、最小可检测变化、95% 显著、80% 功效）；至少跑满 7 天；提前写好赢、输、不确定各怎么办；附偷看结果、样本不足、一次改太多等常见错误。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `experiment-design/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-experiment-design.zip -o /tmp/gh-experiment-design.zip && unzip -oq /tmp/gh-experiment-design.zip -d ~/.claude/skills/ && rm /tmp/gh-experiment-design.zip
```

```powershell
$z="$env:TEMP\gh-experiment-design.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-experiment-design.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/experiment-design` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-experiment-design.zip -o /tmp/gh-experiment-design.zip && unzip -oq /tmp/gh-experiment-design.zip -d ~/.agents/skills/ && rm /tmp/gh-experiment-design.zip
```

```powershell
$z="$env:TEMP\gh-experiment-design.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-experiment-design.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$experiment-design` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-experiment-design.zip -o /tmp/gh-experiment-design.zip && unzip -oq /tmp/gh-experiment-design.zip -d ~/.cursor/skills/ && rm /tmp/gh-experiment-design.zip
```

```powershell
$z="$env:TEMP\gh-experiment-design.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-experiment-design.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `experiment-design`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-experiment-design.zip -o /tmp/gh-experiment-design.zip && unzip -oq /tmp/gh-experiment-design.zip -d ~/.gemini/skills/ && rm /tmp/gh-experiment-design.zip
```

```powershell
$z="$env:TEMP\gh-experiment-design.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-experiment-design.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我设计一个 A/B 实验」
- 「这个改动要怎么验证效果」
- 「这个实验要跑多久、要多少人」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「工具类 App，新手引导从 5 步改成 1 步带做，想看激活率。现在 7 日激活 23%，每周新用户约 8000。」 |
| 它问了你什么 | 先问依据是什么（访谈、数据还是直觉）；没有依据时，它会提醒「没有证据就先别做实验」。 |
| 它交付了什么 | 假设句 1 条（目标 23%→28%）；主指标 7 日激活率，护栏 2 个（次日留存、客服咨询量）；按基线和 5 个百分点的变化估算每组约需 1200 人，约跑 2 周；提前写好三种结果的处理。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**样本量是它算的还是估的？** 原文让用样本量计算器算。能运行代码的工具可以当场算；网页版会给出估算并写出公式，上线前建议用公司的实验平台再核一次。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `experiment-design`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 experiment-design 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `experiment-design`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `66f9cee` 版本，新增中文 README。
