# 把需求压成编码工具能直接照做的精简 PRD（gh-vibe-coding-prd）

免费下载，装上即用。用途：把需求压成编码工具能直接照做的精简 PRD。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 定义需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：fd0415 · 来源：GitHub fd0415/vibe-coding-prd（仓库根目录）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
拿一份写给老板看的 PRD 去让 AI 编程工具做原型，它被商业价值、市场分析带偏，做出来的东西和要的不一样。

### 适合谁
自己动手用 AI 编程工具做原型或小工具的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 手上是模糊想法、写给人看的传统 PRD 或一份竞品分析，要变成编码工具能照着写代码的版本<br>要把每条验收写成「点了 X 出现 Y」 | 要给研发评审用的完整 PRD → 用 gh-prd-writer 或 prd-step-by-step<br>只想一句话生成可点原型 → 用 one-line-html-prototype |

### 用前 / 用后
**用前：** 把 15 页 PRD 整份丢给编码工具，它花了大半精力在「市场规模」那几页上，核心表单反而漏了校验。

**用后：** 先判断你给的是哪类材料；传统 PRD 会删掉商业论证、KPI 汇报这类内容，只留影响实现的部分。然后分 6 块逐块和你确认：需求定义、功能清单（做 / 不做 / 以后再说）、技术栈建议、框架版原型、明细功能、验收标准，最后存成一份 `xxx-vibe-prd.md`。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `vibe-coding-prd/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-vibe-coding-prd.zip -o /tmp/gh-vibe-coding-prd.zip && unzip -oq /tmp/gh-vibe-coding-prd.zip -d ~/.claude/skills/ && rm /tmp/gh-vibe-coding-prd.zip
```

```powershell
$z="$env:TEMP\gh-vibe-coding-prd.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-vibe-coding-prd.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/vibe-coding-prd` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-vibe-coding-prd.zip -o /tmp/gh-vibe-coding-prd.zip && unzip -oq /tmp/gh-vibe-coding-prd.zip -d ~/.agents/skills/ && rm /tmp/gh-vibe-coding-prd.zip
```

```powershell
$z="$env:TEMP\gh-vibe-coding-prd.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-vibe-coding-prd.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$vibe-coding-prd` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-vibe-coding-prd.zip -o /tmp/gh-vibe-coding-prd.zip && unzip -oq /tmp/gh-vibe-coding-prd.zip -d ~/.cursor/skills/ && rm /tmp/gh-vibe-coding-prd.zip
```

```powershell
$z="$env:TEMP\gh-vibe-coding-prd.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-vibe-coding-prd.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `vibe-coding-prd`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-vibe-coding-prd.zip -o /tmp/gh-vibe-coding-prd.zip && unzip -oq /tmp/gh-vibe-coding-prd.zip -d ~/.gemini/skills/ && rm /tmp/gh-vibe-coding-prd.zip
```

```powershell
$z="$env:TEMP\gh-vibe-coding-prd.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-vibe-coding-prd.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我写一份给编码工具用的 PRD」
- 「把这份 PRD 精简成能直接拿去写代码的版本」
- 「这份竞品分析帮我转成要做的需求」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「想做个内部小工具：每周五自动把组里的周报汇总成一页。没有技术背景。」 |
| 它问了你什么 | 用选择题连着问：给谁用？最想解决哪件事？做成网页、小程序还是脚本？功能清单每一项「做 / 不做 / 以后再说」也逐项让你选。 |
| 它交付了什么 | 一份 6 节的精简 PRD：功能表 7 行（MVP 4 行）、推荐的一体化技术组合加 1 个备选、汇总页的区块描述、每个功能的数据和交互要点、12 条「当……时，……」验收。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**它总弹选择题让我点？** 原文要求凡是要替你做主的地方都先问你。你的工具没有弹题功能时，它会在对话里列出选项让你回复数字。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `vibe-coding-prd`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 vibe-coding-prd 这个 Skill」点名调用。这个 Skill 的原文本身就有中文说明，一般中文提问即可触发。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `vibe-coding-prd`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（中英混合，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `cd46732` 版本，新增中文 README。
