# 根因分析：5 个为什么加鱼骨图（gh-root-cause-analysis）

免费下载，装上即用。用途：根因分析：5 个为什么加鱼骨图。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 上线验证 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：qa-aman 及该仓库贡献者 · 来源：GitHub qa-aman/claude-skills（skills/by-role/business-analyst/root-cause-analysis）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
退款超时的问题修了三次又出现，每次复盘的结论都是「加强沟通」。

### 适合谁
要做问题复盘、事故分析、指标异常归因的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 同一个问题反复出现，要找真正的原因<br>线上事故或流程问题要复盘<br>要给老板一份讲得清因果的分析 | 复盘的是整个迭代 → 用 gh-retro<br>复盘的是自己在某次沟通里的表现 → 用 gh-situation-retrospective<br>要排查 AI 智能体的执行日志 → 用 gh-agent-trace-diagnoser |

### 用前 / 用后
**用前：** 问题写成「系统很慢」，5 个为什么问到第 2 层就停了，结论是「研发要优化」。

**用后：** 先把问题写成可量化的陈述（什么、哪里、何时、多大影响）；收集时间线、频率、范围、以前的修复；做 5 个为什么；用鱼骨图从人员、流程、技术、制度、环境、数据六类找原因；验证根因后给出对策和跟踪指标。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `root-cause-analysis/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-root-cause-analysis.zip -o /tmp/gh-root-cause-analysis.zip && unzip -oq /tmp/gh-root-cause-analysis.zip -d ~/.claude/skills/ && rm /tmp/gh-root-cause-analysis.zip
```

```powershell
$z="$env:TEMP\gh-root-cause-analysis.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-root-cause-analysis.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/root-cause-analysis` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-root-cause-analysis.zip -o /tmp/gh-root-cause-analysis.zip && unzip -oq /tmp/gh-root-cause-analysis.zip -d ~/.agents/skills/ && rm /tmp/gh-root-cause-analysis.zip
```

```powershell
$z="$env:TEMP\gh-root-cause-analysis.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-root-cause-analysis.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$root-cause-analysis` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-root-cause-analysis.zip -o /tmp/gh-root-cause-analysis.zip && unzip -oq /tmp/gh-root-cause-analysis.zip -d ~/.cursor/skills/ && rm /tmp/gh-root-cause-analysis.zip
```

```powershell
$z="$env:TEMP\gh-root-cause-analysis.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-root-cause-analysis.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `root-cause-analysis`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-root-cause-analysis.zip -o /tmp/gh-root-cause-analysis.zip && unzip -oq /tmp/gh-root-cause-analysis.zip -d ~/.gemini/skills/ && rm /tmp/gh-root-cause-analysis.zip
```

```powershell
$z="$env:TEMP\gh-root-cause-analysis.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-root-cause-analysis.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`references/fishbone-categories.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我分析一下这个问题的根本原因」
- 「用 5 个为什么帮我复盘这次事故」
- 「这个问题反复出现，帮我画个鱼骨图」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「电商售后：退款平均处理 4.2 小时，承诺是 2 小时，近 30 天 67% 的单超时。」 |
| 它问了你什么 | 先把问题陈述改到可量化，再问问题从什么时候开始、之前改过什么。 |
| 它交付了什么 | 5 个为什么一路问到「三个系统没有共用订单号，人工核对 90 分钟」；鱼骨图 6 类各 1–3 条；根因 1 个、促成因素 2 个；对策 3 条，各带负责人和要盯的指标。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**它给的根因一定对吗？** 它给的是候选。原文要求用数据验证根因后再定对策，别只靠推理。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `root-cause-analysis`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 root-cause-analysis 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `root-cause-analysis`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `references/fishbone-categories.md` | 上游原文：鱼骨图六类原因与示例 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `be4abcc` 版本，新增中文 README。
