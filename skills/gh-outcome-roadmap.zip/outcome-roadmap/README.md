# 功能路线图改成结果路线图（gh-outcome-roadmap）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-execution/skills/outcome-roadmap）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
路线图是一串功能名加日期，老板问「做完这些能带来什么」答不上；日期一延，整张图都没人信了。

### 适合谁
要做季度或年度路线图、向上汇报的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 手上是一份功能清单式的路线图<br>想改写成「让谁做到什么，从而带来什么业务结果」 | 方向还没定 → 用 gh-opportunity-solution-tree<br>要定 OKR → 用 gh-brainstorm-okrs<br>要排具体到天的甘特图 |

### 用前 / 用后
**用前：** 「二季度：高级筛选、智能推荐、首页改版」

**用后：** 「二季度：让店长 1 分钟内找到要补的货（找货时长减半）；让推荐带动客单价提升 20%；……」每条带衡量指标和依赖关系，时间只写到季度。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `outcome-roadmap/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-outcome-roadmap.zip -o /tmp/gh-outcome-roadmap.zip && unzip -oq /tmp/gh-outcome-roadmap.zip -d ~/.claude/skills/ && rm /tmp/gh-outcome-roadmap.zip
```

```powershell
$z="$env:TEMP\gh-outcome-roadmap.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-outcome-roadmap.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/outcome-roadmap` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-outcome-roadmap.zip -o /tmp/gh-outcome-roadmap.zip && unzip -oq /tmp/gh-outcome-roadmap.zip -d ~/.agents/skills/ && rm /tmp/gh-outcome-roadmap.zip
```

```powershell
$z="$env:TEMP\gh-outcome-roadmap.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-outcome-roadmap.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$outcome-roadmap` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-outcome-roadmap.zip -o /tmp/gh-outcome-roadmap.zip && unzip -oq /tmp/gh-outcome-roadmap.zip -d ~/.cursor/skills/ && rm /tmp/gh-outcome-roadmap.zip
```

```powershell
$z="$env:TEMP\gh-outcome-roadmap.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-outcome-roadmap.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `outcome-roadmap`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-outcome-roadmap.zip -o /tmp/gh-outcome-roadmap.zip && unzip -oq /tmp/gh-outcome-roadmap.zip -d ~/.gemini/skills/ && rm /tmp/gh-outcome-roadmap.zip
```

```powershell
$z="$env:TEMP\gh-outcome-roadmap.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-outcome-roadmap.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「把这份路线图改成以结果为导向的」
- 「这些功能帮我改写成业务结果」
- 「路线图要给老板看，帮我讲清每项带来什么」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「这是我们明年上半年的路线图（贴上 8 个功能和对应月份），帮我改成结果路线图。」 |
| 它问了你什么 | 对每一项追问「做这个是为了什么」；说不出结果的会标出来问你，或者建议合并、砍掉。 |
| 它交付了什么 | 改写后的路线图：按季度列出原功能 → 结果句（「让【谁】做到【什么】，从而【业务影响】」）→ 指标；附与公司战略的对应关系、关键假设和依赖。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**它要联网查公司战略？** 只有你的工具开了联网才会查；没开就把战略要点贴给它。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/outcome-roadmap 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `outcome-roadmap`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 outcome-roadmap 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `outcome-roadmap`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
