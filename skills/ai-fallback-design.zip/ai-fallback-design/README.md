# AI 功能兜底设计（ai-fallback-design）

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10）：在本机命令行 AI 里项目级安装真跑，「AI 答错了怎么办」自动调用，问「幻觉是什么」时不调用。同一个拍货架自动补货的功能：装后 89 分、不装 71 分。装后把 4 个输出点里 3 个从「全自动」降为「草稿 + 店长确认」，转人工条件写死 5 条，并给了 20 题评测集（正常 8 / 坏例子 8 / 边界 4，含促销堆头、遮挡、新品、逆光）和上线后的留痕、撤回、监控；不装的思路也对，但没有评测集，还保留了一档自动提交。注意：一句话请求时它没在第 1 步停下确认，直接写完了全部。代价是慢约 1.8 倍。样本 1 次，仅供参考。详见 AI 测评与指南《自制 Skill 全量实测》

## 用处

### 解决什么问题
AI 功能演示很惊艳，上线两周因为一次自动操作出错被叫停，「必要时转人工」到底是什么时候，没人说得清。

### 适合谁
正在做 AI 功能的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| AI 功能准备上线<br>评审时被问「AI 答错了谁负责」 | 选模型、调提示词提高准确率<br>问大模型原理 |

### 用前 / 用后
**用前：** 方案里写「准确率 98%，自动关闭已解决工单，必要时转人工」。上线两周，被错关的工单引来投诉，功能被叫停；「必要时」到底是什么时候，没人说得清。

**用后：** 4 个输出点分了级，「关闭工单」从自动改成只提醒；转人工写清三个条件；评测集里 8 道坏例子题，包括「单号不存在」「知识库没有」「情绪激动要全额退」；上线后看采纳率、撤销率、转人工率，功能有总开关。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `ai-fallback-design/` 文件夹，里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/ai-fallback-design.zip -o /tmp/ai-fallback-design.zip && unzip -oq /tmp/ai-fallback-design.zip -d ~/.claude/skills/ && rm /tmp/ai-fallback-design.zip
```

```powershell
$z="$env:TEMP\ai-fallback-design.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/ai-fallback-design.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/ai-fallback-design` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/ai-fallback-design.zip -o /tmp/ai-fallback-design.zip && unzip -oq /tmp/ai-fallback-design.zip -d ~/.agents/skills/ && rm /tmp/ai-fallback-design.zip
```

```powershell
$z="$env:TEMP\ai-fallback-design.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/ai-fallback-design.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$ai-fallback-design` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/ai-fallback-design.zip -o /tmp/ai-fallback-design.zip && unzip -oq /tmp/ai-fallback-design.zip -d ~/.cursor/skills/ && rm /tmp/ai-fallback-design.zip
```

```powershell
$z="$env:TEMP\ai-fallback-design.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/ai-fallback-design.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `ai-fallback-design`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/ai-fallback-design.zip -o /tmp/ai-fallback-design.zip && unzip -oq /tmp/ai-fallback-design.zip -d ~/.gemini/skills/ && rm /tmp/ai-fallback-design.zip
```

```powershell
$z="$env:TEMP\ai-fallback-design.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/ai-fallback-design.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；步骤里提到的模板文件（`templates/` 下）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「我们的客服 AI 答错了怎么办，帮我设计兜底」
- 「这个 AI 功能上线前要准备什么」
- 「帮我写一份 AI 功能的上线评测集」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「我们的客服 AI 答错了怎么办，帮我设计兜底。」并说明它在哪里输出、输出后是给人看还是直接执行。 |
| 它问了你什么 | 先把功能拆成 4 个 AI 输出点请你确认，并逐个问：这是建议还是自动执行？执行后能不能撤？ |
| 它交付了什么 | 兜底设计表（4 个输出点分了级，「关闭工单」从自动改成只提醒，转人工写清触发条件）+ 20 题评测集（8 道坏例子）+ 上线后的留痕、回放、撤回和三个指标（见 `examples/示例_客服助手.md`）。 |

### 常见问题
**说了触发说法，它没反应怎么办？** 先确认文件夹名和 `SKILL.md` 第二行 `name:` 一致、放对了目录（见上面「安装」里你用的那个 AI）、新开了对话。还不行，直接说「用 ai-fallback-design 这个 Skill」点名调用；或者把你平时的说法加进 `SKILL.md` 开头 `description:` 那一行里——它只靠这一行判断要不要出场。

**怎么改成自己团队的版本？** 不要一上来就大改。先照原样用 3 次，每次把它的产出和你手改后的版本都存下来，然后让 AI 对比两版、说出你改动背后的规则，把规则写进 `SKILL.md` 的步骤或「不要做」里；模板换成你们团队的格式，放进 `templates/` 覆盖同名文件即可。改完在 README「更新记录」里写一行。

**评测集的通过线定多少？** 它不替你定。常见做法是坏例子题一条都不能出现坏输出，由产品负责人拍板后写进上线标准。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 五步流程、分级口径、反例 |
| `templates/兜底设计表.md` | 设计表 + 上线后方案 |
| `templates/评测集.md` | 20 题评测集骨架 |
| `examples/示例_客服助手.md` | 示例产出（虚构） |

## 更新记录
- v1.0（2026-11-09）：首发。
- v1.0（2026-11-09）：README 改为「用处 / 用法」结构，补完整使用示例与常见问题。
- v1.0（2026-11-09）：安装改为按平台分节、给可复制命令（下载地址为上线前占位）。
- v1.0（2026-11-09）：安装补齐 4 个平台的命令（目录按产品技术部核实）。
