# 砍范围：先定值多少时间，再砍到放得下（gh-scope-cutting）

免费下载，装上即用。用途：砍范围：先定值多少时间，再砍到放得下。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 定义需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Tair Asim · 来源：GitHub assimovt/productskills（skills/scope-cutting）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
需求越加越多，排期从 3 周拖到 3 个月，没人敢提砍哪些。

### 适合谁
要定首版范围、控制排期的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 功能清单太长，要找出首版必须有的<br>排期超了，要决定砍什么<br>要给团队讲清「为什么这次不做」 | 还在判断该不该做 → 用 gh-problem-validation<br>要按打分给一堆需求排序 → 用 gh-prioritization-frameworks |

### 用前 / 用后
**用前：** 创作者数据中心首版列了 14 个功能，研发估 10 周，大家只想着怎么加人。

**用后：** 先定「这件事值多少时间」（小批 1–2 周、大批最多 6 周），再逐项过四问：必须还是锦上添花？没有它能不能发？是主路径还是不到 20% 用户会碰到的边角？和「什么都不做」比是不是更好？首版必须项不超过 5 个；砍广度不砍质量。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `scope-cutting/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-scope-cutting.zip -o /tmp/gh-scope-cutting.zip && unzip -oq /tmp/gh-scope-cutting.zip -d ~/.claude/skills/ && rm /tmp/gh-scope-cutting.zip
```

```powershell
$z="$env:TEMP\gh-scope-cutting.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-scope-cutting.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/scope-cutting` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-scope-cutting.zip -o /tmp/gh-scope-cutting.zip && unzip -oq /tmp/gh-scope-cutting.zip -d ~/.agents/skills/ && rm /tmp/gh-scope-cutting.zip
```

```powershell
$z="$env:TEMP\gh-scope-cutting.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-scope-cutting.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$scope-cutting` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-scope-cutting.zip -o /tmp/gh-scope-cutting.zip && unzip -oq /tmp/gh-scope-cutting.zip -d ~/.cursor/skills/ && rm /tmp/gh-scope-cutting.zip
```

```powershell
$z="$env:TEMP\gh-scope-cutting.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-scope-cutting.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `scope-cutting`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-scope-cutting.zip -o /tmp/gh-scope-cutting.zip && unzip -oq /tmp/gh-scope-cutting.zip -d ~/.gemini/skills/ && rm /tmp/gh-scope-cutting.zip
```

```powershell
$z="$env:TEMP\gh-scope-cutting.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-scope-cutting.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我砍一下这个版本的范围」
- 「这些功能哪些可以不放首版」
- 「排期超了，帮我找最小可上线版本」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「内容 App 创作者数据中心，首版 14 个功能（贴清单），只给 3 周，帮我砍。」 |
| 它问了你什么 | 先问这件事值多少时间、几个人做；没说的话按「小批 2 周」来砍并请你确认。 |
| 它交付了什么 | 保留 4 项（核心 3 个指标卡、近 7 天趋势、单篇明细、导出）；10 项移出，每项一句理由（如「粉丝画像：不到 15% 创作者会看，先人工给头部创作者发报告」）。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**它说「不要估时间」？** 原文的意思是先定这件事值多少时间，再把方案削到放得下，而不是先估工期再硬塞。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `scope-cutting`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 scope-cutting 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `scope-cutting`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `66f9cee` 版本，新增中文 README。
