# 取数 SQL：各数仓方言、留存漏斗写法、报错排查（gh-sql-queries）

免费下载，装上即用。用途：取数 SQL：各数仓方言、留存漏斗写法、报错排查。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 上线验证 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10，未见提升）：在本机命令行 AI 里项目级安装真跑，取数请求 2 次里自动调用 1 次、无关请求不调用；4 道口径给全的 SQLite 题装与不装都全对。菜单里看不到它（包里写了不允许点名调用），属正常。详见 AI 测评与指南《3 个站内 Skill 真装真跑》

> 原作者：Anthropic · 来源：GitHub anthropics/knowledge-work-plugins（data/skills/sql-queries）· 许可证：Apache-2.0 · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
想自己拉个次日留存，写的 SQL 在公司数仓里一直报错，或者跑出来的数比看板高一截。

### 适合谁
会一点 SQL、想自己取数验证上线效果的产品经理；数据分析新人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 写留存、漏斗、去重、窗口函数这类常用查询<br>SQL 报错或跑得太慢，要排查<br>换了数仓不清楚方言差别 | 还没想清楚要看什么数 → 先用 data-question-decision-first<br>要检查整份分析结论靠不靠谱 → 用 gh-validate-data |

### 用前 / 用后
**用前：** 算次日留存时把「注册当天又登录」也算进去了，留存率虚高 8 个百分点。

**用后：** 按你的数仓方言写；用 CTE 拆步骤、可读；给出留存、漏斗、去重的标准写法；报错时按方言语法、列名、类型、除零、歧义列、分组六类逐个排查。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `sql-queries/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-sql-queries.zip -o /tmp/gh-sql-queries.zip && unzip -oq /tmp/gh-sql-queries.zip -d ~/.claude/skills/ && rm /tmp/gh-sql-queries.zip
```

```powershell
$z="$env:TEMP\gh-sql-queries.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-sql-queries.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/sql-queries` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-sql-queries.zip -o /tmp/gh-sql-queries.zip && unzip -oq /tmp/gh-sql-queries.zip -d ~/.agents/skills/ && rm /tmp/gh-sql-queries.zip
```

```powershell
$z="$env:TEMP\gh-sql-queries.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-sql-queries.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$sql-queries` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-sql-queries.zip -o /tmp/gh-sql-queries.zip && unzip -oq /tmp/gh-sql-queries.zip -d ~/.cursor/skills/ && rm /tmp/gh-sql-queries.zip
```

```powershell
$z="$env:TEMP\gh-sql-queries.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-sql-queries.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `sql-queries`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-sql-queries.zip -o /tmp/gh-sql-queries.zip && unzip -oq /tmp/gh-sql-queries.zip -d ~/.gemini/skills/ && rm /tmp/gh-sql-queries.zip
```

```powershell
$z="$env:TEMP\gh-sql-queries.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-sql-queries.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我写个 SQL 算次日留存」
- 「这段 SQL 报错了帮我看看」
- 「按渠道算一下注册到下单的漏斗」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「MySQL，表 user_register(user_id, reg_time) 和 user_login(user_id, login_time)，算 11 月每天注册用户的次日留存。」 |
| 它问了你什么 | 先确认数仓类型和表结构；「次日」按自然日还是 24 小时算没说清时，会问你。 |
| 它交付了什么 | 一段带注释的 SQL：CTE 先取注册日，再左连接次日登录、按注册日分组算留存率，用 `NULLIF` 防除零；附「当天重复登录不算留存」的说明。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**能直接连我们的数据库跑吗？** 包里没有任何连接。你的工具接了数据库才可能直接执行，否则它只写 SQL，你复制去跑。

**它会不会编表名？** 不给表结构时它可能按常见命名猜。一定先贴表结构，或让它把猜的表名标出来。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `sql-queries`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 sql-queries 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `sql-queries`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（Apache-2.0），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `e050c2e` 版本，新增中文 README。
