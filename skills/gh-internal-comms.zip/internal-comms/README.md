# 内部沟通：三段式周报、全员简报、FAQ（gh-internal-comms）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Anthropic · 来源：GitHub anthropics/skills（skills/internal-comms）· 许可证：Apache-2.0 · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
周报写成从周一到周五的流水账，领导 30 秒内看不出进展和卡点。

### 适合谁
要写团队周报、项目进展、全员简报、内部 FAQ 的职场人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 写「进展 / 计划 / 问题」三段式周报（原文叫 3P）<br>写公司或部门简报<br>把大家常问的问题整理成 FAQ | 写对外的营销文案<br>要规划长期跟谁怎么沟通 → 用 gh-stakeholder-map<br>整理会议纪要 → 用 meeting-minutes-4blocks |

### 用前 / 用后
**用前：** 周报 800 字，按日期从周一写到周五，真正的问题藏在第 6 段。

**用后：** 一段 30–60 秒能读完的三段式：团队名和日期，进展 1–3 句（带数字），计划 1–3 句，问题 1–3 句。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `internal-comms/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-internal-comms.zip -o /tmp/gh-internal-comms.zip && unzip -oq /tmp/gh-internal-comms.zip -d ~/.claude/skills/ && rm /tmp/gh-internal-comms.zip
```

```powershell
$z="$env:TEMP\gh-internal-comms.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-internal-comms.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/internal-comms` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-internal-comms.zip -o /tmp/gh-internal-comms.zip && unzip -oq /tmp/gh-internal-comms.zip -d ~/.agents/skills/ && rm /tmp/gh-internal-comms.zip
```

```powershell
$z="$env:TEMP\gh-internal-comms.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-internal-comms.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$internal-comms` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-internal-comms.zip -o /tmp/gh-internal-comms.zip && unzip -oq /tmp/gh-internal-comms.zip -d ~/.cursor/skills/ && rm /tmp/gh-internal-comms.zip
```

```powershell
$z="$env:TEMP\gh-internal-comms.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-internal-comms.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `internal-comms`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-internal-comms.zip -o /tmp/gh-internal-comms.zip && unzip -oq /tmp/gh-internal-comms.zip -d ~/.gemini/skills/ && rm /tmp/gh-internal-comms.zip
```

```powershell
$z="$env:TEMP\gh-internal-comms.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-internal-comms.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`examples/3p-updates.md`、`examples/company-newsletter.md`、`examples/faq-answers.md`、`examples/general-comms.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我写这周的团队周报，按进展、计划、问题三段」
- 「把这些更新整理成部门简报」
- 「把大家这周常问的问题整理成 FAQ」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「订货 App 组，11-03 到 11-07；这周再来一单灰度 10%，修了 6 个问题；下周全量；问题是联调环境不稳。写周报。」 |
| 它问了你什么 | 先确认团队名和时间段。如果你的工具接了公司的聊天、邮件、文档，它会按原文去那里找素材——不想让它翻，就说「只用我给的内容」。 |
| 它交付了什么 | 4 行周报（原文要求开头放一个表情）：「进展：再来一单灰度 10%，首日 1,240 家店使用，修复 6 个问题。计划：周三全量……问题：联调环境本周宕机 3 次，需要运维排期。」 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**全员简报那份写的是上千人的大公司？** 是，原文范例按大公司写。小团队只用三段式周报那一份就够。

**包里 4 个范例文件是干什么的？** 一种文体一份：三段式周报、公司简报、FAQ、其他内部沟通；它按你要写的类型只读对应那一份。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `internal-comms`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 internal-comms 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `internal-comms`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE.txt` | 上游许可证原文（Apache-2.0），原样保留 |
| `examples/3p-updates.md` | 上游原文：范例：三段式周报（进展 / 计划 / 问题）的格式与写法 |
| `examples/company-newsletter.md` | 上游原文：范例：公司简报的结构与取舍 |
| `examples/faq-answers.md` | 上游原文：范例：内部 FAQ 的格式 |
| `examples/general-comms.md` | 上游原文：范例：其他内部沟通的通用原则 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `2c5958e` 版本，新增中文 README。
