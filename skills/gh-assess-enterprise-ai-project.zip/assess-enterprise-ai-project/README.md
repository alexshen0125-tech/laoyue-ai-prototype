# 企业 AI 项目立项评估：五道门（gh-assess-enterprise-ai-project）

免费下载，装上即用。用途：企业 AI 项目立项评估：五道门。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** AI 产品设计与评测 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：hope138 · 来源：GitHub hope138/enterprise-ai-project-assessor（assess-enterprise-ai-project）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
老板说「我们也做个 AI 合同审核」，PRD 里需求、收益全是推测，立项会上没人能说清该不该做。

### 适合谁
做企业 AI 产品、参与 AI 项目立项评审的产品经理和业务负责人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 有一个 AI 项目想法或一份立项材料，要判断值不值得做<br>要区分哪些是事实、哪些是假设，列出缺的证据和最便宜的验证办法 | 项目已立项，要写评测细则 → 用 gh-eval-rubric<br>非 AI 项目的问题验证 → 用 gh-problem-validation |

### 用前 / 用后
**用前：** 立项材料写「预计节省法务 50% 时间」，没人问这个数从哪来、错一次的代价谁担。

**用后：** 先定清这次要决定什么（想法→试点、试点→上线……）；把材料里的每条说法分成已核实事实、文档说法、个人说法、假设、未知、矛盾；按顺序过五道门：真需求、为什么要用 AI（规则、人、AI 怎么分工）、技术可行、投入产出、运营兜底；一票否决项单独列；最后给「做 / 先验证 / 不做」和最低成本的验证计划。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `assess-enterprise-ai-project/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-assess-enterprise-ai-project.zip -o /tmp/gh-assess-enterprise-ai-project.zip && unzip -oq /tmp/gh-assess-enterprise-ai-project.zip -d ~/.claude/skills/ && rm /tmp/gh-assess-enterprise-ai-project.zip
```

```powershell
$z="$env:TEMP\gh-assess-enterprise-ai-project.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-assess-enterprise-ai-project.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/assess-enterprise-ai-project` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-assess-enterprise-ai-project.zip -o /tmp/gh-assess-enterprise-ai-project.zip && unzip -oq /tmp/gh-assess-enterprise-ai-project.zip -d ~/.agents/skills/ && rm /tmp/gh-assess-enterprise-ai-project.zip
```

```powershell
$z="$env:TEMP\gh-assess-enterprise-ai-project.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-assess-enterprise-ai-project.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$assess-enterprise-ai-project` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-assess-enterprise-ai-project.zip -o /tmp/gh-assess-enterprise-ai-project.zip && unzip -oq /tmp/gh-assess-enterprise-ai-project.zip -d ~/.cursor/skills/ && rm /tmp/gh-assess-enterprise-ai-project.zip
```

```powershell
$z="$env:TEMP\gh-assess-enterprise-ai-project.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-assess-enterprise-ai-project.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `assess-enterprise-ai-project`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-assess-enterprise-ai-project.zip -o /tmp/gh-assess-enterprise-ai-project.zip && unzip -oq /tmp/gh-assess-enterprise-ai-project.zip -d ~/.gemini/skills/ && rm /tmp/gh-assess-enterprise-ai-project.zip
```

```powershell
$z="$env:TEMP\gh-assess-enterprise-ai-project.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-assess-enterprise-ai-project.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里另有 6 个参考文件，`SKILL.md` 里提到哪个就把哪个一起贴上。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「这个 AI 项目值不值得做」
- 「帮我评估一下这份 AI 立项材料」
- 「AI 项目立项前要验证什么」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「集团法务想做 AI 合同初审，贴上立项 PPT 文字和 3 份访谈记录。要申请做试点。」 |
| 它问了你什么 | 先确认这次要决定的是「想法进入试点」；关键数字（每月合同量、现在初审耗时）材料里没有，会请你补，补不上就标为未知。 |
| 它交付了什么 | 证据清单 14 条（已核实 3 条、假设 6 条）；五道门结论：需求真实、AI 必要性部分成立、技术可行待验证、收益依据不足、兜底未设计；结论「先验证」：选 200 份历史合同做两周离线测试，以高风险条款漏检率为主指标。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**它会不会帮我把项目说成值得做？** 原文规定不编证据、文档里的说法不当事实。证据不够时，它给的是「先验证」和验证计划，而不是「做」。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `assess-enterprise-ai-project`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 assess-enterprise-ai-project 这个 Skill」点名调用。这个 Skill 的原文本身就有中文说明，一般中文提问即可触发。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `assess-enterprise-ai-project`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（中英混合，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `agents/openai.yaml` | 上游原文：上游给某个平台的显示名配置，纯文字，不执行 |
| `references/case-library.md` | 上游原文：评估案例库 |
| `references/decision-rules.md` | 上游原文：做 / 先验证 / 不做的判定规则 |
| `references/evidence-fallback.md` | 上游原文：证据不足时怎么办 |
| `references/five-gates.md` | 上游原文：五道门逐项说明 |
| `references/output-template.md` | 上游原文：输出模板 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `e27a1e1` 版本，新增中文 README。
