# AI 产品经理技术面：六段式答题框架（gh-technical-pm）

免费下载，装上即用。用途：AI 产品经理技术面：六段式答题框架。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 个人成长 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：aroyburman-codes · 来源：GitHub aroyburman-codes/pm-skills（skills/technical-pm）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
面 AI 产品经理被问「设计一个基于知识库的客服机器人」，只会讲功能，说不清检索、评测、成本和延迟。

### 适合谁
准备 AI 产品经理技术面的人，以及想补大模型产品技术常识的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 练「设计一个 AI 系统」类技术题<br>要一份涵盖检索增强、评测、部署、接口设计的答题骨架 | 要模拟真实面试被追问 → 用 gh-mock-interviewer<br>要定一个具体 AI 功能的评测细则 → 用 gh-eval-rubric |

### 用前 / 用后
**用前：** 回答「设计 AI 客服」时直接画界面，面试官问「答错了怎么办、一次要多少钱」答不上。

**用后：** 按六段答：先澄清约束（规模、延迟、成本、数据）；用户（开发者和终端用户）；整体架构；关键取舍深挖（如检索增强还是微调）；接口与开发者体验；技术和产品指标。附大模型训练、推理优化、安全对齐等必备知识点和「好答案长什么样」。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `technical-pm/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-technical-pm.zip -o /tmp/gh-technical-pm.zip && unzip -oq /tmp/gh-technical-pm.zip -d ~/.claude/skills/ && rm /tmp/gh-technical-pm.zip
```

```powershell
$z="$env:TEMP\gh-technical-pm.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-technical-pm.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/technical-pm` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-technical-pm.zip -o /tmp/gh-technical-pm.zip && unzip -oq /tmp/gh-technical-pm.zip -d ~/.agents/skills/ && rm /tmp/gh-technical-pm.zip
```

```powershell
$z="$env:TEMP\gh-technical-pm.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-technical-pm.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$technical-pm` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-technical-pm.zip -o /tmp/gh-technical-pm.zip && unzip -oq /tmp/gh-technical-pm.zip -d ~/.cursor/skills/ && rm /tmp/gh-technical-pm.zip
```

```powershell
$z="$env:TEMP\gh-technical-pm.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-technical-pm.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `technical-pm`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-technical-pm.zip -o /tmp/gh-technical-pm.zip && unzip -oq /tmp/gh-technical-pm.zip -d ~/.gemini/skills/ && rm /tmp/gh-technical-pm.zip
```

```powershell
$z="$env:TEMP\gh-technical-pm.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-technical-pm.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我准备一道 AI 产品技术面的题」
- 「设计一个知识库客服机器人，按技术面怎么答」
- 「AI 产品经理技术面要懂哪些知识」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「技术面题：为一家连锁药店设计基于药品说明书的问答助手。帮我按框架答一遍。」 |
| 它问了你什么 | 原文先请你确认题目里的约束；没给的，它会先列出假设（如每天 5 万次提问、要求 3 秒内回复）。 |
| 它交付了什么 | 六段式答案：澄清 4 条假设；架构为检索增强加人工审核兜底；取舍 3 组（召回率 vs 延迟等）；接口设计要点；指标 6 个（答案有依据比例、拒答率、单次成本等）。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**它说要先搜索 5–10 次？** 那是原文的「先研究」要求。工具没开联网就跳过，直接按框架作答，内容不受影响。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `technical-pm`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 technical-pm 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `technical-pm`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `f879de8` 版本，新增中文 README。
