# 指标树：北极星、输入指标和反向指标（gh-metrics-framework）

免费下载，装上即用。用途：指标树：北极星、输入指标和反向指标。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 上线验证 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Tair Asim · 来源：GitHub assimovt/productskills（skills/metrics-framework）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
指标越加越多，每个都在涨，但没人能说清「这个数变了我们要做什么」。

### 适合谁
要搭指标体系、给团队定可影响指标的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 要从北极星往下拆出各团队能直接推动的输入指标<br>要给每个关键指标配一个防作弊的反向指标 | 只要选北极星、对 7 条标准打勾 → 用 gh-north-star-metric<br>要复盘这个月的指标 → 用 gh-metrics-review |

### 用前 / 用后
**用前：** 团队 KPI 定成「注册数」，于是放宽注册门槛，注册翻倍、7 日留存腰斩。

**用后：** 每个指标先过一问：这个数变了，我们会做什么不同？过不了就是虚荣指标。然后画树：北极星 → 拉新、激活、参与、留存四支 → 每支下面团队能直接推的叶子指标；每个关键指标配一个反向指标（如注册数配 7 日留存）。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `metrics-framework/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-framework.zip -o /tmp/gh-metrics-framework.zip && unzip -oq /tmp/gh-metrics-framework.zip -d ~/.claude/skills/ && rm /tmp/gh-metrics-framework.zip
```

```powershell
$z="$env:TEMP\gh-metrics-framework.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-framework.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/metrics-framework` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-framework.zip -o /tmp/gh-metrics-framework.zip && unzip -oq /tmp/gh-metrics-framework.zip -d ~/.agents/skills/ && rm /tmp/gh-metrics-framework.zip
```

```powershell
$z="$env:TEMP\gh-metrics-framework.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-framework.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$metrics-framework` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-framework.zip -o /tmp/gh-metrics-framework.zip && unzip -oq /tmp/gh-metrics-framework.zip -d ~/.cursor/skills/ && rm /tmp/gh-metrics-framework.zip
```

```powershell
$z="$env:TEMP\gh-metrics-framework.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-framework.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `metrics-framework`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-framework.zip -o /tmp/gh-metrics-framework.zip && unzip -oq /tmp/gh-metrics-framework.zip -d ~/.gemini/skills/ && rm /tmp/gh-metrics-framework.zip
```

```powershell
$z="$env:TEMP\gh-metrics-framework.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-framework.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我搭一个指标树」
- 「从北极星往下拆一下各团队的指标」
- 「这个 KPI 会不会被刷，配什么反向指标」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「在线协作文档工具，团队版收费。帮我定北极星并拆成指标树。」 |
| 它问了你什么 | 先问产品给用户的核心价值在哪一刻发生；你说不清时，会给 2–3 个候选让你挑。 |
| 它交付了什么 | 北极星「每周有 3 人以上协作的活跃团队数」；四支共 9 个叶子指标（如「7 天内邀请队友的比例」）；4 个反向指标；并标出 2 个现有 KPI 属于虚荣指标。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**原文的例子都是海外产品？** 只是举例，判断方法通用。可以直接说「用中文、按我们行业举例」。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `metrics-framework`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 metrics-framework 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `metrics-framework`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `66f9cee` 版本，新增中文 README。
