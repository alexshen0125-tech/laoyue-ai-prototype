# 分步写 PRD（prd-step-by-step）

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10）：在本机命令行 AI 里项目级安装真跑，「把这个需求写成 PRD」自动调用，并照包里的规矩停在第 1 步、列 5 个问题等你回答；问 PRD 和 MRD 区别时不调用。同一需求加一句「中间不用停」一次走完：装后 77 分、不装 57 分——不装的版本替你填了「自动化率 ≥95%」「工单下降 80%」等目标值和现状数，装后目标列留空、没确认的进了待确认表。装后仍有 1 处「24 小时内到账」没标待确认，也漏了称重商品少称的情况。代价是慢约 1.5 倍。样本 1 次，仅供参考。详见 AI 测评与指南《自制 Skill 全量实测》

## 用处

### 解决什么问题
一句话丢给 AI 写 PRD，拿回一大篇，评审时研发一问边界就答不上来。

### 适合谁
1–5 年产品经理；手上是中小需求，一页纸能说清。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 需求只有一句话、一段聊天记录或一份会议纪要，要尽快出一份能评审的文档 | 已经写好 PRD、只想找问题 → 用 prd-four-role-review<br>只补验收标准 → 用 acceptance-criteria-br-ac<br>跨多个系统的大改版 → 先拆成几个小需求 |

### 用前 / 用后
**用前：** 「做个再来一单，按上次买的一键加购，下架的跳过」——一句话丢过去，拿回 3000 字，目标写着「提升用户体验」，研发评审问「上次是哪次」「连点两下会不会加两遍」，答不上来。

**用后：** 第 1 步先被反问 5 个问题；最后拿到一页：P0 只有 2 个，BR-01 写清「优先取今天 − 7 天的订单，没有就取最近一次」，重复点击、全部下架、接口失败都写了用户看到什么，目标值留空自己填。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `prd-step-by-step/` 文件夹，里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/prd-step-by-step.zip -o /tmp/prd-step-by-step.zip && unzip -oq /tmp/prd-step-by-step.zip -d ~/.claude/skills/ && rm /tmp/prd-step-by-step.zip
```

```powershell
$z="$env:TEMP\prd-step-by-step.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/prd-step-by-step.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/prd-step-by-step` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/prd-step-by-step.zip -o /tmp/prd-step-by-step.zip && unzip -oq /tmp/prd-step-by-step.zip -d ~/.agents/skills/ && rm /tmp/prd-step-by-step.zip
```

```powershell
$z="$env:TEMP\prd-step-by-step.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/prd-step-by-step.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$prd-step-by-step` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/prd-step-by-step.zip -o /tmp/prd-step-by-step.zip && unzip -oq /tmp/prd-step-by-step.zip -d ~/.cursor/skills/ && rm /tmp/prd-step-by-step.zip
```

```powershell
$z="$env:TEMP\prd-step-by-step.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/prd-step-by-step.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `prd-step-by-step`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/prd-step-by-step.zip -o /tmp/prd-step-by-step.zip && unzip -oq /tmp/prd-step-by-step.zip -d ~/.gemini/skills/ && rm /tmp/prd-step-by-step.zip
```

```powershell
$z="$env:TEMP\prd-step-by-step.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/prd-step-by-step.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；步骤里提到的模板文件（`templates/` 下）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我把这个需求写成 PRD：……」
- 「这个需求帮我拆一下，先出个 P0」
- 「把这段聊天记录整理成需求文档」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「门店店长每晚补货太慢，做个再来一单，按上次买的一键加购，下架的跳过，帮我写成 PRD。」 |
| 它问了你什么 | 先出 4 行拆解表，再反问 5 个问题：「上次」指哪次？有没有截单时间？谁能用？看哪两个数？缺货要不要自动换？之后每一步都停下来问「确认或修改，回复继续」。 |
| 它交付了什么 | 一页 PRD：P0 2 个、BR-01~05 每条带数字、边界表 7 行（含连点两次、全部下架、接口失败）、AC 7 条、待确认 2 条；目标值留空给你填（见 `examples/再来一单_PRD.md`）。 |

### 常见问题
**说了触发说法，它没反应怎么办？** 先确认文件夹名和 `SKILL.md` 第二行 `name:` 一致、放对了目录（见上面「安装」里你用的那个 AI）、新开了对话。还不行，直接说「用 prd-step-by-step 这个 Skill」点名调用；或者把你平时的说法加进 `SKILL.md` 开头 `description:` 那一行里——它只靠这一行判断要不要出场。

**怎么改成自己团队的版本？** 不要一上来就大改。先照原样用 3 次，每次把它的产出和你手改后的版本都存下来，然后让 AI 对比两版、说出你改动背后的规则，把规则写进 `SKILL.md` 的步骤或「不要做」里；模板换成你们团队的格式，放进 `templates/` 覆盖同名文件即可。改完在 README「更新记录」里写一行。

**它为什么老是反问，不直接写？** 有意的。它只用你确认过的事实写，没说过的标【待确认】。赶时间可以一次把背景、谁用、限制都说清，反问会少很多。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 五步流程、停顿点、自查清单 |
| `templates/一页PRD.md` | 7 节一页 PRD 模板 |
| `reference/边界类别.md` | 6 类需求各自的 6 类边界 |
| `examples/再来一单_输入.md` | 示例输入（虚构） |
| `examples/再来一单_PRD.md` | 示例产出（虚构） |

## 更新记录
- v1.0（2026-11-09）：首发。
- v1.0（2026-11-09）：README 改为「用处 / 用法」结构，补完整使用示例与常见问题。
- v1.0（2026-11-09）：安装改为按平台分节、给可复制命令（下载地址为上线前占位）。
- v1.0（2026-11-09）：安装补齐 4 个平台的命令（目录按产品技术部核实）。
