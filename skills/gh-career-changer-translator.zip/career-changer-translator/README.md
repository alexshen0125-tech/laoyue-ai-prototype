# 转行翻译器：把旧经历翻成新岗位听得懂的话（gh-career-changer-translator）

免费下载，装上即用。用途：转行翻译器：把旧经历翻成新岗位听得懂的话。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 个人成长 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Resume Skills（Paramchoudhary） · 来源：GitHub Paramchoudhary/ResumeSkills（skills/career-changer-translator）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
从运营、测试、研发转产品经理，简历上全是旧岗位的说法，面试官看不出你能干产品的活。

### 适合谁
想转做产品经理或转 AI 产品经理的人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 要找出旧工作里能迁移到新岗位的能力<br>要改写简历开头和经历，回答「为什么转行」 | 已经是产品经理、只是改简历 → 用 gh-resume-bullet-writer<br>要准备 AI 产品技术面 → 用 gh-technical-pm |

### 用前 / 用后
**用前：** 「负责 5 个社群日常运营，策划线上活动 20 场。」投产品岗石沉大海。

**用后：** 先列出可迁移能力（用户洞察、数据分析、跨团队推进……）；把旧说法翻成新岗位的说法（「策划活动」→「设计并验证用户增长实验」）；简历用「可迁移能力摘要」开头，必要时用混合格式；写一段「为什么转」的故事；给出补经验的过渡办法。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `career-changer-translator/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-career-changer-translator.zip -o /tmp/gh-career-changer-translator.zip && unzip -oq /tmp/gh-career-changer-translator.zip -d ~/.claude/skills/ && rm /tmp/gh-career-changer-translator.zip
```

```powershell
$z="$env:TEMP\gh-career-changer-translator.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-career-changer-translator.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/career-changer-translator` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-career-changer-translator.zip -o /tmp/gh-career-changer-translator.zip && unzip -oq /tmp/gh-career-changer-translator.zip -d ~/.agents/skills/ && rm /tmp/gh-career-changer-translator.zip
```

```powershell
$z="$env:TEMP\gh-career-changer-translator.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-career-changer-translator.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$career-changer-translator` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-career-changer-translator.zip -o /tmp/gh-career-changer-translator.zip && unzip -oq /tmp/gh-career-changer-translator.zip -d ~/.cursor/skills/ && rm /tmp/gh-career-changer-translator.zip
```

```powershell
$z="$env:TEMP\gh-career-changer-translator.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-career-changer-translator.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `career-changer-translator`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-career-changer-translator.zip -o /tmp/gh-career-changer-translator.zip && unzip -oq /tmp/gh-career-changer-translator.zip -d ~/.gemini/skills/ && rm /tmp/gh-career-changer-translator.zip
```

```powershell
$z="$env:TEMP\gh-career-changer-translator.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-career-changer-translator.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「我想从运营转产品经理，帮我翻译一下经历」
- 「转 AI 产品经理，我原来的经历怎么写」
- 「面试问为什么转行，怎么回答」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「做了 3 年电商运营，想转 AI 产品经理。这是我的简历。」 |
| 它问了你什么 | 先问目标岗位和你最拿得出手的 3 件事；看不出迁移点时会追问做事细节。 |
| 它交付了什么 | 可迁移能力 5 项，各对应一段经历；改写后的简历开头 3 行；3 条经历改写；「为什么转」的 4 句话故事；2 个能在 1 个月内补上的作品（如用 AI 做一个选品助手原型并写复盘）。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**原文的转行路径里没有我的？** 方法通用。直接告诉它「从 A 转 B」，它按同样的框架做。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `career-changer-translator`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 career-changer-translator 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `career-changer-translator`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `74ae19e` 版本，新增中文 README。
