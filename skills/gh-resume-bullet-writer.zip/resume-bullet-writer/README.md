# 简历经历改写：从「负责」到「做成了什么」（gh-resume-bullet-writer）

免费下载，装上即用。用途：简历经历改写：从「负责」到「做成了什么」。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 个人成长 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Resume Skills（Paramchoudhary） · 来源：GitHub Paramchoudhary/ResumeSkills（skills/resume-bullet-writer）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
简历每条都是「负责 XX 模块的需求」「参与 XX 项目」，看不出做成了什么。

### 适合谁
要写或改简历的产品经理，尤其是转行、转 AI 产品的人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 简历里的经历描述太弱，要改成结果导向<br>手上没有精确数字，要找能写的指标 | 要对照招聘要求挑经历 → 用 resume-match-jd<br>要准备面试故事 → 用 gh-interview-prep-generator |

### 用前 / 用后
**用前：** 「负责商家后台订单模块的需求设计与跟进。」

**用后：** 「重做商家后台订单筛选和批量处理，商家处理 100 单的时间从 25 分钟降到 8 分钟，相关客服工单下降 30%。」——用「做成了什么 + 用什么衡量 + 怎么做到」的公式，强动词开头，没有精确数字时给出合理估算的写法和说明。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `resume-bullet-writer/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-resume-bullet-writer.zip -o /tmp/gh-resume-bullet-writer.zip && unzip -oq /tmp/gh-resume-bullet-writer.zip -d ~/.claude/skills/ && rm /tmp/gh-resume-bullet-writer.zip
```

```powershell
$z="$env:TEMP\gh-resume-bullet-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-resume-bullet-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/resume-bullet-writer` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-resume-bullet-writer.zip -o /tmp/gh-resume-bullet-writer.zip && unzip -oq /tmp/gh-resume-bullet-writer.zip -d ~/.agents/skills/ && rm /tmp/gh-resume-bullet-writer.zip
```

```powershell
$z="$env:TEMP\gh-resume-bullet-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-resume-bullet-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$resume-bullet-writer` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-resume-bullet-writer.zip -o /tmp/gh-resume-bullet-writer.zip && unzip -oq /tmp/gh-resume-bullet-writer.zip -d ~/.cursor/skills/ && rm /tmp/gh-resume-bullet-writer.zip
```

```powershell
$z="$env:TEMP\gh-resume-bullet-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-resume-bullet-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `resume-bullet-writer`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-resume-bullet-writer.zip -o /tmp/gh-resume-bullet-writer.zip && unzip -oq /tmp/gh-resume-bullet-writer.zip -d ~/.gemini/skills/ && rm /tmp/gh-resume-bullet-writer.zip
```

```powershell
$z="$env:TEMP\gh-resume-bullet-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-resume-bullet-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我改一下简历里的这几条经历」
- 「这段工作经历怎么写才有亮点」
- 「我没有具体数据，经历怎么量化」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 贴上 5 条简历经历，说「应聘 AI 产品经理，原来做 B 端后台」。 |
| 它问了你什么 | 对每条追问：你具体做了什么？改了之后什么变了？有没有数字（时间、比例、金额、人数）？ |
| 它交付了什么 | 5 条改写，各给两个版本（有数字 / 估算）；标出 1 条「信息不够，建议删掉或补充」；提醒估算数字面试时要能说出来源。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**它会帮我编数字吗？** 原文强调可以估算但要合理、能解释。别写自己说不出依据的数。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `resume-bullet-writer`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 resume-bullet-writer 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `resume-bullet-writer`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `74ae19e` 版本，新增中文 README。
