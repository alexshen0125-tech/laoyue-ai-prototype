# 9 种优先级方法速查（gh-prioritization-frameworks）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-execution/skills/prioritization-frameworks）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。 编辑部按 MIT 许可删除了原文末的课程推广链接，其余内容保持原样。

## 用处

### 解决什么问题
老板问「为什么先做这个」，只能说「感觉更重要」；RICE、ICE 分不清，随手挑一个。

### 适合谁
要排需求优先级、给排序找依据的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 不知道该用哪种排序方法<br>想弄清 RICE 和 ICE 的公式差在哪<br>要给团队讲清打分规则 | 手上就是一堆需求，要直接排出前 3 → 用 gh-analyze-feature-requests<br>要定核心指标 → 用 gh-north-star-metric |

### 用前 / 用后
**用前：** 用 RICE 给 30 个需求打分，「影响力」全靠拍脑袋，排出来的顺序和直觉一模一样。

**用后：** 先分清排的是「用户问题」还是「功能方案」：排问题用机会分（重要度 ×（1 − 满意度）），排方案再用 ICE 或 RICE；拿到对应公式、适用场景和一张 9 种方法对照表。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `prioritization-frameworks/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-prioritization-frameworks.zip -o /tmp/gh-prioritization-frameworks.zip && unzip -oq /tmp/gh-prioritization-frameworks.zip -d ~/.claude/skills/ && rm /tmp/gh-prioritization-frameworks.zip
```

```powershell
$z="$env:TEMP\gh-prioritization-frameworks.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prioritization-frameworks.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/prioritization-frameworks` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-prioritization-frameworks.zip -o /tmp/gh-prioritization-frameworks.zip && unzip -oq /tmp/gh-prioritization-frameworks.zip -d ~/.agents/skills/ && rm /tmp/gh-prioritization-frameworks.zip
```

```powershell
$z="$env:TEMP\gh-prioritization-frameworks.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prioritization-frameworks.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$prioritization-frameworks` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-prioritization-frameworks.zip -o /tmp/gh-prioritization-frameworks.zip && unzip -oq /tmp/gh-prioritization-frameworks.zip -d ~/.cursor/skills/ && rm /tmp/gh-prioritization-frameworks.zip
```

```powershell
$z="$env:TEMP\gh-prioritization-frameworks.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prioritization-frameworks.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `prioritization-frameworks`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-prioritization-frameworks.zip -o /tmp/gh-prioritization-frameworks.zip && unzip -oq /tmp/gh-prioritization-frameworks.zip -d ~/.gemini/skills/ && rm /tmp/gh-prioritization-frameworks.zip
```

```powershell
$z="$env:TEMP\gh-prioritization-frameworks.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prioritization-frameworks.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「RICE 和 ICE 有什么区别，我该用哪个」
- 「帮我选一个排需求优先级的方法」
- 「机会分怎么算」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「我们有 12 个用户提的问题、5 个候选方案，团队 6 个人，下周要定季度优先级，用哪种方法？」 |
| 它问了你什么 | 它是参考资料型的 Skill，追问不多，主要问一句：你要排的是用户问题还是功能方案。 |
| 它交付了什么 | 建议分两步：先用机会分排 12 个问题（附公式和 0–1 归一化说明），再给前 3 个问题的方案用 ICE 打分；并提醒投票前先各自独立打分，别被最资深的人带偏。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**末尾的模板链接打不开？** 那是作者放在境外网盘的表格，打不开不影响，公式和对照表都在 `SKILL.md` 正文里。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `prioritization-frameworks`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 prioritization-frameworks 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `prioritization-frameworks`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
