# 写给用户看的更新说明（gh-release-notes）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-execution/skills/release-notes）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
更新说明直接贴研发的提交记录：「修复并发下单竞态问题」，用户看不懂。

### 适合谁
要发版本更新说明、更新公告的产品经理和运营。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 手上有需求单、提交记录或内部更新清单，要改成用户听得懂的话<br>要按「新功能 / 改进 / 修复 / 需要你操作」分好组 | 要做上线前风险评估 → 用 gh-pre-mortem<br>要写营销推广文案 |

### 用前 / 用后
**用前：** 「v3.2：优化缓存策略；修复 #1287；新增 RepurchaseBtn 组件」

**用后：** 「新功能 · 再来一单：按上次订单一键加购，已下架的自动跳过。改进 · 订单列表打开快了约 3 倍。修复 · 高峰期偶尔下单失败的问题。」每条先说对用户有什么好处。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `release-notes/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-release-notes.zip -o /tmp/gh-release-notes.zip && unzip -oq /tmp/gh-release-notes.zip -d ~/.claude/skills/ && rm /tmp/gh-release-notes.zip
```

```powershell
$z="$env:TEMP\gh-release-notes.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-release-notes.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/release-notes` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-release-notes.zip -o /tmp/gh-release-notes.zip && unzip -oq /tmp/gh-release-notes.zip -d ~/.agents/skills/ && rm /tmp/gh-release-notes.zip
```

```powershell
$z="$env:TEMP\gh-release-notes.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-release-notes.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$release-notes` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-release-notes.zip -o /tmp/gh-release-notes.zip && unzip -oq /tmp/gh-release-notes.zip -d ~/.cursor/skills/ && rm /tmp/gh-release-notes.zip
```

```powershell
$z="$env:TEMP\gh-release-notes.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-release-notes.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `release-notes`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-release-notes.zip -o /tmp/gh-release-notes.zip && unzip -oq /tmp/gh-release-notes.zip -d ~/.gemini/skills/ && rm /tmp/gh-release-notes.zip
```

```powershell
$z="$env:TEMP\gh-release-notes.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-release-notes.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「把这些需求单写成更新说明」
- 「帮我写这次版本的更新日志，给用户看的」
- 「把研发的提交记录改成用户能看懂的话」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「这是 v3.2 的 9 条需求单标题和描述（贴上），读者是门店店长，写更新说明。」 |
| 它问了你什么 | 先确认读者是谁（店长、开发者还是内部同事），语气跟着变；看不出对用户有什么变化的条目，会问你「这条对用户有什么不同」。 |
| 它交付了什么 | 一份分组的更新说明，每条 1–3 句、先写好处；纯内部重构不写进去；需要用户自己操作的单独列出。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**「快了 3 倍」这种数字哪来的？** 只用需求单里本来就有的数。没有就让它写「更快了」，别让它编。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/release-notes 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `release-notes`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 release-notes 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `release-notes`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
