# 机会解决方案树（gh-opportunity-solution-tree）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-product-discovery/skills/opportunity-solution-tree）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。 编辑部按 MIT 许可删除了原文末的课程推广链接，其余内容保持原样。

## 用处

### 解决什么问题
拿到「提升留存」的目标，直接跳到「做个签到功能」，没想过还有别的路。

### 适合谁
做产品发现、要从目标一路推到方案的产品经理和产品三人组（产品、设计、研发）。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 有一个明确的目标，加上一些用户研究材料<br>要理清「目标 → 用户机会 → 方案 → 实验」这条线 | 一份用户研究材料都没有 → 先用 gh-interview-script 去访谈<br>方案已经定了，只差排期 |

### 用前 / 用后
**用前：** 目标是「7 日留存到 40%」，会上 5 个人各提一个功能，吵了一个小时。

**用后：** 一棵四层的树：最上面 1 个目标；下面 5 个用户机会（从访谈原话提炼，像「我总是忘了……」）；排在前面的 2–3 个机会各配 3 个以上方案；最有希望的方案各配 1–2 个实验（假设、方法、指标、成功线）。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `opportunity-solution-tree/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-opportunity-solution-tree.zip -o /tmp/gh-opportunity-solution-tree.zip && unzip -oq /tmp/gh-opportunity-solution-tree.zip -d ~/.claude/skills/ && rm /tmp/gh-opportunity-solution-tree.zip
```

```powershell
$z="$env:TEMP\gh-opportunity-solution-tree.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-opportunity-solution-tree.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/opportunity-solution-tree` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-opportunity-solution-tree.zip -o /tmp/gh-opportunity-solution-tree.zip && unzip -oq /tmp/gh-opportunity-solution-tree.zip -d ~/.agents/skills/ && rm /tmp/gh-opportunity-solution-tree.zip
```

```powershell
$z="$env:TEMP\gh-opportunity-solution-tree.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-opportunity-solution-tree.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$opportunity-solution-tree` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-opportunity-solution-tree.zip -o /tmp/gh-opportunity-solution-tree.zip && unzip -oq /tmp/gh-opportunity-solution-tree.zip -d ~/.cursor/skills/ && rm /tmp/gh-opportunity-solution-tree.zip
```

```powershell
$z="$env:TEMP\gh-opportunity-solution-tree.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-opportunity-solution-tree.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `opportunity-solution-tree`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-opportunity-solution-tree.zip -o /tmp/gh-opportunity-solution-tree.zip && unzip -oq /tmp/gh-opportunity-solution-tree.zip -d ~/.gemini/skills/ && rm /tmp/gh-opportunity-solution-tree.zip
```

```powershell
$z="$env:TEMP\gh-opportunity-solution-tree.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-opportunity-solution-tree.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我画一棵机会解决方案树」
- 「目标是提升留存，从这些用户研究材料里帮我理出机会和方案」
- 「这些访谈记录帮我整理成 OST」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「目标：新开门店首月复购率从 35% 到 45%；这是 8 份店长访谈摘要（贴上）。帮我做 OST。」 |
| 它问了你什么 | 先确认目标只有一个、能量化；材料撑不起某个机会时会标出来，请你补材料或删掉。 |
| 它交付了什么 | 一份树形大纲：机会 5 个（如「我不知道第二次该订多少」），排序后前 3 个各配 3 个方案（产品、设计、研发视角各一个），每个首选方案配一个两周内能做完的实验和成功线。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**框架名都是英文？** 可以直接说「用中文输出，保留 OST 这类缩写」。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/opportunity-solution-tree 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `opportunity-solution-tree`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 opportunity-solution-tree 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `opportunity-solution-tree`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
