# 界面文案：按钮、报错、空状态怎么写（gh-ux-writing）

免费下载，装上即用。用途：界面文案：按钮、报错、空状态怎么写。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 定义需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Carlos C.（cuellarfr） · 来源：GitHub cuellarfr/design-skills（skills/ux-writing）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
PRD 里文案一栏写「提示错误」，上线后用户看到「操作失败，错误码 4003」，客服电话打爆。

### 适合谁
要在 PRD 或原型里写清界面文案的产品经理、交互设计师。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 写按钮、表单提示、报错、空状态、新手引导的文案<br>检查现有文案是不是清楚、简洁、语气对 | 要写营销推广文案<br>要整页交互评审 → 用 gh-product-designer |

### 用前 / 用后
**用前：** 支付失败弹窗写「系统异常，请稍后再试」，用户不知道钱扣没扣、该不该重付。

**用后：** 按「有用、简洁、像人说话、清楚」四条标准写；报错说清发生了什么、为什么、下一步做什么；按钮用动词写结果（「保存地址」而不是「确定」）；附错误、空状态、新手引导三个可填模板和改写前后对照。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `ux-writing/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-ux-writing.zip -o /tmp/gh-ux-writing.zip && unzip -oq /tmp/gh-ux-writing.zip -d ~/.claude/skills/ && rm /tmp/gh-ux-writing.zip
```

```powershell
$z="$env:TEMP\gh-ux-writing.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-ux-writing.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/ux-writing` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-ux-writing.zip -o /tmp/gh-ux-writing.zip && unzip -oq /tmp/gh-ux-writing.zip -d ~/.agents/skills/ && rm /tmp/gh-ux-writing.zip
```

```powershell
$z="$env:TEMP\gh-ux-writing.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-ux-writing.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$ux-writing` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-ux-writing.zip -o /tmp/gh-ux-writing.zip && unzip -oq /tmp/gh-ux-writing.zip -d ~/.cursor/skills/ && rm /tmp/gh-ux-writing.zip
```

```powershell
$z="$env:TEMP\gh-ux-writing.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-ux-writing.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `ux-writing`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-ux-writing.zip -o /tmp/gh-ux-writing.zip && unzip -oq /tmp/gh-ux-writing.zip -d ~/.gemini/skills/ && rm /tmp/gh-ux-writing.zip
```

```powershell
$z="$env:TEMP\gh-ux-writing.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-ux-writing.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里另有 9 个参考文件，`SKILL.md` 里提到哪个就把哪个一起贴上。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我写这几个页面的报错和空状态文案」
- 「这个按钮叫什么好」
- 「检查一下这批界面文案」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「电商结算页，支付失败、库存不足、地址缺失三种情况，帮我写弹窗文案，语气友好但别卖萌。」 |
| 它问了你什么 | 先问产品的语气定位、用户此刻的情绪；没有语气规范时，会建议先用包里的语气表模板定一版。 |
| 它交付了什么 | 三组文案，每组含标题、正文、主按钮、次按钮，例如支付失败：「支付没成功，钱没有扣」+「换个方式付款」/「返回订单」；并说明每处为什么这样写。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**例子都是英文界面？** 规则通用。你用中文提需求，它按中文习惯写；英文的大小写规则那部分直接跳过。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `ux-writing`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 ux-writing 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `ux-writing`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `docs/figma-integration.md` | 上游原文：可选：怎么给 AI 工具接设计稿服务（需用户自己操作） |
| `examples/real-world-improvements.md` | 上游原文：示例 |
| `references/accessibility-guidelines.md` | 上游原文：参考资料 |
| `references/content-usability-checklist.md` | 上游原文：参考资料 |
| `references/patterns-detailed.md` | 上游原文：参考资料 |
| `references/voice-chart-template.md` | 上游原文：参考资料 |
| `templates/empty-state-template.md` | 上游原文：可填写的模板 |
| `templates/error-message-template.md` | 上游原文：可填写的模板 |
| `templates/onboarding-flow-template.md` | 上游原文：可填写的模板 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `7e25e66` 版本，新增中文 README。
