# 产品指标看板设计（gh-metrics-dashboard）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-product-discovery/skills/metrics-dashboard）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。 编辑部按 MIT 许可删除了原文末的课程推广链接，其余内容保持原样。

## 用处

### 解决什么问题
看板做了 40 张图，周会没人看；指标突然掉了也没人知道。

### 适合谁
要搭产品数据看板、定监控告警的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 新产品要建看板<br>旧看板太杂要重做<br>要给每个指标定口径、目标和告警线 | 核心指标还没定 → 先用 gh-north-star-metric<br>要分析某一次数据异常 → 用 data-question-decision-first |

### 用前 / 用后
**用前：** 看板上全是累计注册数这种只涨不跌的数，出了问题根本看不出来。

**用后：** 四层指标（北极星 / 输入 / 健康 / 业务），每个指标都有口径（分子、分母、时间窗）、数据来源、图表类型、目标和告警线；一张看板布局草图；每天、每周、每月、每季度各看什么；告警发给谁、多久内响应。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `metrics-dashboard/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-dashboard.zip -o /tmp/gh-metrics-dashboard.zip && unzip -oq /tmp/gh-metrics-dashboard.zip -d ~/.claude/skills/ && rm /tmp/gh-metrics-dashboard.zip
```

```powershell
$z="$env:TEMP\gh-metrics-dashboard.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-dashboard.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/metrics-dashboard` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-dashboard.zip -o /tmp/gh-metrics-dashboard.zip && unzip -oq /tmp/gh-metrics-dashboard.zip -d ~/.agents/skills/ && rm /tmp/gh-metrics-dashboard.zip
```

```powershell
$z="$env:TEMP\gh-metrics-dashboard.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-dashboard.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$metrics-dashboard` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-dashboard.zip -o /tmp/gh-metrics-dashboard.zip && unzip -oq /tmp/gh-metrics-dashboard.zip -d ~/.cursor/skills/ && rm /tmp/gh-metrics-dashboard.zip
```

```powershell
$z="$env:TEMP\gh-metrics-dashboard.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-dashboard.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `metrics-dashboard`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-metrics-dashboard.zip -o /tmp/gh-metrics-dashboard.zip && unzip -oq /tmp/gh-metrics-dashboard.zip -d ~/.gemini/skills/ && rm /tmp/gh-metrics-dashboard.zip
```

```powershell
$z="$env:TEMP\gh-metrics-dashboard.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-metrics-dashboard.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我设计一个产品数据看板」
- 「这些指标帮我定口径和告警线」
- 「看板太乱了，帮我重新规划」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「门店订货 App，北极星是每周按时到货订单数，帮我设计看板，数据都在数仓里。」 |
| 它问了你什么 | 先读你给的现有看板或 OKR；数据来源说不清的指标会标「口径待确认」。 |
| 它交付了什么 | 指标表 14 行（如「准时履约率 = 按时到货订单 ÷ 应到订单，按周，低于 92% 告警」）、看板布局草图、查看节奏和告警表。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**推荐的工具我们没有？** 用你们公司现有的报表或 BI 工具即可，看板设计本身不依赖哪款工具。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/metrics-dashboard 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `metrics-dashboard`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 metrics-dashboard 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `metrics-dashboard`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
