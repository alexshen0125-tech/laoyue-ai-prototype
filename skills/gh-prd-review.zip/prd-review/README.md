# PRD 能不能交开发：打分、裁决、缺什么（gh-prd-review）

免费下载，装上即用。用途：PRD 能不能交开发：打分、裁决、缺什么。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 定义需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Taya Intelligence · 来源：GitHub TayaIntelligence/skills（prd-review）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
PRD 九个章节都填满了，研发还是说「没法开工」，但说不清到底缺什么。

### 适合谁
要在评审前自查 PRD，或帮别人审 PRD 的产品经理、产品负责人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| PRD 写完，想知道能不能交给开发<br>要一份按严重程度分级、每条都说清怎么补的审查报告<br>审 AI 功能的 PRD（会额外检查评测口径和人工兜底） | 还没写 PRD → 用 gh-prd-writer 或 gh-write-spec<br>要四个角色分别挑刺的评审清单 → 用 prd-four-role-review<br>只检查需求条目措辞 → 用 gh-make-requirements-great |

### 用前 / 用后
**用前：** 评审会开到一半，测试问「优惠券叠加超过上限怎么办」，没人答得上，会议改期。

**用后：** 按 9 组标准逐项判「完整 / 部分 / 缺失 / 不适用」并引用原文；分开给两个结论：完成度百分比，以及「可交付开发 / 有条件交付 / 暂不可交付」——任何一项阻断项缺失就判暂不可交付；最后生成一份 HTML 报告，阻断项每条写清后果和 2–4 步补法，也列出写得好的地方。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `prd-review/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-prd-review.zip -o /tmp/gh-prd-review.zip && unzip -oq /tmp/gh-prd-review.zip -d ~/.claude/skills/ && rm /tmp/gh-prd-review.zip
```

```powershell
$z="$env:TEMP\gh-prd-review.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prd-review.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/prd-review` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-prd-review.zip -o /tmp/gh-prd-review.zip && unzip -oq /tmp/gh-prd-review.zip -d ~/.agents/skills/ && rm /tmp/gh-prd-review.zip
```

```powershell
$z="$env:TEMP\gh-prd-review.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prd-review.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$prd-review` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-prd-review.zip -o /tmp/gh-prd-review.zip && unzip -oq /tmp/gh-prd-review.zip -d ~/.cursor/skills/ && rm /tmp/gh-prd-review.zip
```

```powershell
$z="$env:TEMP\gh-prd-review.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prd-review.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `prd-review`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-prd-review.zip -o /tmp/gh-prd-review.zip && unzip -oq /tmp/gh-prd-review.zip -d ~/.gemini/skills/ && rm /tmp/gh-prd-review.zip
```

```powershell
$z="$env:TEMP\gh-prd-review.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-prd-review.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里另有 15 个参考文件，`SKILL.md` 里提到哪个就把哪个一起贴上。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我审一下这份 PRD，能不能交开发」
- 「这份需求文档还缺什么」
- 「给这份 PRD 的完整度打个分」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「电商优惠券叠加规则 PRD（贴全文），下周评审，帮我先审。」 |
| 它问了你什么 | 通常不追问，直接审；只有答案会改变结论时才问一两句，比如「这是给消费者用的，还是运营后台的录入工具？」 |
| 它交付了什么 | 完成度约 60%，结论「暂不可交付」：验收标准只写了正常流程，缺「叠加超上限」「券过期」两类异常；没有写不做什么。报告列阻断项 3 条、建议项 5 条，并肯定「规则表写得清楚」。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**报告是英文的？** 原文要求报告用你的语言、少用术语。你用中文提问就是中文报告。

**HTML 报告在哪？** 能写文件的工具会存成 `PRD审核报告-功能名.html` 并告诉你路径；网页版会直接贴出内容，可复制到 .html 文件里打开。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `prd-review`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 prd-review 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `prd-review`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `agents/openai.yaml` | 上游原文：上游给某个平台的显示名配置，纯文字，不执行 |
| `assets/prd-template.md` | 上游原文：模板与报告样式 |
| `assets/report-template.html` | 上游原文：模板与报告样式 |
| `assets/risk-register-template.md` | 上游原文：模板与报告样式 |
| `assets/user-story-template.md` | 上游原文：模板与报告样式 |
| `references/ai-ml-products.md` | 上游原文：参考资料 |
| `references/delivery-and-process.md` | 上游原文：参考资料 |
| `references/discovery-and-requirements.md` | 上游原文：参考资料 |
| `references/edge-cases-and-exceptions.md` | 上游原文：参考资料 |
| `references/metrics.md` | 上游原文：参考资料 |
| `references/prioritization-and-estimation.md` | 上游原文：参考资料 |
| `references/review-rubric.md` | 上游原文：参考资料 |
| `references/technical-artifacts.md` | 上游原文：参考资料 |
| `references/worked-example.md` | 上游原文：参考资料 |
| `references/worked-review-example.md` | 上游原文：参考资料 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `58665d6` 版本，新增中文 README。
