# 营销心理学模型速查（gh-marketing-psychology）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Corey Haines · 来源：GitHub coreyhaines31/marketingskills（skills/marketing-psychology）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
定价页、引导页改来改去，说不出「为什么这样改用户会买单」。

### 适合谁
做增长、定价、转化、新手引导的产品经理和运营。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 想用心理学和行为科学解释或改进某个转化环节<br>要给方案找理论依据 | 要写完整的营销文案<br>要分析实验结果 → 用 gh-ab-test-analysis<br>想做诱导、操纵用户的设计（原文强调要合乎伦理，只在属实时用稀缺、紧迫） |

### 用前 / 用后
**用前：** 会员三档并列，用户几乎都选最便宜的，团队只想到「降价」。

**用后：** 先对上问题类型（比如「价格异议」）→ 找出相关模型（锚定、框架效应、心理账户、损失厌恶）→ 每个模型讲清原理、在你的页面上怎么用、怎么用才不越线。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `marketing-psychology/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-marketing-psychology.zip -o /tmp/gh-marketing-psychology.zip && unzip -oq /tmp/gh-marketing-psychology.zip -d ~/.claude/skills/ && rm /tmp/gh-marketing-psychology.zip
```

```powershell
$z="$env:TEMP\gh-marketing-psychology.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-marketing-psychology.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/marketing-psychology` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-marketing-psychology.zip -o /tmp/gh-marketing-psychology.zip && unzip -oq /tmp/gh-marketing-psychology.zip -d ~/.agents/skills/ && rm /tmp/gh-marketing-psychology.zip
```

```powershell
$z="$env:TEMP\gh-marketing-psychology.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-marketing-psychology.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$marketing-psychology` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-marketing-psychology.zip -o /tmp/gh-marketing-psychology.zip && unzip -oq /tmp/gh-marketing-psychology.zip -d ~/.cursor/skills/ && rm /tmp/gh-marketing-psychology.zip
```

```powershell
$z="$env:TEMP\gh-marketing-psychology.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-marketing-psychology.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `marketing-psychology`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-marketing-psychology.zip -o /tmp/gh-marketing-psychology.zip && unzip -oq /tmp/gh-marketing-psychology.zip -d ~/.gemini/skills/ && rm /tmp/gh-marketing-psychology.zip
```

```powershell
$z="$env:TEMP\gh-marketing-psychology.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-marketing-psychology.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`evals/evals.json`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「用心理学帮我分析一下这个定价页」
- 「新手引导转化低，有哪些行为模型可以用」
- 「稀缺效应怎么用才不算套路」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「订货平台会员三档：99、299、699 元/月，85% 的人选 99，想提高中间档的占比。」 |
| 它问了你什么 | 先问 5 件事：想影响什么行为、用户来之前怎么想、在哪个环节、现在卡在哪、有没有拿真实用户测过。 |
| 它交付了什么 | 4 个模型的具体用法（如诱饵效应：调整高档权益，让中间档「显得最划算」；默认效应：预选中间档并标「多数门店选择」——只在属实时这样写），每条附伦理提醒和建议的 A/B 验证。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**它提到的 cro、copywriting 等技能在哪？** 那是同仓库的其他 Skill，不在本包；不装也不影响本包使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `marketing-psychology`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 marketing-psychology 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `marketing-psychology`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `evals/evals.json` | 上游原文：作者的测试题（6 道），纯数据 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `96798cf` 版本，新增中文 README。
