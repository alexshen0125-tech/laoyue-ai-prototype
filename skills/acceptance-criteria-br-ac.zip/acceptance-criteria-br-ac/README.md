# 业务规则 BR + 验收标准 AC（acceptance-criteria-br-ac）

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10）：在本机命令行 AI 里项目级安装真跑，「补一下验收标准」1/1 自动调用、问概念时不调用；同一段满减需求装后 83 分、不装 71 分，装后输出带编号的 BR 和 Given/When/Then 表，模糊词都标了待确认（仍有 1 处把「不含运费」当事实写）。详见 AI 测评与指南《又装了 5 个站内 Skill》

## 用处

### 解决什么问题
PRD 里写着「一定金额需审批」「及时提醒」，测试问多少算一定、多久算及时，没人答得上。

### 适合谁
测试总说「PRD 没写」的产品经理；要从 PRD 反推用例的测试同学。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| PRD 写完，验收标准还是「功能正常」<br>要把一段需求原文改成带编号、带数字的规则 | 还没有需求文档 → 先写 PRD<br>要写自动化测试代码<br>要找整份文档所有问题 → 用 prd-four-role-review |

### 用前 / 用后
**用前：** 「订单金额比较大的时候要主管审批，审批不及时要提醒」——研发问多大算大，测试问多久算不及时，没人答得上。

**用后：** BR-01「实付 ≥ 5000 元【待确认】进入待审批」；AC 6 条，包括 5000.00 刚好等于、4999.99 不触发、驳回同一秒仓库拉单不出库；末尾 2 条待确认，写清问业务负责人和运营。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `acceptance-criteria-br-ac/` 文件夹，里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/acceptance-criteria-br-ac.zip -o /tmp/acceptance-criteria-br-ac.zip && unzip -oq /tmp/acceptance-criteria-br-ac.zip -d ~/.claude/skills/ && rm /tmp/acceptance-criteria-br-ac.zip
```

```powershell
$z="$env:TEMP\acceptance-criteria-br-ac.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/acceptance-criteria-br-ac.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/acceptance-criteria-br-ac` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/acceptance-criteria-br-ac.zip -o /tmp/acceptance-criteria-br-ac.zip && unzip -oq /tmp/acceptance-criteria-br-ac.zip -d ~/.agents/skills/ && rm /tmp/acceptance-criteria-br-ac.zip
```

```powershell
$z="$env:TEMP\acceptance-criteria-br-ac.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/acceptance-criteria-br-ac.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$acceptance-criteria-br-ac` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/acceptance-criteria-br-ac.zip -o /tmp/acceptance-criteria-br-ac.zip && unzip -oq /tmp/acceptance-criteria-br-ac.zip -d ~/.cursor/skills/ && rm /tmp/acceptance-criteria-br-ac.zip
```

```powershell
$z="$env:TEMP\acceptance-criteria-br-ac.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/acceptance-criteria-br-ac.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `acceptance-criteria-br-ac`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/acceptance-criteria-br-ac.zip -o /tmp/acceptance-criteria-br-ac.zip && unzip -oq /tmp/acceptance-criteria-br-ac.zip -d ~/.gemini/skills/ && rm /tmp/acceptance-criteria-br-ac.zip
```

```powershell
$z="$env:TEMP\acceptance-criteria-br-ac.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/acceptance-criteria-br-ac.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；步骤里提到的模板文件（`templates/` 下）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「给这个需求写验收标准：……」
- 「帮我把这段规则写成 BR，再补 AC」
- 「测试说 PRD 没写清，帮我从 PRD 反推一下用例」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「帮我把这段需求写成 BR，再补 AC：订单金额比较大的时候要主管审批，审批不及时要提醒。」 |
| 它问了你什么 | 先列出 3 个功能点请你确认有没有漏；「比较大」「不及时」它不会替你填数，而是写成「≥ 5000 元【待确认：阈值】」并问你。 |
| 它交付了什么 | BR-01~03、AC 6 条（含 5000.00 刚好等于、4999.99 不触发、驳回同一秒仓库拉单），末尾 2 条待确认写清问谁（见 `examples/示例_大额订单审批.md`）。 |

### 常见问题
**说了触发说法，它没反应怎么办？** 先确认文件夹名和 `SKILL.md` 第二行 `name:` 一致、放对了目录（见上面「安装」里你用的那个 AI）、新开了对话。还不行，直接说「用 acceptance-criteria-br-ac 这个 Skill」点名调用；或者把你平时的说法加进 `SKILL.md` 开头 `description:` 那一行里——它只靠这一行判断要不要出场。

**怎么改成自己团队的版本？** 不要一上来就大改。先照原样用 3 次，每次把它的产出和你手改后的版本都存下来，然后让 AI 对比两版、说出你改动背后的规则，把规则写进 `SKILL.md` 的步骤或「不要做」里；模板换成你们团队的格式，放进 `templates/` 覆盖同名文件即可。改完在 README「更新记录」里写一行。

**【待确认】太多怎么办？** 说明需求原文本来就没写清。把待确认清单直接发给业务负责人，回来后让它按回答更新一遍。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 四步流程、BR 与 AC 反例 |
| `templates/BR与AC表.md` | 空白表 |
| `templates/模糊词对照.md` | 7 个常见模糊词怎么改 |
| `examples/示例_大额订单审批.md` | 示例产出（示例数字） |

## 更新记录
- v1.0（2026-11-09）：首发。
- v1.0（2026-11-09）：README 改为「用处 / 用法」结构，补完整使用示例与常见问题。
- v1.0（2026-11-09）：安装改为按平台分节、给可复制命令（下载地址为上线前占位）。
- v1.0（2026-11-09）：安装补齐 4 个平台的命令（目录按产品技术部核实）。
