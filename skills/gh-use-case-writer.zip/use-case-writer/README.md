# 用例：主成功路径加每个分支（gh-use-case-writer）

免费下载，装上即用。用途：用例：主成功路径加每个分支。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 定义需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：qa-aman 及该仓库贡献者 · 来源：GitHub qa-aman/claude-skills（skills/by-role/business-analyst/use-case-writer）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
功能描述只写了「管理员可以给子账号分配权限」，没写权限冲突、子账号已离职这些分支，研发上线后才补。

### 适合谁
写 B 端后台、权限、流程类需求的产品经理和业务分析师。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 要把一个功能写成「谁 → 做什么 → 系统怎么回应」的步骤<br>要逐个列出异常和分支（扩展路径） | 要写用户故事 → 用 gh-user-stories<br>要画跨角色的流程 → 用 gh-process-mapper<br>要写测试步骤 → 用 gh-test-scenarios |

### 用前 / 用后
**用前：** 「子账号权限」一页需求，测试问了 11 个「如果……怎么办」，有 7 个文档里没有。

**用后：** 先列「角色—目标」清单，定范围和层级（用户目标层为主）；写完整用例：前置条件、触发、主成功路径（角色一步、系统一步交替编号）、成功保证；再给每一步写扩展分支（如「3a. 子账号已停用」）；最后标出可复用的公共用例和验收检查。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `use-case-writer/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-use-case-writer.zip -o /tmp/gh-use-case-writer.zip && unzip -oq /tmp/gh-use-case-writer.zip -d ~/.claude/skills/ && rm /tmp/gh-use-case-writer.zip
```

```powershell
$z="$env:TEMP\gh-use-case-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-use-case-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/use-case-writer` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-use-case-writer.zip -o /tmp/gh-use-case-writer.zip && unzip -oq /tmp/gh-use-case-writer.zip -d ~/.agents/skills/ && rm /tmp/gh-use-case-writer.zip
```

```powershell
$z="$env:TEMP\gh-use-case-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-use-case-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$use-case-writer` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-use-case-writer.zip -o /tmp/gh-use-case-writer.zip && unzip -oq /tmp/gh-use-case-writer.zip -d ~/.cursor/skills/ && rm /tmp/gh-use-case-writer.zip
```

```powershell
$z="$env:TEMP\gh-use-case-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-use-case-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `use-case-writer`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-use-case-writer.zip -o /tmp/gh-use-case-writer.zip && unzip -oq /tmp/gh-use-case-writer.zip -d ~/.gemini/skills/ && rm /tmp/gh-use-case-writer.zip
```

```powershell
$z="$env:TEMP\gh-use-case-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-use-case-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`references/use-case-template.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我把这个功能写成用例」
- 「这个流程的异常分支帮我列全」
- 「用 Cockburn 的格式写一份用例」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「SaaS 后台：主账号给子账号分配菜单权限和数据范围。帮我写用例。」 |
| 它问了你什么 | 先问参与的角色有哪些、这个用例在哪个层级；系统边界说不清时会先请你确认「权限服务算不算在系统内」。 |
| 它交付了什么 | 角色—目标清单 6 行；「分配权限」完整用例：主路径 7 步，扩展 9 条（如「4a. 选中的数据范围超出主账号自身范围：系统提示并只保留交集」）；公共用例「身份校验」单独抽出。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**用例和用户故事有什么区别？** 用户故事讲「为什么要」，用例讲「一步步怎么走、哪里会岔开」。复杂流程先写用例，再从中拆故事。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `use-case-writer`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 use-case-writer 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `use-case-writer`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `references/use-case-template.md` | 上游原文：用例模板 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `be4abcc` 版本，新增中文 README。
