# 业务流程图：现状、目标与差异（gh-process-mapper）

免费下载，装上即用。用途：业务流程图：现状、目标与差异。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 定义需求 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：qa-aman 及该仓库贡献者 · 来源：GitHub qa-aman/claude-skills（skills/by-role/business-analyst/process-mapper）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
B 端退款流程靠口口相传，PRD 里画了一张只有正常路径的流程图，审批卡在哪一步没人说得清。

### 适合谁
做 B 端后台、审批流、业务流程改造的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 要画清现状流程（谁、在哪一步、等多久）<br>要设计改造后的流程并说明改了什么 | 要写单个功能的用例 → 用 gh-use-case-writer<br>要画用户旅程（体验、情绪） → 用 gh-journey-mapping |

### 用前 / 用后
**用前：** 退款流程图只有 5 个方框，没有泳道，也没画「金额超 500 元转财务复核」这个分支。

**用后：** 先定层级（全局价值链 / 业务流程 / 执行步骤）和起止边界；画现状：按角色分泳道、标判断点和异常分支、标出交接处；量现状：周期、出错率、交接次数；再按去掉 / 简化 / 合并 / 自动化四招画目标流程，最后给一张差异表。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `process-mapper/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-process-mapper.zip -o /tmp/gh-process-mapper.zip && unzip -oq /tmp/gh-process-mapper.zip -d ~/.claude/skills/ && rm /tmp/gh-process-mapper.zip
```

```powershell
$z="$env:TEMP\gh-process-mapper.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-process-mapper.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/process-mapper` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-process-mapper.zip -o /tmp/gh-process-mapper.zip && unzip -oq /tmp/gh-process-mapper.zip -d ~/.agents/skills/ && rm /tmp/gh-process-mapper.zip
```

```powershell
$z="$env:TEMP\gh-process-mapper.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-process-mapper.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$process-mapper` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-process-mapper.zip -o /tmp/gh-process-mapper.zip && unzip -oq /tmp/gh-process-mapper.zip -d ~/.cursor/skills/ && rm /tmp/gh-process-mapper.zip
```

```powershell
$z="$env:TEMP\gh-process-mapper.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-process-mapper.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `process-mapper`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-process-mapper.zip -o /tmp/gh-process-mapper.zip && unzip -oq /tmp/gh-process-mapper.zip -d ~/.gemini/skills/ && rm /tmp/gh-process-mapper.zip
```

```powershell
$z="$env:TEMP\gh-process-mapper.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-process-mapper.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`references/bpmn-notation.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我画这个业务流程的泳道图」
- 「把现在的审批流程梳理一下，看看能怎么简化」
- 「这个流程改造前后有什么区别」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「SaaS 订货后台的退款流程：客服登记、主管审批、财务打款，超 500 元财务还要复核。平均 3 天才退完。帮我梳理并改造。」 |
| 它问了你什么 | 先问流程的起点和终点、每一步谁做、哪里最常卡住；没有数据的环节会标「待测量」。 |
| 它交付了什么 | 现状泳道图（文字或 Mermaid 写法）4 条泳道、2 个判断点、5 处交接；目标流程把 500 元以下改为主管审批后自动打款；差异表 4 行，预计交接从 5 次降到 3 次。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**流程图能直接显示出来吗？** 它多半给 Mermaid 写法或文字版。粘到支持 Mermaid 的文档或画图工具里即可显示。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `process-mapper`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 process-mapper 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `process-mapper`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `references/bpmn-notation.md` | 上游原文：流程图符号说明 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `be4abcc` 版本，新增中文 README。
