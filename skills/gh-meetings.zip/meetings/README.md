# 会议闸门：该不该开、怎么排议程、会后待办（gh-meetings）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Alireza Rezvani · 来源：GitHub alirezarezvani/claude-skills（productivity/meetings/skills/meetings）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
一个「同步一下」拉了 8 个人开 1 小时，没结论；会后待办没人认领。

### 适合谁
经常组织会议的产品经理、项目经理、小组长。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 发邀请前判断这个会该不该开<br>给要开的会排议程<br>会后把笔记变成有负责人、有日期的待办 | 要出整份会议纪要 → 用 meeting-minutes-4blocks<br>要做迭代复盘 → 用 gh-retro |

### 用前 / 用后
**用前：** 周一例会 8 个人开 60 分钟，只是轮流念进展。

**用后：** 先过闸门：没有要做的决定 → 改成书面同步；有决定但缺议程或负责人 → 先别开，说清缺什么；三样都齐 → 开，并算出这场会花多少钱。议程每项都要有期望结果，要拍板的排最前，最后留 5 分钟逐条念待办。会后待办按人分组，没人认领的、没日期的都标出来。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `meetings/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-meetings.zip -o /tmp/gh-meetings.zip && unzip -oq /tmp/gh-meetings.zip -d ~/.claude/skills/ && rm /tmp/gh-meetings.zip
```

```powershell
$z="$env:TEMP\gh-meetings.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-meetings.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/meetings` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-meetings.zip -o /tmp/gh-meetings.zip && unzip -oq /tmp/gh-meetings.zip -d ~/.agents/skills/ && rm /tmp/gh-meetings.zip
```

```powershell
$z="$env:TEMP\gh-meetings.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-meetings.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$meetings` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-meetings.zip -o /tmp/gh-meetings.zip && unzip -oq /tmp/gh-meetings.zip -d ~/.cursor/skills/ && rm /tmp/gh-meetings.zip
```

```powershell
$z="$env:TEMP\gh-meetings.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-meetings.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `meetings`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-meetings.zip -o /tmp/gh-meetings.zip && unzip -oq /tmp/gh-meetings.zip -d ~/.gemini/skills/ && rm /tmp/gh-meetings.zip
```

```powershell
$z="$env:TEMP\gh-meetings.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-meetings.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`assets/example_agenda.md`、`assets/meeting_gate_worksheet.md`、`references/action_item_discipline.md`、`references/agenda_discipline.md`、`references/meeting_cost_canon.md`、`scripts/action_item_extractor.py`、`scripts/agenda_builder.py`、`scripts/meeting_cost_calculator.py`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「这个会有必要开吗」
- 「帮我排一个 45 分钟的议程，先做决定的放前面」
- 「把这份会议笔记里的待办提出来，按人分好」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「周四想拉 6 个人开 45 分钟，讨论三季度定价用按量还是按席位，人均时薪按 150 元算。」 |
| 它问了你什么 | 如果你没说这个会要做什么决定，它会先问这一个问题——闸门全靠它判断。 |
| 它交付了什么 | 结论「可以开」，成本 6 人 × 0.75 小时 × 150 元 = 675 元，加上每人 23 分钟回神时间共约 1,020 元；议程：定价决策 15 分钟排第一，其余两项各 10 分钟，最后 5 分钟念待办。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**包里有脚本，安全吗？** 3 个 Python 小脚本，只用 Python 自带库，不联网、不发任何消息，唯一读的文件是你指定的会议笔记。能运行代码的工具会在运行前问你；网页版里它按同样规则手算。

**金额显示的是美元符号？** 脚本写死了 `$`，把时薪填成人民币数值即可，符号忽略。

**中文笔记提取不到待办？** 提取脚本认的是英文写法。把待办写成 `- [ ] @lisi 订会议室 by 2026-11-14`（负责人用拼音或英文名放在最前，日期用 年-月-日）就能认出来；或者直接让它人工提取，不用脚本。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `meetings`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 meetings 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `meetings`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `assets/example_agenda.md` | 上游原文：完整示例：从闸门到议程 |
| `assets/meeting_gate_worksheet.md` | 上游原文：可填写的「该不该开会」工作表 |
| `references/action_item_discipline.md` | 上游原文：待办必须有负责人和日期的文献依据 |
| `references/agenda_discipline.md` | 上游原文：议程写法（期望结果、限时、决策优先）的文献依据 |
| `references/meeting_cost_canon.md` | 上游原文：会议成本与「该不该开」的文献依据 |
| `scripts/action_item_extractor.py` | 上游原文：从会议笔记里提取待办，标出没负责人、没日期的 |
| `scripts/agenda_builder.py` | 上游原文：排限时议程，决策项优先 |
| `scripts/meeting_cost_calculator.py` | 上游原文：算会议成本并给出该不该开的结论 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `8f08254` 版本，新增中文 README。
