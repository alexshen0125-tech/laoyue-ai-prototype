# AI 什么时候该转人工、拒答或反问（gh-escalation-design）

免费下载，装上即用。用途：AI 什么时候该转人工、拒答或反问。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** AI 产品设计与评测 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：MC Dean（Owl-Listener） · 来源：GitHub Owl-Listener/ai-design-skills（ai-alignment-reasoning 插件下的 escalation-design 目录）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
AI 客服遇到退款纠纷还在一遍遍道歉，用户找不到人工，最后去投诉。

### 适合谁
设计 AI 客服、AI 助手、智能体的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 要定 AI 什么情况下必须转人工、拒绝或反问<br>要设计转人工时的体验（不让用户重说一遍） | 要设计答错后的整体兜底方案 → 用 ai-fallback-design<br>要设计 AI 怎么表达把握程度 → 用 gh-trust-calibration |

### 用前 / 用后
**用前：** 转人工的唯一条件是用户说了「人工」两个字，AI 在高金额纠纷里自己硬答。

**用后：** 列出 7 类必须升级的情况（把握低、风险高、用户情绪激动、意图反复问不清、超出范围、碰到规则红线、和用户争执不下）；5 种升级去向（人工客服、交还用户决定、转专业人员、报给管理员、自己标记待审）；转接体验要带上完整上下文、告知接下来会怎样、没人时给替代方案；再列反面做法。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `escalation-design/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-escalation-design.zip -o /tmp/gh-escalation-design.zip && unzip -oq /tmp/gh-escalation-design.zip -d ~/.claude/skills/ && rm /tmp/gh-escalation-design.zip
```

```powershell
$z="$env:TEMP\gh-escalation-design.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-escalation-design.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/escalation-design` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-escalation-design.zip -o /tmp/gh-escalation-design.zip && unzip -oq /tmp/gh-escalation-design.zip -d ~/.agents/skills/ && rm /tmp/gh-escalation-design.zip
```

```powershell
$z="$env:TEMP\gh-escalation-design.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-escalation-design.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$escalation-design` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-escalation-design.zip -o /tmp/gh-escalation-design.zip && unzip -oq /tmp/gh-escalation-design.zip -d ~/.cursor/skills/ && rm /tmp/gh-escalation-design.zip
```

```powershell
$z="$env:TEMP\gh-escalation-design.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-escalation-design.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `escalation-design`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-escalation-design.zip -o /tmp/gh-escalation-design.zip && unzip -oq /tmp/gh-escalation-design.zip -d ~/.gemini/skills/ && rm /tmp/gh-escalation-design.zip
```

```powershell
$z="$env:TEMP\gh-escalation-design.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-escalation-design.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「AI 客服什么时候该转人工」
- 「帮我设计 AI 的拒答和反问规则」
- 「转人工的体验怎么设计」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「电商 AI 售后客服，能查物流、改地址，不能直接退款。帮我设计升级规则。」 |
| 它问了你什么 | 先问 AI 能做和不能做的事、人工客服的在线时间。 |
| 它交付了什么 | 升级规则表 9 行（如「退款金额超 200 元或用户第二次表达不满 → 转人工，并附订单号和对话摘要」）；人工下班时的替代方案（留言 + 承诺回复时间）；3 条反面做法。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**规则里的金额、次数可以直接用吗？** 那是示例。按你们的客诉数据和客服人力来定。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `escalation-design`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 escalation-design 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `escalation-design`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `f41b650` 版本，新增中文 README。
