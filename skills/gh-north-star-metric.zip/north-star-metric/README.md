# 北极星指标（gh-north-star-metric）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-marketing-growth/skills/north-star-metric）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
团队一会儿盯成交额、一会儿盯日活，每个人优化的东西都不一样。

### 适合谁
要定产品核心指标、搭指标体系的产品经理和负责人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 新产品要定一个核心指标<br>老产品指标太多，想收成一个主指标加几个驱动指标 | 要做看板布局和告警 → 用 gh-metrics-dashboard<br>要定季度目标 → 用 gh-brainstorm-okrs<br>要分析某一次数据 → 用 data-question-decision-first |

### 用前 / 用后
**用前：** 提了「月成交额」当北极星，被指出那是收入不是用户得到的价值，也没法告诉哪个团队该干什么。

**用后：** 先判断产品属于「抢时间 / 促成交易 / 提升效率」哪一类；给出 1 个北极星，逐条对 7 条标准打勾；再给 3–5 个输入指标，说明各自由谁来推。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `north-star-metric/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-north-star-metric.zip -o /tmp/gh-north-star-metric.zip && unzip -oq /tmp/gh-north-star-metric.zip -d ~/.claude/skills/ && rm /tmp/gh-north-star-metric.zip
```

```powershell
$z="$env:TEMP\gh-north-star-metric.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-north-star-metric.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/north-star-metric` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-north-star-metric.zip -o /tmp/gh-north-star-metric.zip && unzip -oq /tmp/gh-north-star-metric.zip -d ~/.agents/skills/ && rm /tmp/gh-north-star-metric.zip
```

```powershell
$z="$env:TEMP\gh-north-star-metric.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-north-star-metric.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$north-star-metric` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-north-star-metric.zip -o /tmp/gh-north-star-metric.zip && unzip -oq /tmp/gh-north-star-metric.zip -d ~/.cursor/skills/ && rm /tmp/gh-north-star-metric.zip
```

```powershell
$z="$env:TEMP\gh-north-star-metric.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-north-star-metric.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `north-star-metric`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-north-star-metric.zip -o /tmp/gh-north-star-metric.zip && unzip -oq /tmp/gh-north-star-metric.zip -d ~/.gemini/skills/ && rm /tmp/gh-north-star-metric.zip
```

```powershell
$z="$env:TEMP\gh-north-star-metric.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-north-star-metric.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我定一个北极星指标」
- 「我们的核心指标该看什么」
- 「北极星和输入指标帮我拆一下」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「B2B 门店订货平台，门店每天向供应商下单，收入来自佣金，愿景是让门店不缺货也不压货。帮我定北极星。」 |
| 它问了你什么 | 会请你补商业模式、愿景、现在在看哪些指标、主要客户群（原文「提示」一节列了 5 项）。 |
| 它交付了什么 | 归为交易类；北极星「每周按时到货的门店订单数」；输入指标 4 个（活跃下单门店数、店均每周下单次数、准时履约率、再来一单使用率），附 7 条标准逐条判断。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**原文例子都是海外公司？** 换成你熟悉的行业说法就行，判断标准不变。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/north-star-metric 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `north-star-metric`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 north-star-metric 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `north-star-metric`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
