# 数据分析先问决策（data-question-decision-first）

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

**实测：** 实测通过（2026-11-10，提升较小）：在本机命令行 AI 里项目级安装真跑，「这个指标为什么掉了」自动调用，问中位数和平均数区别时不调用。一张首页改版后转化下跌的表（决策和口径都给了），装与不装各跑 2 次：装后平均 92.5 分、不装 84 分（不装另有 1 次卡死无输出，未计入）。首轮不装反而高 5 分；装后两次都没把「改版导致下跌」当结论，并把新用户占比上升、只有 iOS 掉得多分成「数据直接显示」和「推断」，有 1 次还查了预热活动结束的影响；不装的有 1 次直接下了「新首页确实有负面影响」的因果结论。数据和口径给得越全，这个包的提升越小。详见 AI 测评与指南《自制 Skill 全量实测》

## 用处

### 解决什么问题
一张表丢给 AI「分析一下」，拿回十个维度的图，每段都对，看完不知道该做什么。

### 适合谁
要用数据回答老板问题的产品经理、运营。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 老板问「这个活动还要不要做」「昨天怎么掉了」<br>手上有导出表，不知道从哪看起 | 问统计概念<br>口径已经写清，只要算一个数<br>学 SQL 语法 |

### 用前 / 用后
**用前：** 一张活动订单表丢进去，拿回「整体趋势、用户画像、地区分布」十段分析，每段都对，但看完不知道活动还做不做；复购率 14% 是怎么算的，也说不清。

**用后：** 先被问到「要决定 11 月还做不做」；口径写清「首单后 30 天内再下单 ÷ 首单人数，排除测试账号」；结论第一行是「暂不停，11-14 窗口满了重算」，因为还有 23% 的用户没满 30 天（示例）。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `data-question-decision-first/` 文件夹，里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/data-question-decision-first.zip -o /tmp/data-question-decision-first.zip && unzip -oq /tmp/data-question-decision-first.zip -d ~/.claude/skills/ && rm /tmp/data-question-decision-first.zip
```

```powershell
$z="$env:TEMP\data-question-decision-first.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/data-question-decision-first.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/data-question-decision-first` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/data-question-decision-first.zip -o /tmp/data-question-decision-first.zip && unzip -oq /tmp/data-question-decision-first.zip -d ~/.agents/skills/ && rm /tmp/data-question-decision-first.zip
```

```powershell
$z="$env:TEMP\data-question-decision-first.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/data-question-decision-first.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$data-question-decision-first` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/data-question-decision-first.zip -o /tmp/data-question-decision-first.zip && unzip -oq /tmp/data-question-decision-first.zip -d ~/.cursor/skills/ && rm /tmp/data-question-decision-first.zip
```

```powershell
$z="$env:TEMP\data-question-decision-first.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/data-question-decision-first.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `data-question-decision-first`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/data-question-decision-first.zip -o /tmp/data-question-decision-first.zip && unzip -oq /tmp/data-question-decision-first.zip -d ~/.gemini/skills/ && rm /tmp/data-question-decision-first.zip
```

```powershell
$z="$env:TEMP\data-question-decision-first.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/data-question-decision-first.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；步骤里提到的模板文件（`templates/` 下）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我分析一下这份订单数据」
- 「这个指标上周为什么掉了」
- 「看看这张表能看出什么」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「这是 10 月满减活动的订单导出，帮我分析一下。」 |
| 它问了你什么 | 先问三件事：看完要决定什么、结果是 A 或 B 你各怎么做、谁看什么时候要；再把复购率的分子分母、时间范围、要排除的测试单写出来请你确认。 |
| 它交付了什么 | 第一行建议「暂不停，11-14 窗口满了重算」；依据分「数据直接显示」和「推断」两栏，每个数写清怎么算的；局限里写明还有 23% 的用户没满 30 天（示例数据，见 `examples/示例_活动复购.md`）。 |

### 常见问题
**说了触发说法，它没反应怎么办？** 先确认文件夹名和 `SKILL.md` 第二行 `name:` 一致、放对了目录（见上面「安装」里你用的那个 AI）、新开了对话。还不行，直接说「用 data-question-decision-first 这个 Skill」点名调用；或者把你平时的说法加进 `SKILL.md` 开头 `description:` 那一行里——它只靠这一行判断要不要出场。

**怎么改成自己团队的版本？** 不要一上来就大改。先照原样用 3 次，每次把它的产出和你手改后的版本都存下来，然后让 AI 对比两版、说出你改动背后的规则，把规则写进 `SKILL.md` 的步骤或「不要做」里；模板换成你们团队的格式，放进 `templates/` 覆盖同名文件即可。改完在 README「更新记录」里写一行。

**我就是想随便看看，不行吗？** 可以，它会给你 3 个这份数据能回答的具体问题让你挑一个，比漫无目的地出图有用。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 四步流程、异动排查顺序、反例 |
| `templates/分析前三问.md` | 三问 + 口径确认表 |
| `templates/分析结论.md` | 结论格式 |
| `examples/示例_活动复购.md` | 示例产出（示例数据） |

## 更新记录
- v1.0（2026-11-09）：首发。
- v1.0（2026-11-09）：README 改为「用处 / 用法」结构，补完整使用示例与常见问题。
- v1.0（2026-11-09）：安装改为按平台分节、给可复制命令（下载地址为上线前占位）。
- v1.0（2026-11-09）：安装补齐 4 个平台的命令（目录按产品技术部核实）。
