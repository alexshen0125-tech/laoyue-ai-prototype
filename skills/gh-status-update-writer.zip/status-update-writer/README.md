# 项目进展汇报：按读者调高度，坏消息带对策（gh-status-update-writer）

免费下载，装上即用。用途：项目进展汇报：按读者调高度，坏消息带对策。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 推进落地 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Aakash Gupta · 来源：GitHub aakashg/pm-claude-skills（skills/status-update-writer）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
项目要延期，周报里还写「整体正常推进」，等老板发现时已经来不及调资源。

### 适合谁
要给老板、跨部门、管理层写项目进展的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 写周报、月报、项目进展、季度汇报<br>有坏消息要报，想同时给出对策 | 要三段式团队周报 → 用 gh-internal-comms<br>要规划长期跟谁沟通 → 用 gh-stakeholder-map |

### 用前 / 用后
**用前：** 周报 1 页流水账，风险写在最后一行「联调可能有点紧」。

**用后：** 先要齐三样：具体做了什么、给谁看、状态（正常 / 有风险 / 受阻）及依据；按读者调整高度（给老板只写结论、影响和要他做的决定）；坏消息开头就说，并配缓解方案；按模板输出，最后用检查清单自查。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `status-update-writer/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-status-update-writer.zip -o /tmp/gh-status-update-writer.zip && unzip -oq /tmp/gh-status-update-writer.zip -d ~/.claude/skills/ && rm /tmp/gh-status-update-writer.zip
```

```powershell
$z="$env:TEMP\gh-status-update-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-status-update-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/status-update-writer` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-status-update-writer.zip -o /tmp/gh-status-update-writer.zip && unzip -oq /tmp/gh-status-update-writer.zip -d ~/.agents/skills/ && rm /tmp/gh-status-update-writer.zip
```

```powershell
$z="$env:TEMP\gh-status-update-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-status-update-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$status-update-writer` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-status-update-writer.zip -o /tmp/gh-status-update-writer.zip && unzip -oq /tmp/gh-status-update-writer.zip -d ~/.cursor/skills/ && rm /tmp/gh-status-update-writer.zip
```

```powershell
$z="$env:TEMP\gh-status-update-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-status-update-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `status-update-writer`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-status-update-writer.zip -o /tmp/gh-status-update-writer.zip && unzip -oq /tmp/gh-status-update-writer.zip -d ~/.gemini/skills/ && rm /tmp/gh-status-update-writer.zip
```

```powershell
$z="$env:TEMP\gh-status-update-writer.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-status-update-writer.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`references/cadences.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我写这周的项目进展」
- 「项目要延期了，周报怎么写」
- 「给老板写一份季度汇报」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「电商会员改版，原定 11 月 20 日上线；支付联调晚了一周。读者是分管副总。贴上这周的群聊记录。」 |
| 它问了你什么 | 先问状态你自己怎么判断、需不需要老板做什么决定。 |
| 它交付了什么 | 状态「有风险」；开头一句：上线推迟到 11 月 27 日，原因是支付联调晚一周；对策 2 个（砍掉积分抵扣先上主流程 / 加 1 名测试）；需要副总在周三前选一个。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**能把群聊记录直接贴进去吗？** 能，原文说越乱越好，它来提炼。但先把客户隐私和内部敏感信息删掉。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `status-update-writer`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 status-update-writer 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `status-update-writer`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `references/cadences.md` | 上游原文：周报、月报、季度汇报的不同写法 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `64deebf` 版本，新增中文 README。
