# 用户故事与验收标准（gh-user-stories）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-execution/skills/user-stories）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
需求拆成故事时写成「作为用户，我想要这个功能」，验收标准一句「功能正常」，测试没法测，研发没法估。

### 适合谁
要往待办池里写故事的产品经理、产品负责人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 需求已经定了，要拆成一个迭代能做完的故事<br>每条故事要带 4–6 条看得见、能验证的验收标准 | 需求还没想清楚 → 先用 prd-step-by-step<br>要写带编号的业务规则和 Given/When/Then → 用 acceptance-criteria-br-ac<br>要写一步步的测试步骤 → 用 gh-test-scenarios |

### 用前 / 用后
**用前：** 「再来一单」写成一条大故事，研发估不了点；验收时才发现「下架商品怎么处理」没人定过。

**用后：** 拆成 4 条互不依赖的故事（入口展示、一键加购、下架跳过提示、连点防重复），每条是「作为……我想要……以便……」，各带 5 条能直接观察的验收标准。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `user-stories/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-user-stories.zip -o /tmp/gh-user-stories.zip && unzip -oq /tmp/gh-user-stories.zip -d ~/.claude/skills/ && rm /tmp/gh-user-stories.zip
```

```powershell
$z="$env:TEMP\gh-user-stories.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-user-stories.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/user-stories` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-user-stories.zip -o /tmp/gh-user-stories.zip && unzip -oq /tmp/gh-user-stories.zip -d ~/.agents/skills/ && rm /tmp/gh-user-stories.zip
```

```powershell
$z="$env:TEMP\gh-user-stories.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-user-stories.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$user-stories` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-user-stories.zip -o /tmp/gh-user-stories.zip && unzip -oq /tmp/gh-user-stories.zip -d ~/.cursor/skills/ && rm /tmp/gh-user-stories.zip
```

```powershell
$z="$env:TEMP\gh-user-stories.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-user-stories.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `user-stories`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-user-stories.zip -o /tmp/gh-user-stories.zip && unzip -oq /tmp/gh-user-stories.zip -d ~/.gemini/skills/ && rm /tmp/gh-user-stories.zip
```

```powershell
$z="$env:TEMP\gh-user-stories.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-user-stories.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「把这个功能拆成用户故事」
- 「帮我写这个需求的用户故事和验收标准」
- 「这个大需求拆成能放进一个迭代的故事」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「产品：门店订货 App；功能：再来一单；设计稿还没出；前提：只取最近一次订单。帮我拆用户故事。」 |
| 它问了你什么 | 原文用四个输入：产品、功能、设计稿链接、前提。设计稿没有就留空；它会先列出涉及的角色（店长、店员）和各自的路径再拆。 |
| 它交付了什么 | 4 条故事，每条有标题、描述、设计稿占位和 5 条验收标准，例如「下架商品不加入购物车，并在顶部提示『2 件已下架，已跳过』」。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**为什么写得这么白？** 原文要求「用小学毕业生能看懂的话」，研发和测试读得更快、歧义更少。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `user-stories`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 user-stories 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `user-stories`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
