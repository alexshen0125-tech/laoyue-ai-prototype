# 上线前业务验收（UAT）计划与放行标准（gh-uat-plan）

免费下载，装上即用。用途：上线前业务验收（UAT）计划与放行标准。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 上线验证 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：qa-aman 及该仓库贡献者 · 来源：GitHub qa-aman/claude-skills（skills/by-role/business-analyst/uat-plan）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
功能测完了，业务方第一次用是在上线当天，发现对账口径和他们的手工表对不上。

### 适合谁
B 端项目里要组织业务方验收、决定能不能上线的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 上线前要让真实业务人员走一遍<br>要写清进入验收和放行上线的条件<br>要一张按需求对应的验收场景表 | 要写开发自测的测试场景 → 用 gh-test-scenarios<br>要上线前全部门的检查清单 → 用 gh-launch-checklist |

### 用前 / 用后
**用前：** UAT 只发了一句「大家用一下有问题群里说」，三天收到 40 条反馈，分不清哪些阻断上线。

**用后：** 定验收范围、谁来测（业务用户而不是测试）、环境和时间；写进入条件和放行条件（如「必须项场景 100% 通过、无严重缺陷、业务负责人签字」）；从需求和用例推出场景（主路径一条、每个分支一条）；附缺陷分级和签字表。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `uat-plan/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-uat-plan.zip -o /tmp/gh-uat-plan.zip && unzip -oq /tmp/gh-uat-plan.zip -d ~/.claude/skills/ && rm /tmp/gh-uat-plan.zip
```

```powershell
$z="$env:TEMP\gh-uat-plan.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-uat-plan.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/uat-plan` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-uat-plan.zip -o /tmp/gh-uat-plan.zip && unzip -oq /tmp/gh-uat-plan.zip -d ~/.agents/skills/ && rm /tmp/gh-uat-plan.zip
```

```powershell
$z="$env:TEMP\gh-uat-plan.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-uat-plan.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$uat-plan` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-uat-plan.zip -o /tmp/gh-uat-plan.zip && unzip -oq /tmp/gh-uat-plan.zip -d ~/.cursor/skills/ && rm /tmp/gh-uat-plan.zip
```

```powershell
$z="$env:TEMP\gh-uat-plan.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-uat-plan.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `uat-plan`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-uat-plan.zip -o /tmp/gh-uat-plan.zip && unzip -oq /tmp/gh-uat-plan.zip -d ~/.gemini/skills/ && rm /tmp/gh-uat-plan.zip
```

```powershell
$z="$env:TEMP\gh-uat-plan.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-uat-plan.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我写一份 UAT 计划」
- 「上线前业务验收怎么组织」
- 「帮我定一下能不能上线的标准」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「B 端对账系统新版，财务 3 人参与验收，一周时间，需求清单和用例附上。」 |
| 它问了你什么 | 先问验收要回答的业务问题、参与人和时间；没有用例时，会先按需求清单推出场景并请你确认。 |
| 它交付了什么 | UAT 计划：进入条件 5 条、放行条件 4 条；场景 18 个（必须项 11 个），每个写前置数据、步骤、预期；缺陷按严重 / 一般 / 轻微三级定处理时限；最后一页签字表。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**UAT 和测试有什么区别？** 测试查「做得对不对」，UAT 让真实业务人员查「做的是不是我们要的」。两者都要有。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `uat-plan`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 uat-plan 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `uat-plan`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `be4abcc` 版本，新增中文 README。
