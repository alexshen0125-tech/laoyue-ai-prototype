# 智能体执行日志诊断：找主因、画流程、给证据链（gh-agent-trace-diagnoser）

免费下载，装上即用。用途：智能体执行日志诊断：找主因、画流程、给证据链。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** AI 产品设计与评测 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：PANGKAIFENG · 来源：GitHub PANGKAIFENG/ai-product-manager-skills（skills/agent-trace-diagnoser）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
智能体任务失败了，日志几百行，团队争论是模型的问题、工具的问题还是提示词的问题。

### 适合谁
负责智能体（Agent）产品、要和研发一起排查失败原因的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 手上有一段智能体执行记录、日志或工具调用序列，要找出最早出错的那一步<br>要一张能复核的执行流程图和证据链 | 要归类一大批对话记录的问题 → 用 gh-trace-codes<br>没有日志、只是设计新功能 |

### 用前 / 用后
**用前：** 用户说「总结 PDF 失败」，团队盯着最后一步的「文件太大」报错修了半天，其实第一步解析就失败了。

**用后：** 重建时间线，区分直接原因和后续症状；画执行流程图（实线是发生过的、虚线是推断的，关键节点标证据编号）；按规划路由、工具实现、环境、输出策略四层归类；列出证据链、可能的文件和行、修复建议，默认不改文件。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `agent-trace-diagnoser/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-agent-trace-diagnoser.zip -o /tmp/gh-agent-trace-diagnoser.zip && unzip -oq /tmp/gh-agent-trace-diagnoser.zip -d ~/.claude/skills/ && rm /tmp/gh-agent-trace-diagnoser.zip
```

```powershell
$z="$env:TEMP\gh-agent-trace-diagnoser.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-agent-trace-diagnoser.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/agent-trace-diagnoser` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-agent-trace-diagnoser.zip -o /tmp/gh-agent-trace-diagnoser.zip && unzip -oq /tmp/gh-agent-trace-diagnoser.zip -d ~/.agents/skills/ && rm /tmp/gh-agent-trace-diagnoser.zip
```

```powershell
$z="$env:TEMP\gh-agent-trace-diagnoser.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-agent-trace-diagnoser.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$agent-trace-diagnoser` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-agent-trace-diagnoser.zip -o /tmp/gh-agent-trace-diagnoser.zip && unzip -oq /tmp/gh-agent-trace-diagnoser.zip -d ~/.cursor/skills/ && rm /tmp/gh-agent-trace-diagnoser.zip
```

```powershell
$z="$env:TEMP\gh-agent-trace-diagnoser.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-agent-trace-diagnoser.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `agent-trace-diagnoser`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-agent-trace-diagnoser.zip -o /tmp/gh-agent-trace-diagnoser.zip && unzip -oq /tmp/gh-agent-trace-diagnoser.zip -d ~/.gemini/skills/ && rm /tmp/gh-agent-trace-diagnoser.zip
```

```powershell
$z="$env:TEMP\gh-agent-trace-diagnoser.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-agent-trace-diagnoser.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里另有 5 个参考文件，`SKILL.md` 里提到哪个就把哪个一起贴上。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「看下这个日志，定位根因」
- 「这个智能体为什么失败了，只说明问题不要改文件」
- 「帮我把这段执行记录画成流程图」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 贴上一段执行记录，说「用户让总结 report.pdf，最后说文件太大。只读分析」。 |
| 它问了你什么 | 通常不追问，直接分析；记录少于两个有效事件时会明确说「证据不足，无法可靠成图」。 |
| 它交付了什么 | 主因：第 2 步 PDF 链接解析返回不支持；放大因素：退回网页抓取后超出 5MB 上限；最终回复只说「文件太大」，掩盖了主因。附流程图、证据 E1–E5 和 2 条修复建议。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**流程图怎么显示？** 默认给 Mermaid 写法，粘到支持的文档里即可；不支持时它会改成文字箭头版。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `agent-trace-diagnoser`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 agent-trace-diagnoser 这个 Skill」点名调用。这个 Skill 的原文本身就有中文说明，一般中文提问即可触发。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `agent-trace-diagnoser`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（中英混合，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `agents/openai.yaml` | 上游原文：上游给某个平台的显示名配置，纯文字，不执行 |
| `evals/evals.json` | 上游原文：作者的测试题，纯数据 |
| `references/investigation-checklist.md` | 上游原文：排查清单 |
| `references/output-template.md` | 上游原文：输出模板 |
| `references/visualization-guide.md` | 上游原文：流程图画法 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `09a8757` 版本，新增中文 README。
