# 单次工作情境复盘：我这次处理得对吗（gh-situation-retrospective）

免费下载，装上即用。用途：单次工作情境复盘：我这次处理得对吗。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 个人成长 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：George Nurijanian · 来源：GitHub gnurio/nurijanian-skills（skills/situation-retrospective）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。

## 用处

### 解决什么问题
评审会上和研发吵起来，事后只觉得委屈，说不清自己哪一步可以做得更好。

### 适合谁
想从具体工作情境里成长的产品经理，尤其是 1–3 年、正在练沟通和决策的人。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 刚经历一次不顺利的会议、冲突、决策，想听一个诚实的反馈<br>准备晋升答辩，想把一次经历复盘成成长故事 | 要复盘整个迭代 → 用 gh-retro<br>要分析业务问题根因 → 用 gh-root-cause-analysis<br>要写述职 → 用 review-deck-5-lines |

### 用前 / 用后
**用前：** 「研发说做不了，我就去找了他们老大」，自己觉得推进得很果断。

**用后：** 它先追问最多两句「你当时具体说了什么、对方怎么回的」；然后对照 7 类行为标准（沟通、决策质量、团队授权、执行、调研、倾听、尊重人）给出：做对的 1–2 点、做漏的 1–3 点（你做了 X，更好的是 Y，为什么重要），以及下次遇到同样情况要做的一件具体的事。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `situation-retrospective/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-situation-retrospective.zip -o /tmp/gh-situation-retrospective.zip && unzip -oq /tmp/gh-situation-retrospective.zip -d ~/.claude/skills/ && rm /tmp/gh-situation-retrospective.zip
```

```powershell
$z="$env:TEMP\gh-situation-retrospective.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-situation-retrospective.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/situation-retrospective` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-situation-retrospective.zip -o /tmp/gh-situation-retrospective.zip && unzip -oq /tmp/gh-situation-retrospective.zip -d ~/.agents/skills/ && rm /tmp/gh-situation-retrospective.zip
```

```powershell
$z="$env:TEMP\gh-situation-retrospective.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-situation-retrospective.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$situation-retrospective` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-situation-retrospective.zip -o /tmp/gh-situation-retrospective.zip && unzip -oq /tmp/gh-situation-retrospective.zip -d ~/.cursor/skills/ && rm /tmp/gh-situation-retrospective.zip
```

```powershell
$z="$env:TEMP\gh-situation-retrospective.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-situation-retrospective.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `situation-retrospective`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-situation-retrospective.zip -o /tmp/gh-situation-retrospective.zip && unzip -oq /tmp/gh-situation-retrospective.zip -d ~/.gemini/skills/ && rm /tmp/gh-situation-retrospective.zip
```

```powershell
$z="$env:TEMP\gh-situation-retrospective.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-situation-retrospective.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`references/pm-excellence-behaviors.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「我刚遇到一个情况，想复盘一下我处理得对不对」
- 「评审会上和研发吵起来了，帮我复盘」
- 「这个决定我做得对吗」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「需求评审时研发说排期不够，我说『这是老板要的』，会后直接找了研发负责人加人。」 |
| 它问了你什么 | 「你说『老板要的』之后，研发说了什么？你有没有讲过这个需求为什么这周必须上？」 |
| 它交付了什么 | 做对：会后很快推动解决；做漏：用职级压人而不是讲清「为什么」、绕过了研发直接找上级，可能伤信任；下次：评审前先跟研发对一次「为什么这周要上、哪些可以砍」。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**它会不会只说好话？** 原文专门写了「不要夸—批—夸三明治」，有严重问题会直说，但只评行为、不评人。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `situation-retrospective`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 situation-retrospective 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `situation-retrospective`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `references/pm-excellence-behaviors.md` | 上游原文：7 类产品经理行为标准 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `43a0566` 版本，新增中文 README。
