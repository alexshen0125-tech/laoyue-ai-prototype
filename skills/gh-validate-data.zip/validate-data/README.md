# 分析结论发出去前的自检（gh-validate-data）

免费下载，装上即用。用途：分析结论发出去前的自检。

**版本：** v1.0 · **日期：** 2026-11-10 · **环节：** 上线验证 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Anthropic · 来源：GitHub anthropics/knowledge-work-plugins（data/skills/validate-data）· 许可证：Apache-2.0 · 老岳AI编辑部 中文整理与实测。上游文件除下述链接修正外原样保留，本 README 由编辑部撰写；这不是本站自制的 Skill。 编辑部修正了 1 处指向原仓库其他文件的链接，其余内容保持原样

## 用处

### 解决什么问题
周报里写「新功能带来转化提升 20%」，被数据同学指出分母口径变了，结论站不住。

### 适合谁
要把数据分析结论发给老板或跨部门的产品经理、分析师。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 分析做完、发出去之前，想先查一遍方法和计算<br>要知道这份结论能不能发、要加哪些说明 | 还在写 SQL → 用 gh-sql-queries<br>要分析实验结果 → 用 gh-ab-test-analysis |

### 用前 / 用后
**用前：** 对比了「本月 1–20 日」和「上月整月」，得出「本月下滑」的结论。

**用后：** 按 8 步查：问题定义、数据选取、人群口径、指标口径、对比是否公平；常见陷阱（连接导致重复、幸存者偏差、不完整周期对比、分母变化、平均数再平均、时区不一致）；抽查计算；图表；结论表述；最后给出「可以发 / 带说明发 / 需要返工」和必须附上的说明。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `validate-data/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-validate-data.zip -o /tmp/gh-validate-data.zip && unzip -oq /tmp/gh-validate-data.zip -d ~/.claude/skills/ && rm /tmp/gh-validate-data.zip
```

```powershell
$z="$env:TEMP\gh-validate-data.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-validate-data.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/validate-data` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-validate-data.zip -o /tmp/gh-validate-data.zip && unzip -oq /tmp/gh-validate-data.zip -d ~/.agents/skills/ && rm /tmp/gh-validate-data.zip
```

```powershell
$z="$env:TEMP\gh-validate-data.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-validate-data.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$validate-data` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-validate-data.zip -o /tmp/gh-validate-data.zip && unzip -oq /tmp/gh-validate-data.zip -d ~/.cursor/skills/ && rm /tmp/gh-validate-data.zip
```

```powershell
$z="$env:TEMP\gh-validate-data.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-validate-data.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `validate-data`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-validate-data.zip -o /tmp/gh-validate-data.zip && unzip -oq /tmp/gh-validate-data.zip -d ~/.gemini/skills/ && rm /tmp/gh-validate-data.zip
```

```powershell
$z="$env:TEMP\gh-validate-data.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-validate-data.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；包里其他文件（`CONNECTORS.md`）需要时一起贴。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「这份分析发给老板前帮我检查一遍」
- 「帮我看看这个数据结论站不站得住」
- 「这个对比口径有没有问题」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「这是我们的周报分析（贴结论和 SQL），结论是新推荐位带来转化提升 20%，帮我检查。」 |
| 它问了你什么 | 先问这份分析要回答什么问题、给谁看；没给原始查询时，会把「无法抽查计算」写进报告。 |
| 它交付了什么 | 结论「带说明发」：发现 2 个中等问题——上线前后两周包含一个大促日、分母从「访问用户」变成了「点击用户」；建议改为同周期对比并统一分母，附 2 条必须写给读者的说明。 |

（示例为编辑部按原 `SKILL.md` 的步骤，用虚构场景逐步推演的一次过程，你的产出会随输入不同。）

### 常见问题
**`~~data warehouse` 这种写法是什么？** 占位符，指你自己给 AI 工具接上的数仓。包里附了上游 `CONNECTORS.md` 说明；没接也能用，把查询和结果贴给它即可。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 除上述链接修正外保持上游原文，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `validate-data`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 validate-data 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `validate-data`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，修正 1 处包外链接）：步骤、规矩、输出格式 |
| `CONNECTORS.md` | 上游原文：上游插件说明：`~~知识库` 这类占位符分别指哪类工具（只是说明，不含任何连接配置） |
| `LICENSE` | 上游许可证原文（Apache-2.0），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-10 v1.0：收录上游提交 `e050c2e` 版本，新增中文 README。
