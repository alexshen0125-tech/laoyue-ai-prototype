# 方案红队：先替它辩护，再攻击关键假设（gh-strategy-red-team）

免费下载，装上即用。

**版本：** v1.0 · **日期：** 2026-11-09 · **出品：** 小齿轮 ｜ 老岳AI编辑部 · Skill 与自动化组

> 原作者：Pawel Huryn · 来源：GitHub phuryn/pm-skills（pm-execution/skills/strategy-red-team）· 许可证：MIT · 老岳AI编辑部 中文整理与实测。上游文件原样保留未改，本 README 由编辑部撰写；这不是本站自制的 Skill。 编辑部按 MIT 许可删除了原文末的课程推广链接，其余内容保持原样。

## 用处

### 解决什么问题
方案在内部只收到客气的反馈，一上会就被老板一句「凭什么用户会买单」问住。

### 适合谁
要向老板、管理层汇报方案或路线图的产品经理。

### 什么时候用 / 什么时候别用
| 用 | 别用 |
|---|---|
| 方案定稿前，想先找出「这条不成立方案就完蛋」的假设<br>准备高层评审，想先被人狠狠问一遍 | 想倒推上线会怎么失败 → 用 gh-pre-mortem<br>只想检查文档写得清不清楚 → 用 prd-four-role-review<br>还没有成型的方案 |

### 用前 / 用后
**用前：** 方案里写着「店长有补货痛点，做了就会用」，评审时被问「你访谈了几个店长」，答不上来。

**用后：** 3–5 条致命假设排好序，每条写清：在什么情况下会失败、这周就能拿到的证据、到哪条线就止损、最便宜的验证办法；最后还有一段「哪些地方站得住」，不为挑刺而挑刺。

## 用法

### 安装
按你用的 AI 选一节，复制命令运行即可。下载包解压后是一个 `strategy-red-team/` 文件夹（与 `SKILL.md` 里的 `name` 一致，不带 `gh-` 前缀），里面有 `SKILL.md`。各平台目录以产品技术部《各 AI 的 Skill 安装方式核实》（2026-11-09，官方文档）为准；命令只做建目录、下载、解压三件事。

#### Claude Code
个人级（所有项目都能用）：

```bash
mkdir -p ~/.claude/skills && curl -fsSL https://laoyueai.top/s/gh-strategy-red-team.zip -o /tmp/gh-strategy-red-team.zip && unzip -oq /tmp/gh-strategy-red-team.zip -d ~/.claude/skills/ && rm /tmp/gh-strategy-red-team.zip
```

```powershell
$z="$env:TEMP\gh-strategy-red-team.zip"; New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-strategy-red-team.zip -OutFile $z; Expand-Archive $z "$HOME\.claude\skills" -Force; Remove-Item $z
```

只在某个项目里用：先进入项目根目录，把命令里的 `~/.claude/skills`（PowerShell 里是 `$HOME\.claude\skills`）换成 `.claude/skills`。装好后新开一个会话，说一句下面的触发说法；也可以输入 `/strategy-red-team` 直接调用。

#### Codex CLI
```bash
mkdir -p ~/.agents/skills && curl -fsSL https://laoyueai.top/s/gh-strategy-red-team.zip -o /tmp/gh-strategy-red-team.zip && unzip -oq /tmp/gh-strategy-red-team.zip -d ~/.agents/skills/ && rm /tmp/gh-strategy-red-team.zip
```

```powershell
$z="$env:TEMP\gh-strategy-red-team.zip"; New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-strategy-red-team.zip -OutFile $z; Expand-Archive $z "$HOME\.agents\skills" -Force; Remove-Item $z
```

装好后新开会话，输入 `/skills` 能看到它；也可以输入 `$strategy-red-team` 点名调用。

#### Cursor
```bash
mkdir -p ~/.cursor/skills && curl -fsSL https://laoyueai.top/s/gh-strategy-red-team.zip -o /tmp/gh-strategy-red-team.zip && unzip -oq /tmp/gh-strategy-red-team.zip -d ~/.cursor/skills/ && rm /tmp/gh-strategy-red-team.zip
```

```powershell
$z="$env:TEMP\gh-strategy-red-team.zip"; New-Item -ItemType Directory -Force "$HOME\.cursor\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-strategy-red-team.zip -OutFile $z; Expand-Archive $z "$HOME\.cursor\skills" -Force; Remove-Item $z
```

装好后在 Agent 对话框输入 `/` 搜 `strategy-red-team`，或直接说触发说法。

#### Gemini CLI
```bash
mkdir -p ~/.gemini/skills && curl -fsSL https://laoyueai.top/s/gh-strategy-red-team.zip -o /tmp/gh-strategy-red-team.zip && unzip -oq /tmp/gh-strategy-red-team.zip -d ~/.gemini/skills/ && rm /tmp/gh-strategy-red-team.zip
```

```powershell
$z="$env:TEMP\gh-strategy-red-team.zip"; New-Item -ItemType Directory -Force "$HOME\.gemini\skills" | Out-Null; Invoke-WebRequest https://laoyueai.top/s/gh-strategy-red-team.zip -OutFile $z; Expand-Archive $z "$HOME\.gemini\skills" -Force; Remove-Item $z
```

说触发说法后，界面会弹出「是否启用这个 Skill」的确认，同意后生效。

#### 网页版（DeepSeek、Kimi、豆包、通义等）：复制全文粘贴
1. 打开包里的 `SKILL.md`，全选复制。
2. 新开一个对话，先粘贴 `SKILL.md` 全文，再另起一行写你的需求；这个包只有一个 `SKILL.md`，贴它就够了。
3. 同一个对话里接着干活；换新对话要重新粘贴。

### 3 句触发说法
- 「帮我红队一下这个方案」
- 「这份路线图里最站不住的假设是什么」
- 「下周给老板汇报，先帮我攻击一遍这个策略」

### 一次完整使用示例
| | 内容 |
|---|---|
| 你说了什么 | 「这是明年一季度门店补货的方案（贴全文），下周给分管副总汇报，帮我红队一遍。」 |
| 它问了你什么 | 先把方案里所有「断言」列出来，分成「不成立就完蛋」和「装饰性」两类，只攻击前一类；方案没给够信息的地方写进「无法评估」。 |
| 它交付了什么 | 排第 1 的假设「补货慢是店长流失的主因」——失败条件：流失访谈里补货排不进前三；本周证据：拉近 3 个月流失门店的回访记录；止损线：提到补货的不到 30% 就换方向；最便宜的测试：给 20 家店人工代下单两周，看复购。 |

（示例为编辑部按原 `SKILL.md` 用虚构的门店订货场景走通一遍的结果，你的产出会随输入不同。）

### 常见问题
**它会不会为了显得专业硬挑毛病？** 原文专门写了「不编造弱点」：站得住的地方会明说站得住。你发现它硬挑，直接指出，它会收回。

**原文里的 `$ARGUMENTS` 是什么？** 是「你这次给的内容」的占位符。用 `/strategy-red-team 你的内容` 调用时会被自动替换；其他平台或直接说话触发时，它会把你的话当作这部分内容，不影响使用。

**原文是英文，它会用英文回答吗？** 你用中文提问，一般就用中文回答；不放心就在需求后面加一句「用中文输出」。`SKILL.md` 保持上游原文不改，方便以后跟着原作者更新。

**说了触发说法，它没反应怎么办？** 先确认文件夹名是 `strategy-red-team`（和 `SKILL.md` 里的 `name:` 一致）、放对了目录、新开了对话。还不行，直接说「用 strategy-red-team 这个 Skill」点名调用。原文的描述是英文，中文说法偶尔对不上；想让它更容易被叫起来，可以在你自己那份 `SKILL.md` 的 `description:` 末尾加一句中文说法（这是你本地的改动，不影响原作者许可）。

**和别的 Skill 重名了？** 如果你已经装过同名的（比如都叫 `strategy-red-team`），后装的会覆盖或冲突。先把旧的那个文件夹改名或移走。

## 包里有什么
| 文件 | 用途 |
|---|---|
| `SKILL.md` | 上游原文（英文，未改动）：步骤、规矩、输出格式 |
| `LICENSE` | 上游许可证原文（MIT），原样保留 |
| `README.md` | 本站中文说明（本文件） |

## 更新记录
- 2026-11-09 v1.0：收录上游提交 `9af7bfd` 版本，新增中文 README。
