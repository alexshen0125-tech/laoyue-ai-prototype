// 在模板根目录运行 node m-sync-conflict/verify.cjs <本机jsdom目录>
const {JSDOM,VirtualConsole}=require(process.argv[2]||'jsdom');
const fs=require('fs'),assert=require('node:assert/strict');
const names=["m-sync-conflict"];
const cases={"m-sync-conflict":{"local":[["set","server","13"],["act","compare",1],["set","server","12"],["act","compare",2],["act","commit",3]],"cloud":[["act","backup",1],["act","adopt",2],["act","restore",3,"供应商承诺周五到仓"]],"merge":[["act","preview",1],["set","source","本机"],["act","preview",2,"13900003682"],["act","save",3]],"backoff":[["act","retry",1],["act","tick",2],["act","retry",0],["act","tick",2],["act","retry",0],["act","tick",2],["act","retry",3]],"snapshot":[["set","days",0],["act","keep",1],["set","days",7],["act","keep",2],["act","resolve",2,"至少8字"],["set","reason","人工核对客户最新说明采用云端"],["act","resolve",3]]}};
(async()=>{for(const name of names){
let checks=0,states=0,errors=[];const vc=new VirtualConsole();vc.on('jsdomError',e=>{if(!/Could not parse CSS/.test(e.message))errors.push(e.message)});
const dom=new JSDOM(fs.readFileSync(name+'/index.html','utf8'),{url:'https://offline.invalid/'+name+'/index.html',runScripts:'dangerously',virtualConsole:vc,beforeParse(w){w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};w.URL.createObjectURL=()=> 'blob:offline';w.URL.revokeObjectURL=()=>{};w.HTMLAnchorElement.prototype.click=function(){w.__download=this.download;};Object.defineProperty(w.navigator,'clipboard',{value:{writeText:async t=>w.__copy=t}});}});
const w=dom.window,doc=w.document;const ok=(v,msg)=>{assert.ok(v,name+': '+msg);checks++};
const q=s=>{const e=doc.querySelector(s);assert.ok(e,name+' 缺少 '+s);return e};
ok(w.Gallery?.cfg.sections.length===5,'五种做法初始化');ok(w.Proto._prompts.length===3,'三条AI提示词');ok(q('a[download]').getAttribute('href')==='./'+name+'.zip','模块zip下载路径');
for(const sec of w.Gallery.cfg.sections){
const statesHtml=[];for(const state of sec.states){q('#'+sec.id+' .g-states [data-st="'+state.id+'"]').click();states++;const body=q('#'+sec.id+' [data-demo]');ok(body.textContent.length>20,'状态非空 '+sec.id+'/'+state.name);statesHtml.push(body.innerHTML);}
ok(new Set(statesHtml).size===sec.states.length,'状态UI区分 '+sec.id);
q('#'+sec.id+' [data-copy-html]').click();await new Promise(r=>setTimeout(r,0));ok(w.__copy.includes('rb-panel')&&w.__copy.includes(':root'),'复制当前界面及样式');
q('#'+sec.id+' [data-copy-prompt]').click();await new Promise(r=>setTimeout(r,0));ok(w.__copy.includes(sec.name),'做法提示词');
q('#'+sec.id+' .g-states [data-st="0"]').click();
for(const step of cases[name][sec.id]){
 const [kind,key,value,txt]=step;
 if(kind==='reset'){q('#'+sec.id+' [data-act=reset]').click();continue;}
 if(kind==='set'){const input=q('#'+sec.id+' [data-field="'+key+'"]');input.value=value;input.dispatchEvent(new w.Event('input',{bubbles:true}));continue;}
 const btn=q('#'+sec.id+' [data-act="'+key+'"]');ok(!btn.disabled,sec.id+'/'+key+'操作可用');btn.click();
 ok(q('#'+sec.id+' .g-states [data-st="'+value+'"]').getAttribute('aria-pressed')==='true',sec.id+'/'+key+'进入状态'+value);
 if(txt)ok(q('#'+sec.id+' [data-demo]').textContent.includes(txt),sec.id+'/'+key+'包含'+txt);
}
}
// 补充验证具体业务不变量，避免只验证状态标签。
if(name==='m-data-permission'){
const sec=w.Gallery.cfg.sections.find(x=>x.id==='rows');q('#rows .g-states [data-st="2"]').click();ok(q('#rows tbody').children.length===2,'华东只能看到两行');ok(!q('#rows [data-demo]').textContent.includes('广州二店'),'跨区数据未渲染');
q('#columns .g-states [data-st="0"]').click();const t=q('#columns [data-field=tail]');t.value=0;t.dispatchEvent(new w.Event('input',{bubbles:true}));q('#columns [data-act=mask]').click();ok(!q('#columns tbody').textContent.includes('6291'),'零尾号不保留数字');
}
if(name==='m-sla'){
q('#reminder .g-states [data-st="0"]').click();const t=q('#reminder [data-field=ahead]');t.value=60;t.dispatchEvent(new w.Event('input',{bubbles:true}));q('#reminder [data-act=scan]').click();ok(q('#reminder [data-demo]').textContent.includes('本轮命中3件'),'60分钟窗口准确命中三件');
}
if(name==='m-sku-editor'){
ok(q('#stock [data-demo]').textContent.includes('148'),'同批次拒绝后账面仍148');ok(q('#price [data-act=preview]').disabled,'调价保存后按钮锁定');
}
if(name==='m-ai-knowledge'){
const chunk=w.Gallery.cfg.sections.find(x=>x.id==='chunks').data;ok(chunk.chunks.join('')===chunk.text,'固定切片能还原全部原文');const overlap=w.Gallery.cfg.sections.find(x=>x.id==='overlap').data;ok(overlap.parts[0].text.slice(-8)===overlap.parts[1].text.slice(0,8),'窗口实际共享八字符');
}
if(name==='m-ai-feedback'){
const privacy=w.Gallery.cfg.sections.find(x=>x.id==='privacy').data;ok(privacy.raw==='','隐私原文本地清除');ok(!q('#privacy [data-demo]').textContent.includes('13800006291'),'安全稿没有完整手机号');
}
if(name==='m-price-rule'){
const budget=w.Gallery.cfg.sections.find(x=>x.id==='budget').data;ok(budget.used===1940,'只占用一次80元补贴');ok(q('#budget [data-act=check]').disabled,'占用后禁止重复试扣');
}
if(name==='m-membership'){
const redeem=w.Gallery.cfg.sections.find(x=>x.id==='redeem').data;ok(redeem.balance===360,'失败兑换不扣积分，成功只扣500');ok(q('#redeem [data-act=redeem]').disabled,'兑换成功后锁定请求');
}
if(name==='m-shift-handover'){
q('#tasks .g-states [data-st="0"]').click();function setTask(k,v){const e=q('#tasks [data-field='+k+']');e.value=v;e.dispatchEvent(new w.Event('input',{bubbles:true}));}setTask('person','晚班 江澄');q('#tasks [data-act=accept]').click();setTask('person','中班 许岚');setTask('task','客诉回访');q('#tasks [data-act=accept]').click();const td=w.Gallery.cfg.sections.find(x=>x.id==='tasks').data;ok(td.owners['冷链到货验温']==='晚班 江澄'&&td.owners['客诉回访']==='中班 许岚','逐事项保存接班人，后选人员不改旧签收');
}

q('[data-dark="1"]').click();ok(doc.documentElement.dataset.theme==='dark','暗色可切换');
ok(errors.length===0,'无运行错误 '+errors.join(';'));
fs.writeFileSync(name+'/runtime-validation.json',JSON.stringify({kind:'离线JSDOM验证，不含浏览器视觉验收',states,checks,errors,tested_methods:Object.keys(cases[name]),source_sha256:require('crypto').createHash('sha256').update(fs.readFileSync(name+'/index.html')).digest('hex')},null,2)+'\n');
console.log(name+': '+states+'状态 / '+checks+'断言');dom.window.close();
}})().catch(e=>{console.error(e);process.exit(1)});
